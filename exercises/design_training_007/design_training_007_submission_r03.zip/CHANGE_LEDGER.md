# CHANGE LEDGER: DESIGN_TRAINING_007 (TRIPFLOW)

> **Mã nhiệm vụ**: `DESIGN_TRAINING_007`  
> **Chặng**: `FOUNDATION_TRANSFER_CAPSTONE` (Transfer Testing on New Brief)  
> **Sản phẩm**: `TRIPFLOW — Bảng điều phối tour khởi hành`  
> **Đợt nộp**: `DESIGN_TRAINING_007_REPAIR_002` (Final Repair Round 2/2)  
> **Quy chuẩn đối soát**: Khóa mã băm SHA-256 bất biến, ghi nhận toàn bộ bước chuyển giao và tinh chỉnh phản biện.

---

## 🔒 1. Bảng Đối Soát Mã Băm (Source & Hash Ledger)

### 1.1. Tài Liệu Phát Hành Gốc Của Controller (R01.1 — 100% Byte-Identical)
| Tệp / Phiên Bản | SHA-256 Checksum Thực Tế | SHA-256 Chuẩn Controller | Đối Soát |
| :--- | :--- | :--- | :---: |
| `DESIGN_TRAINING_007_DIRECTIVE.md` | `0840d95724643b730237444005d20a6097d98ec72bc0b40441e1ee6e8064d7d7` | `0840d95724643b730237444005d20a6097d98ec72bc0b40441e1ee6e8064d7d7` | `EXACT MATCH` |
| `DESIGN_TRAINING_007_REVIEW_001.md` | `f545d0fb2eb693256066cfdf4a0493a4535e7292ad7c8d4214a87a8c994fdd00` | `f545d0fb2eb693256066cfdf4a0493a4535e7292ad7c8d4214a87a8c994fdd00` | `EXACT MATCH` |
| `DESIGN_TRAINING_007_REVIEW_002.md` | `37a4be75236730287a19ed184cc4ae0bd9a1286a1a01e5d1fc7fc918e0cd51d3` | `37a4be75236730287a19ed184cc4ae0bd9a1286a1a01e5d1fc7fc918e0cd51d3` | `EXACT MATCH` |

### 1.2. Mã Nguồn Đã Qua Vòng Sửa Cuối 2/2 (Final Checksums)
| Phiên Bản / Tệp | Đường Dẫn Tương Đối | SHA-256 Checksum | Trạng Thái |
| :--- | :--- | :--- | :---: |
| **Baseline** | `baseline/index.html` | `d7725c3129303aaf375b457f246c215281da718cb008b68931dc001b429c5004` | `PATCHED_COMPLIANT` |
| **Candidate Pre-Critique** | `candidate/pre_critique.html` | `0e68156a2f38bf14c8dde210ef96b363d5681900d83837684cf55931be3e655a` | `PATCHED_COMPLIANT` |
| **Candidate Final** | `candidate/index.html` | `ee5294b94f37e2b4945743ab3215af238dde9e3b97af10a357872c1a85506800` | `FINAL_LOCKED` |
| **Direction A Specimen** | `directions/option_a.html` | `c6a2dbd5292eb5f91753c15d5ecdd94fb797c23101eb89caefaa9dc90b39679f` | `ACTIVE` |
| **Direction B Specimen** | `directions/option_b.html` | `0b15a63901b0f5b9d3e8e1966a0129c54238e8ecaaecfcadfaeb81d2f00a29ea` | `ACTIVE` |
| **Design Contract** | `DESIGN_CONTRACT.yaml` | `[Structured Specification]` | `ACTIVE` |
| **Verification Ledger** | `VERIFICATION.json` | `[14/14 Conjunction Evidence]` | `SELF_CHECK_PASS` |

---

## 📝 2. Lịch Sử Biến Đổi & Quyết Định Kỹ Thuật (Change Log)

### Giai đoạn 1: Baseline $\to$ Candidate Pre-Critique
* **Composition & Visual Hierarchy**:
  - Bổ sung khối tiêu điểm khẩn cấp (`Urgent Focus Module`) cho `T01` (Hạ Long 2N1Đ - khởi hành < 24h, chờ khách sạn) với nút hành động trực tiếp, nhưng bảo toàn đường dẫn và tầm nhìn tới `T02` và toàn bộ danh sách 8 tour.
  - Chuyển đổi từ danh sách thẻ card rời rạc sang **Grouped Container with Hairline Dividers** (Quy tắc `CAPSTONE-003`), tạo cảm giác sổ điều phối hành trình trang nhã, chuyên nghiệp.
* **Information Architecture (IA)**:
  - Chọn **Phương án B (Theo luồng xử lý nghiệp vụ)** làm điều hướng chính: *Tất cả*, *Cần xử lý* (T01, T03, T06), *Trong 48 giờ* (T01, T02), *Sẵn sàng* (T02, T05), *Hoàn thành* (T08).
* **Art Direction**:
  - Hiện thực hóa **Direction A (Dispatch Ledger)**: bảng màu sáng Warm Paper `#FAF9F6`, đường kẻ hairline `#E2E8F0`, typography Sans-serif kết hợp Monospace cho các trường dữ liệu giờ giấc và mã tour.

---

### Giai đoạn 2: Candidate Pre-Critique $\to$ Candidate Final (Vòng Phản Biện - Critique)
* **Kết quả Phản biện (Critique Taxonomy)**:
  - `Strength 1`: Khối điểm nóng T01 tại màn hình đầu giúp định hướng thị giác tức thì. *Quyết định: Giữ nguyên.*
  - `Defect 1`: Trên màn hình di động (< 480px), nút "Chi tiết" bị nhảy xuống chiếm 1 dòng riêng dạng block full-width, làm vỡ nhịp điệu 2 dòng và tăng không gian cuộn lãng phí.
  - `Trade-off 1`: Giữ snippet ghi chú vấn đề trong cột Tour để quét nhanh nguyên nhân mà không cần mở popup.
* **Giả thuyết Sửa (Single Hypothesis)**:
  - *"Nếu tinh chỉnh CSS layout trên mobile (< 480px) để nút Chi tiết neo gọn ở góc trên bên phải dòng dữ liệu và bổ sung biểu tượng icon ngữ nghĩa cho hộp trạng thái FSM, giao diện sẽ đạt nhịp điệu 2 dòng chuẩn mực (`CAPSTONE-002`) và tăng cường tính nhận biết không phụ thuộc màu sắc."*
* **2 Thay đổi Thực tế Đã Áp dụng**:
  1. **Thay đổi 1 (Mobile Cadence)**: Tái cấu trúc grid layout của `.ledger-item` trên mobile trong `candidate/index.html` thành `50px 1fr auto`, cho phép nút Chi tiết neo tại cột 3 trên dòng 1, bảo đảm nhịp điệu 2 dòng gọn gàng.
  2. **Thay đổi 2 (Semantic Live Feedback)**: Tinh chỉnh hộp thông báo trạng thái `status-feedback-box` với icon ngữ nghĩa và kiểu chữ rõ ràng, loại bỏ hoàn toàn sự phụ thuộc màu sắc đơn độc.
* **Quyết định thẩm định**: **`ADOPT`**.

---

### Giai đoạn 3: Khắc phục Tràn Màn Hình Di Động (Mobile Viewport Flex Resolution - T12 Pass)
* **Vấn đề phát hiện**: Khi kiểm thử T12 trên viewport mobile 390×844px, thanh input tìm kiếm và nút "Xoá bộ lọc" trên cùng dòng bị tràn 16px (`scrollWidth: 391px > clientWidth: 375px`) do thuộc tính flexbox mặc định `min-width: auto`.
* **Biện pháp xử lý**:
  1. Thiết lập `min-width: 0` trên `.search-input-field` để triệt tiêu hiện tượng flex blowout.
  2. Chuyển sang bố cục dọc `flex-direction: column` cho hàng tìm kiếm trên màn hình hẹp (< 480px).
* **Kết quả**: `scrollWidth: 375px == clientWidth: 375px`, hoàn toàn không có overflow ngang, T12 chuyển sang `PASS`.

---

### Giai đoạn 4: Đợt Sửa Chữa 1/2 — Repair Round 1 (Theo Controller Review 001)
* **F01 (Data Integrity & Canonical Tuples)**:
  - Khôi phục chính xác 8 tuple nghiệp vụ chuẩn chỉ của `TRIPFLOW` trong mã nguồn và báo cáo nghiệm thu.
  - Chuẩn hóa toàn bộ liên kết tệp sang đường dẫn tương đối `./DESIGN_CONTRACT.yaml`, loại bỏ triệt để đường dẫn tuyệt đối.
* **F02 (Information Architecture Separation)**:
  - Phân tách dứt khoát 2 phân tầng:
    - **Tầng 1 (Primary Workflow Navigation)**: Dãy nút phân đoạn ngang gồm: *Tất cả*, *Cần xử lý* (T01, T03, T06), *Đang chuẩn bị* (T04, T07), *Sẵn sàng* (T02, T05), *Đã hoàn thành* (T08).
    - **Tầng 2 (Faceted Attribute Filters)**: Bộ lọc thuộc tính độc lập gồm *Thời gian: Tất cả | Trong 48 giờ* và *Phụ trách: Tất cả | Lan | Minh | Huy | An*.
  - Bộ lọc AND giao nhau hoạt động hoàn hảo: chọn "Cần xử lý" + "Huy" + query "nha xe" trả về chính xác duy nhất T06.
* **F03 (Single Stable Action Element FSM)**:
  - Hợp nhất nút xử lý thành một phần tử DOM duy nhất (`#btn-save-contact-note` trên candidate và `#btn-submit-contact` trên baseline).
  - Quá trình FSM chuyển đổi nhãn nút tại chỗ: *Lưu nhật ký* $\to$ *Đang lưu nhật ký…* $\to$ *Thử lưu lại* $\to$ *Đang lưu nhật ký…* $\to$ *Lưu nhật ký*.
* **F04 (Critique Scope Isolation & Common Compliance Patch)**:
  - Áp dụng bản vá quy chuẩn chung (IA separation, single stable button, 44px touch targets) lên cả 3 artifact (`baseline`, `pre_critique`, `candidate_final`).
  - Đảm bảo diff giữa `candidate/pre_critique.html` và `candidate/index.html` chỉ chứa DUY NHẤT 2 thay đổi thiết kế theo đúng giả thuyết ban đầu (Mobile 2-line cadence `50px 1fr auto` và Semantic icons `⚠️`, `⏳`, `✓`).
* **F05 (Accessibility, Portability & Conjunction Verdict)**:
  - Đảm bảo toàn bộ mục tiêu chạm tương tác đều $\ge 44\times 44\text{px}$ trên cả màn hình di động (xóa bỏ override 40px).
  - Đo đạc định lượng mức giảm chiều cao cuộn trên mobile: giảm chính xác 470px (từ 2950px xuống 2480px, tương đương -15.93%).
  - Thiết lập công thức phán quyết tổng thể nghiêm ngặt theo phép hội logic conjunction của toàn bộ 14 bài kiểm thử T01–T14 $\to$ **PASS**.

---

### Giai đoạn 5: Đợt Sửa Chữa Cuối 2/2 — Final Repair Round 2/2 (Theo Controller Review 002)

#### 1. R01 — Hoàn tất hồ sơ IA & Bảo toàn tài liệu gốc byte-identical:
* Tích hợp tệp phát hành nguyên gốc `DESIGN_TRAINING_007_DIRECTIVE.md` (SHA-256: `0840d957...`) và `DESIGN_TRAINING_007_REVIEW_001.md` (SHA-256: `f545d0fb...`) lấy trực tiếp qua Chrome CDP download behavior, không reflow hay đổi định dạng.
* Bổ sung bảng ánh xạ đầy đủ 8 dòng T01–T08 cho cả Scheme A (nhóm thời gian) và Scheme B (nhóm workflow), kèm thuộc tính time/owner facet.
* Đính chính dữ liệu nghiệp vụ: Huy chỉ phụ trách T03 và T06; Kịch bản "Đang chuẩn bị" + "Trong 48 giờ" trả về kết quả rỗng (0 tour) chuẩn logic AND; chuẩn hóa các khẳng định hiệu năng thành mô hình đếm thao tác bài tập (benchmark task-step count), loại bỏ suy diễn thành nghiên cứu người dùng (`usability study`).

#### 2. R02 — Focus Preservation và No-Steal Invariant:
* Loại bỏ triệt để native `actionBtn.disabled = true;` trên cả 3 file (`baseline/index.html`, `candidate/pre_critique.html`, `candidate/index.html`).
* Thay thế bằng visual disabled class `.is-saving`, thuộc tính trợ năng `aria-disabled="true"`, và cờ logic `isSavingActive` chặn pointer click và Enter.
* Khắc phục 100% hiện tượng mất focus về `BODY` (`bodyFocusEvents: 0`), giữ `document.activeElement` xuyên suốt: idle $\to$ saving $\to$ error $\to$ retry saving.
* Thực thi kiểm thử **No-Steal**: Trong 800ms saving của retry, chuyển focus sang nút Back (`#btn-back-to-ledger`); khi success hoàn tất, focus được giữ nguyên vẹn tại nút Back, tuyệt đối không bị cướp về nút lưu nhật ký.

#### 3. R03 — Chuẩn hóa Harness Kiểm Thử (`verify_module_007.js`):
* Xóa bỏ hoàn toàn đường dẫn tác giả nội bộ; import chuẩn qua `require('puppeteer-core')`.
* Định nghĩa fixture kỳ vọng độc lập `CANONICAL_FIXTURE` (8 đối tượng) trong harness; so sánh sâu từng trường (`deepEqual`) qua lexical binding.
* Triển khai tương tác thật: `page.click(selector)` cho pointer attempt và `page.keyboard.press('Enter')` cho keyboard attempt.
* Sửa đổi kiểm tra viewport trong T11: dùng `window.scrollTo(0, 0)` tức thì khi mở chi tiết để đảm bảo nút Back hiển thị trong viewport ngay lập tức (`inViewport: true`).
* Sửa đổi độ tương phản CTA trong T12: nâng cấp màu nền nút chính thành `#B45309` (Amber-700) với chữ trắng, đạt tỷ lệ tương phản **5.02:1** (vượt chuẩn AA 4.5:1).
* Đo lường toàn diện 12 cặp màu, vòng focus 16.96:1 (chuẩn non-text 3:1), 22 target sizes $\ge 44\text{px}$, và các thuộc tính trợ năng (`role="status"`, `aria-live="polite"`, `aria-describedby`).
* Thực hiện so sánh parity sâu đối chuẩn (normalized outcome parity) T01–T13 giữa baseline và candidate.

#### 4. R04 — Làm sạch gói nộp và Đồng bộ báo cáo:
* Gói nộp chỉ giữ đúng 12 ảnh bằng chứng authoritative được quy định tại Mục 10 của Review 002.
* Chụp mới toàn bộ ảnh FSM (`candidate_t01_error`, `candidate_t01_retry_saving`, `candidate_t01_success`) và các viewports sau khi áp dụng Common Compliance Patch.
* Tự đánh giá nghiệm thu đạt chuẩn: **`SELF_CHECK_PASS (14/14 PASS)`**.
