# CHANGE LEDGER: DESIGN_TRAINING_007 (TRIPFLOW)

> **Mã nhiệm vụ**: `DESIGN_TRAINING_007`  
> **Chặng**: `FOUNDATION_TRANSFER_CAPSTONE`  
> **Sản phẩm**: `TRIPFLOW — Bảng điều phối tour khởi hành`  
> **Quy chuẩn đối soát**: Khóa mã băm SHA-256 bất biến, ghi nhận toàn bộ bước chuyển giao và tinh chỉnh phản biện.

---

## 🔒 1. Bảng Đối Soát Mã Băm (Source & Hash Ledger)

| Phiên Bản / Tệp | Đường Dẫn Tương Đối | SHA-256 Checksum | Trạng Thái |
| :--- | :--- | :--- | :---: |
| **Baseline** | `baseline/index.html` | `377b4572f62c607c76ac8bad2a771dfe634cb874a0521402005daa518dc75958` | `LOCKED` |
| **Candidate Pre-Critique** | `candidate/pre_critique.html` | `a90bbc8c3440bd8461dce45106e6e84336d2a4932d592e833c2818f86ffd17e2` | `LOCKED` |
| **Candidate Final** | `candidate/index.html` | `5b9672066670df1db8bb5e8dd4ebb051f39d2abd175ed36cc35e6bca4c777913` | `FINAL` |
| **Direction A Specimen** | `directions/option_a.html` | `c6a2dbd5292eb5f91753c15d5ecdd94fb797c23101eb89caefaa9dc90b39679f` | `ACTIVE` |
| **Direction B Specimen** | `directions/option_b.html` | `0b15a63901b0f5b9d3e8e1966a0129c54238e8ecaaecfcadfaeb81d2f00a29ea` | `ACTIVE` |

---

## 📝 2. Lịch Sử Biến Đổi & Quyết Định Kỹ Thuật (Change Log)

### Giai đoạn 1: Baseline $\to$ Candidate Pre-Critique
* **Composition & Visual Hierarchy**:
  - Bổ sung khối tiêu điểm khẩn cấp (`Urgent Focus Module`) cho `T01` (Hạ Long 2N1Đ - khởi hành < 24h, chờ khách sạn) với nút hành động trực tiếp, nhưng bảo toàn đường dẫn và tầm nhìn tới `T02` và toàn bộ danh sách 8 tour.
  - Chuyển đổi từ danh sách thẻ card rời rạc sang **Grouped Container with Hairline Dividers** (Quy tắc `CAPSTONE-003`), tạo cảm giác sổ điều phối hành trình trang nhã, chuyên nghiệp.
* **Information Architecture (IA)**:
  - Chọn **Phương án B (Theo luồng xử lý nghiệp vụ)** làm điều hướng chính: *Tất cả*, *Cần xử lý* (T01, T03, T06), *Trong 48 giờ* (T01, T02), *Sẵn sàng* (T02, T05), *Hoàn thành* (T08).
* **Art Direction**:
  - Hiện thực hóa **Direction A (Dispatch Ledger)**: bảng màu sáng Warm Paper `#FAF9F6`, đường kẻ hairline `#E2E8F0`, typography Sans-serif kết hợp Monospace cho các trường dữ liệu giờ giấc và mã tour.

---

### Giai đoạn 2: Candidate Pre-Critique $\to$ Candidate Final (Vòng Phản Biện - Critique)
* **Kết quả Phản biện (Critique Taxonomy)**:
  - `Strength 1`: Khối điểm nóng T01 tại màn hình đầu giúp định hướng thị giác tức thì. *Quyết định: Giữ nguyên.*
  - `Defect 1`: Trên màn hình di động (< 480px), nút "Chi tiết" bị nhảy xuống chiếm 1 dòng riêng dạng block full-width, làm vỡ nhịp điệu 2 dòng và tăng không gian cuộn lãng phí.
  - `Trade-off 1`: Giữ snippet ghi chú vấn đề trong cột Tour để quét nhanh nguyên nhân mà không cần mở popup.
* **Giả thuyết Sửa (Single Hypothesis)**:
  - *"Nếu tinh chỉnh CSS layout trên mobile (< 480px) để nút Chi tiết neo gọn ở góc trên bên phải dòng dữ liệu và bổ sung biểu tượng icon ngữ nghĩa cho hộp trạng thái FSM, giao diện sẽ đạt nhịp điệu 2 dòng chuẩn mực (`CAPSTONE-002`) và tăng cường tính nhận biết không phụ thuộc màu sắc."*
* **2 Thay đổi Thực tế Đã Áp dụng**:
  1. **Thay đổi 1 (Mobile Cadence)**: Tái cấu trúc grid layout của `.ledger-item` trên mobile trong `candidate/index.html` thành `50px 1fr auto`, cho phép nút Chi tiết neo tại cột 3 trên dòng 1, bảo đảm nhịp điệu 2 dòng gọn gàng.
  2. **Thay đổi 2 (Semantic Live Feedback)**: Tinh chỉnh hộp thông báo trạng thái `status-feedback-box` với icon ngữ nghĩa và kiểu chữ rõ ràng, loại bỏ hoàn toàn sự phụ thuộc màu sắc đơn độc.
* **Quyết định thẩm định**: **`ADOPT`**.

---

### Giai đoạn 3: Khắc phục Tràn Màn Hình Di Động (Mobile Viewport Flex Resolution - T12 Pass)
* **Vấn đề phát hiện**: Khi kiểm thử T12 trên viewport mobile 390×844px, thanh input tìm kiếm và nút "Xoá bộ lọc" trên cùng dòng bị tràn 16px (`scrollWidth: 391px > clientWidth: 375px`) do thuộc tính flexbox mặc định `min-width: auto`.
* **Biện pháp xử lý**:
  1. Thiết lập `min-width: 0` trên `.search-input-field` để triệt tiêu hiện tượng flex blowout.
  2. Chuyển sang bố cục dọc `flex-direction: column` cho hàng tìm kiếm trên màn hình hẹp (< 480px).
* **Kết quả**: `scrollWidth: 375px == clientWidth: 375px`, hoàn toàn không có overflow ngang, T12 chuyển sang `PASS`.
