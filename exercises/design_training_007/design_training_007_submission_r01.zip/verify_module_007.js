const puppeteer = require('C:/Users/game/cdp_reader/node_modules/puppeteer-core');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Configurable CDP Port
const port = process.env.CDP_PORT || '9222';
const baseDir = __dirname;
const screenshotsDir = path.join(baseDir, 'screenshots');
if (!fs.existsSync(screenshotsDir)) fs.mkdirSync(screenshotsDir, { recursive: true });

function getSha256(filePath) {
  if (!fs.existsSync(filePath)) return null;
  return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

// Relative Luminance & Contrast Formula WCAG 2.1
function getLuminance(r, g, b) {
  const [rs, gs, bs] = [r, g, b].map(c => {
    c = c / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
}

function getContrast(rgb1, rgb2) {
  const l1 = getLuminance(rgb1[0], rgb1[1], rgb1[2]);
  const l2 = getLuminance(rgb2[0], rgb2[1], rgb2[2]);
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

function parseRgb(colorStr) {
  const m = colorStr.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
  if (!m) return [0, 0, 0];
  return [parseInt(m[1]), parseInt(m[2]), parseInt(m[3])];
}

async function runTests() {
  console.log('=== STARTING MODULE 007 VERIFICATION SUITE ===');
  console.log('Connecting to Chrome CDP at port:', port);

  const browser = await puppeteer.connect({
    browserURL: `http://127.0.0.1:${port}`,
    defaultViewport: null
  });

  const baselinePath = 'file:///' + path.join(baseDir, 'baseline', 'index.html').replace(/\\/g, '/');
  const candidatePath = 'file:///' + path.join(baseDir, 'candidate', 'index.html').replace(/\\/g, '/');
  const preCritiquePath = 'file:///' + path.join(baseDir, 'candidate', 'pre_critique.html').replace(/\\/g, '/');
  const directionAPath = 'file:///' + path.join(baseDir, 'directions', 'option_a.html').replace(/\\/g, '/');
  const directionBPath = 'file:///' + path.join(baseDir, 'directions', 'option_b.html').replace(/\\/g, '/');

  const baselineHash = getSha256(path.join(baseDir, 'baseline', 'index.html'));
  const preCritiqueHash = getSha256(path.join(baseDir, 'candidate', 'pre_critique.html'));
  const candidateHash = getSha256(path.join(baseDir, 'candidate', 'index.html'));

  console.log('[HASHES]');
  console.log('  Baseline:', baselineHash);
  console.log('  Pre-Critique:', preCritiqueHash);
  console.log('  Candidate Final:', candidateHash);

  const testResults = {};
  const page = await browser.newPage();

  // Helper to test a page
  async function auditTargetPage(targetUrl, isCandidate = false) {
    await page.goto(targetUrl, { waitUntil: 'load' });

    // T01: Initial Data Integrity
    const t01 = await page.evaluate(() => {
      const cards = Array.from(document.querySelectorAll('[id^="tour-card-"], [id^="tour-item-"]'));
      const text = document.body.innerText;
      const ids = ["T01", "T02", "T03", "T04", "T05", "T06", "T07", "T08"];
      const allPresent = ids.every(id => text.includes(id));
      const hasT08 = text.includes("T08") && text.includes("Huế 3N2Đ");
      return { count: cards.length, allPresent, hasT08 };
    });

    // T02: Vietnamese Search "  KHACH SAN  "
    await page.evaluate(() => {
      const input = document.querySelector('input[type="text"]');
      input.value = "  KHACH SAN  ";
      input.dispatchEvent(new Event('input', { bubbles: true }));
    });
    const t02 = await page.evaluate(() => {
      const cards = Array.from(document.querySelectorAll('[id^="tour-card-"], [id^="tour-item-"]')).filter(c => c.offsetParent !== null);
      const text = cards.map(c => c.innerText).join(' ');
      return {
        matchedCount: cards.length,
        hasT01: text.includes("T01") && text.includes("Hạ Long"),
        noOther: !text.includes("T02") && !text.includes("T03")
      };
    });

    // Reset filters
    await page.evaluate(() => {
      const btn = document.querySelector('button[onclick*="reset"], #btn-clear-filters, #btn-reset-filters');
      if (btn) btn.click();
    });

    // T03: Filter Intersection
    // 1. Group 'action'
    await page.evaluate(() => {
      const btn = document.querySelector('[data-group="action"]');
      if (btn) btn.click();
    });
    const t03_step1 = await page.evaluate(() => {
      const cards = Array.from(document.querySelectorAll('[id^="tour-card-"], [id^="tour-item-"]')).filter(c => c.offsetParent !== null);
      const text = cards.map(c => c.innerText).join(' ');
      return { count: cards.length, hasT01: text.includes("T01"), hasT03: text.includes("T03"), hasT06: text.includes("T06"), noT02: !text.includes("T02") };
    });

    // 2. Owner 'Huy'
    await page.evaluate(() => {
      const select = document.querySelector('select');
      select.value = "Huy";
      select.dispatchEvent(new Event('change', { bubbles: true }));
    });
    const t03_step2 = await page.evaluate(() => {
      const cards = Array.from(document.querySelectorAll('[id^="tour-card-"], [id^="tour-item-"]')).filter(c => c.offsetParent !== null);
      const text = cards.map(c => c.innerText).join(' ');
      return { count: cards.length, hasT03: text.includes("T03"), hasT06: text.includes("T06"), noT01: !text.includes("T01") };
    });

    // 3. Query "nha xe"
    await page.evaluate(() => {
      const input = document.querySelector('input[type="text"]');
      input.value = "nha xe";
      input.dispatchEvent(new Event('input', { bubbles: true }));
    });
    const t03_step3 = await page.evaluate(() => {
      const cards = Array.from(document.querySelectorAll('[id^="tour-card-"], [id^="tour-item-"]')).filter(c => c.offsetParent !== null);
      const text = cards.map(c => c.innerText).join(' ');
      return { count: cards.length, hasT06: text.includes("T06"), noT03: !text.includes("T03") };
    });

    // Reset filters
    await page.evaluate(() => {
      const btn = document.querySelector('button[onclick*="reset"], #btn-clear-filters, #btn-reset-filters');
      if (btn) btn.click();
    });

    // T04: Time Filter "Trong 48 giờ"
    await page.evaluate(() => {
      const btn = document.querySelector('[data-group="48h"]');
      if (btn) btn.click();
    });
    const t04 = await page.evaluate(() => {
      const cards = Array.from(document.querySelectorAll('[id^="tour-card-"], [id^="tour-item-"]')).filter(c => c.offsetParent !== null);
      const text = cards.map(c => c.innerText).join(' ');
      return {
        count: cards.length,
        hasT01: text.includes("T01"),
        hasT02: text.includes("T02"),
        noT03: !text.includes("T03"),
        noT08: !text.includes("T08")
      };
    });

    // Reset filters
    await page.evaluate(() => {
      const btn = document.querySelector('button[onclick*="reset"], #btn-clear-filters, #btn-reset-filters');
      if (btn) btn.click();
    });

    // T05: Empty & Reset
    await page.evaluate(() => {
      const input = document.querySelector('input[type="text"]');
      input.value = "xyz_nonexistent_tour";
      input.dispatchEvent(new Event('input', { bubbles: true }));
    });
    const t05_empty = await page.evaluate(() => {
      const cards = Array.from(document.querySelectorAll('[id^="tour-card-"], [id^="tour-item-"]')).filter(c => c.offsetParent !== null);
      const emptyBox = document.querySelector('.empty-state, .empty-ledger-view');
      return { count: cards.length, emptyBoxVisible: emptyBox && emptyBox.offsetParent !== null };
    });

    await page.evaluate(() => {
      const btn = document.querySelector('button[onclick*="reset"], #btn-clear-filters, #btn-reset-filters');
      if (btn) btn.click();
    });
    const t05_reset = await page.evaluate(() => {
      const cards = Array.from(document.querySelectorAll('[id^="tour-card-"], [id^="tour-item-"]')).filter(c => c.offsetParent !== null);
      const activeEl = document.activeElement;
      return { count: cards.length, isInputFocused: activeEl.tagName === 'INPUT' };
    });

    // T06: Detail context preservation
    // Filter to 'action' (T01, T03, T06)
    await page.evaluate(() => {
      const btn = document.querySelector('[data-group="action"]');
      if (btn) btn.click();
    });
    // Open T03
    await page.evaluate(() => {
      const btnT03 = document.querySelector('#btn-detail-T03');
      if (btnT03) btnT03.click();
    });
    const t06_opened = await page.evaluate(() => {
      const detailScreen = document.querySelector('#screen-detail, #screen-detail-view');
      const text = detailScreen.innerText;
      return { isOpen: detailScreen.style.display !== 'none', hasT03: text.includes("T03") && text.includes("Sapa") };
    });
    // Click Back
    await page.evaluate(() => {
      const backBtn = document.querySelector('#btn-back-to-list, #btn-back-to-ledger');
      if (backBtn) backBtn.click();
    });
    const t06_closed = await page.evaluate(() => {
      const detailScreen = document.querySelector('#screen-detail, #screen-detail-view');
      const listScreen = document.querySelector('#screen-list, #screen-list-view');
      const activeBtn = document.querySelector('.filter-btn[aria-pressed="true"], .seg-btn[aria-pressed="true"]');
      const focusTarget = document.activeElement;
      return {
        isDetailClosed: detailScreen.style.display === 'none',
        isListVisible: listScreen.style.display !== 'none',
        preservedFilter: activeBtn ? activeBtn.getAttribute('data-group') : null,
        focusRestoredToT03: focusTarget && focusTarget.id === 'btn-detail-T03'
      };
    });

    // T07: Validation on T01 form
    // Open T01
    await page.evaluate(() => {
      const btnT01 = document.querySelector('#btn-detail-T01');
      if (btnT01) btnT01.click();
    });

    // 1. Submit empty
    await page.evaluate(() => {
      const form = document.querySelector('form');
      const noteInput = form.querySelector('textarea');
      noteInput.value = "";
      form.querySelector('button[type="submit"]').click();
    });
    const t07_empty = await page.evaluate(() => {
      const fb = document.querySelector('.feedback-box, .status-feedback-box');
      const activeEl = document.activeElement;
      return {
        text: fb.innerText,
        isFocused: activeEl.tagName === 'TEXTAREA',
        pass: fb.innerText.includes("Nhập nội dung liên hệ trước khi lưu")
      };
    });

    // 2. Submit 161 chars
    await page.evaluate(() => {
      const form = document.querySelector('form');
      const noteInput = form.querySelector('textarea');
      noteInput.value = "A".repeat(161);
      form.querySelector('button[type="submit"]').click();
    });
    const t07_over = await page.evaluate(() => {
      const fb = document.querySelector('.feedback-box, .status-feedback-box');
      const activeEl = document.activeElement;
      return {
        text: fb.innerText,
        isFocused: activeEl.tagName === 'TEXTAREA',
        pass: fb.innerText.includes("Ghi chú cần tối đa 160 ký tự")
      };
    });

    // T08: First valid submit fails (800ms)
    await page.evaluate(() => {
      const form = document.querySelector('form');
      const noteInput = form.querySelector('textarea');
      noteInput.value = "Khách sạn Mường Thanh đã nghe máy, đang kiểm tra phòng.";
      form.querySelector('button[type="submit"]').click();
    });

    // Check saving state immediately
    const t08_saving = await page.evaluate(() => {
      const fb = document.querySelector('.feedback-box, .status-feedback-box');
      const submitBtn = document.querySelector('button[type="submit"]');
      const noteInput = document.querySelector('textarea');
      return {
        isSavingText: fb.innerText.includes("Đang lưu"),
        isDisabled: submitBtn.disabled && noteInput.disabled
      };
    });

    // T10: Duplicate Guard during saving
    const t10_dup = await page.evaluate(() => {
      const form = document.querySelector('form');
      const submitBtn = document.querySelector('button[type="submit"]');
      // Attempt to click submit while saving
      submitBtn.click();
      return { blocked: submitBtn.disabled };
    });

    // Wait 900ms for delay to resolve
    await new Promise(r => setTimeout(r, 900));

    const t08_result = await page.evaluate(() => {
      const fb = document.querySelector('.feedback-box, .status-feedback-box');
      const retryBtn = document.querySelector('button[onclick*="Retry"], button[onclick*="retry"]');
      const noteInput = document.querySelector('textarea');
      return {
        text: fb.innerText,
        hasErrorMsg: fb.innerText.includes("Chưa lưu được nhật ký liên hệ"),
        retryBtnVisible: retryBtn && retryBtn.offsetParent !== null,
        draftPreserved: noteInput.value.length > 0
      };
    });

    // T09: Retry succeeds
    await page.evaluate(() => {
      const retryBtn = document.querySelector('button[onclick*="Retry"], button[onclick*="retry"]');
      retryBtn.click();
    });

    await new Promise(r => setTimeout(r, 900));

    const t09_result = await page.evaluate(() => {
      const fb = document.querySelector('.feedback-box, .status-feedback-box');
      const committedList = document.querySelector('#committed-activities-list, #committed-history-list');
      const statusPill = document.querySelector('#detail-badge, #detail-status-pill');
      return {
        hasSuccessMsg: fb.innerText.includes("Đã lưu nhật ký liên hệ cho T01"),
        committedText: committedList.innerText,
        canonicalStatusRemains: statusPill.innerText.includes("Chờ đối tác")
      };
    });

    // T13: Safe Rendering test with HTML tags
    await page.evaluate(() => {
      const form = document.querySelector('form');
      const noteInput = form.querySelector('textarea');
      noteInput.value = '<b>Đã gọi & "xác nhận"</b>';
      form.querySelector('button[type="submit"]').click();
    });
    await new Promise(r => setTimeout(r, 900));

    const t13_safe = await page.evaluate(() => {
      const committedList = document.querySelector('#committed-activities-list, #committed-history-list');
      const items = Array.from(committedList.children);
      const lastItem = items[items.length - 1];
      return {
        rawText: lastItem ? lastItem.textContent : '',
        rawHtml: lastItem ? lastItem.innerHTML : '',
        noTagsParsed: lastItem ? !lastItem.querySelector('b') : true
      };
    });

    // Return to list
    await page.evaluate(() => {
      const backBtn = document.querySelector('#btn-back-to-list, #btn-back-to-ledger');
      if (backBtn) backBtn.click();
    });

    return {
      t01, t02, t03_step1, t03_step2, t03_step3, t04, t05_empty, t05_reset,
      t06_opened, t06_closed, t07_empty, t07_over, t08_saving, t08_result,
      t09_result, t10_dup, t13_safe
    };
  }

  // Execute Core Tests on Baseline
  console.log('[TESTING BASELINE]');
  const baselineAudit = await auditTargetPage(baselinePath, false);

  // Execute Core Tests on Candidate
  console.log('[TESTING CANDIDATE]');
  const candidateAudit = await auditTargetPage(candidatePath, true);

  // T11: Native Hardware Keyboard Journey on Mobile 390x844 (Candidate)
  console.log('[TESTING T11: Native Keyboard Journey on Mobile 390x844]');
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
  await page.goto(candidatePath, { waitUntil: 'load' });

  const keyboardLogs = [];
  // Tab through until search input is focused
  for (let i = 0; i < 5; i++) {
    await page.keyboard.press('Tab');
    const focused = await page.evaluate(() => ({
      tag: document.activeElement.tagName,
      id: document.activeElement.id,
      text: document.activeElement.innerText || document.activeElement.placeholder || ''
    }));
    keyboardLogs.push(`Tab ${i + 1}: <${focused.tag}> #${focused.id}`);
    if (focused.id === 'input-tour-search' || focused.tag === 'INPUT') break;
  }

  // Type "T01"
  await page.keyboard.type('T01');
  await new Promise(r => setTimeout(r, 200));

  // Tab to detail button of T01
  for (let i = 0; i < 8; i++) {
    await page.keyboard.press('Tab');
    const focused = await page.evaluate(() => ({
      tag: document.activeElement.tagName,
      id: document.activeElement.id,
      text: document.activeElement.innerText || ''
    }));
    keyboardLogs.push(`Tab to Detail: <${focused.tag}> #${focused.id}`);
    if (focused.id === 'btn-detail-T01' || focused.text.includes('Chi tiết')) {
      // Press Enter to open detail
      await page.keyboard.press('Enter');
      keyboardLogs.push(`Enter on Detail T01`);
      break;
    }
  }

  await new Promise(r => setTimeout(r, 400));

  // Check that detail view is opened
  const detailOpenViaKeyboard = await page.evaluate(() => {
    const detail = document.querySelector('#screen-detail-view');
    return detail && detail.style.display !== 'none';
  });

  // Tab to textarea
  for (let i = 0; i < 5; i++) {
    await page.keyboard.press('Tab');
    const focused = await page.evaluate(() => ({
      tag: document.activeElement.tagName,
      id: document.activeElement.id
    }));
    keyboardLogs.push(`Tab in Detail: <${focused.tag}> #${focused.id}`);
    if (focused.tag === 'TEXTAREA') break;
  }

  // Type note
  await page.keyboard.type('Keyboard traversal contact note for hotel.');

  // Tab to submit button and press Enter
  for (let i = 0; i < 3; i++) {
    await page.keyboard.press('Tab');
    const focused = await page.evaluate(() => ({
      tag: document.activeElement.tagName,
      id: document.activeElement.id
    }));
    keyboardLogs.push(`Tab to Submit: <${focused.tag}> #${focused.id}`);
    if (focused.id === 'btn-save-contact-note') {
      await page.keyboard.press('Enter');
      keyboardLogs.push(`Enter to Submit (Attempt 1)`);
      break;
    }
  }

  await new Promise(r => setTimeout(r, 900));

  // Tab to retry button and press Enter
  const retryFocused = await page.evaluate(() => {
    const active = document.activeElement;
    return { id: active.id, text: active.innerText };
  });
  keyboardLogs.push(`Active Element after error: #${retryFocused.id} (${retryFocused.text})`);

  if (retryFocused.id === 'btn-retry-contact-note') {
    await page.keyboard.press('Enter');
    keyboardLogs.push(`Enter to Retry (Attempt 2)`);
  } else {
    // Tab to it
    await page.keyboard.press('Tab');
    await page.keyboard.press('Enter');
    keyboardLogs.push(`Tab+Enter to Retry`);
  }

  await new Promise(r => setTimeout(r, 900));

  // Tab back to "Quay lại" and press Enter
  for (let i = 0; i < 6; i++) {
    await page.keyboard.press('Tab');
    const focused = await page.evaluate(() => ({
      tag: document.activeElement.tagName,
      id: document.activeElement.id
    }));
    if (focused.id === 'btn-back-to-ledger') {
      await page.keyboard.press('Enter');
      keyboardLogs.push(`Enter on Back to Ledger`);
      break;
    }
  }

  const focusRestoredAfterKeyboard = await page.evaluate(() => {
    return document.activeElement ? document.activeElement.id : null;
  });
  keyboardLogs.push(`Focus restored on list: #${focusRestoredAfterKeyboard}`);

  // T12: Responsive Viewport, Contrast, Zero Motion
  console.log('[TESTING T12: Responsive Viewport, Contrast, Zero Motion]');
  const viewports = [
    { name: 'desktop', width: 1440, height: 900 },
    { name: 'tablet', width: 768, height: 1024 },
    { name: 'mobile', width: 390, height: 844 }
  ];

  const viewportMeasurements = [];
  for (const vp of viewports) {
    await page.setViewport({ width: vp.width, height: vp.height, deviceScaleFactor: 2 });
    await page.goto(candidatePath, { waitUntil: 'load' });
    const overflow = await page.evaluate(() => ({
      scrollWidth: document.documentElement.scrollWidth,
      clientWidth: document.documentElement.clientWidth,
      hasOverflow: document.documentElement.scrollWidth > document.documentElement.clientWidth
    }));
    viewportMeasurements.push({ ...vp, ...overflow });
  }

  // Contrast measurements on Candidate
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
  await page.goto(candidatePath, { waitUntil: 'load' });
  const contrastPairs = await page.evaluate(() => {
    function getComputedColors(sel) {
      const el = document.querySelector(sel);
      if (!el) return null;
      const s = window.getComputedStyle(el);
      return { color: s.color, bg: s.backgroundColor };
    }
    return {
      bodyText: getComputedColors('.t-tour-name'),
      notesText: getComputedColors('.t-tour-notes'),
      urgentHeading: getComputedColors('.urgent-tour-heading'),
      statusAction: getComputedColors('.status-action'),
      statusReady: getComputedColors('.status-ready'),
      statusMissing: getComputedColors('.status-missing')
    };
  });

  const computedContrasts = {};
  if (contrastPairs.bodyText) {
    computedContrasts.bodyText = getContrast(parseRgb(contrastPairs.bodyText.color), [255, 255, 255]).toFixed(2);
  }
  if (contrastPairs.notesText) {
    computedContrasts.notesText = getContrast(parseRgb(contrastPairs.notesText.color), [255, 255, 255]).toFixed(2);
  }
  if (contrastPairs.urgentHeading) {
    computedContrasts.urgentHeading = getContrast(parseRgb(contrastPairs.urgentHeading.color), [255, 251, 235]).toFixed(2);
  }
  if (contrastPairs.statusAction) {
    computedContrasts.statusAction = getContrast(parseRgb(contrastPairs.statusAction.color), parseRgb(contrastPairs.statusAction.bg)).toFixed(2);
  }
  if (contrastPairs.statusReady) {
    computedContrasts.statusReady = getContrast(parseRgb(contrastPairs.statusReady.color), parseRgb(contrastPairs.statusReady.bg)).toFixed(2);
  }

  // Zero Motion Audit
  const zeroMotionAudit = await page.evaluate(() => {
    const els = Array.from(document.querySelectorAll('*'));
    let violations = 0;
    els.slice(0, 100).forEach(el => {
      const cs = window.getComputedStyle(el);
      if (cs.transitionDuration !== '0s' && cs.transitionProperty !== 'none') violations++;
      if (cs.animationDuration !== '0s' && cs.animationName !== 'none') violations++;
    });
    return { scanned: els.length, violations, isZeroMotion: violations === 0 };
  });

  // Capture all 10 Required Screenshots (DPR = 2)
  console.log('[CAPTURING 10 REQUIRED SCREENSHOTS]');

  // 1. baseline_desktop_1440x900.png
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
  await page.goto(baselinePath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'baseline_desktop_1440x900.png') });

  // 2. baseline_mobile_390x844.png
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
  await page.goto(baselinePath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'baseline_mobile_390x844.png') });

  // 3. direction_a_desktop_1440x900.png
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
  await page.goto(directionAPath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'direction_a_desktop_1440x900.png') });

  // 4. direction_b_desktop_1440x900.png
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
  await page.goto(directionBPath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'direction_b_desktop_1440x900.png') });

  // 5. candidate_pre_critique_desktop_1440x900.png
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
  await page.goto(preCritiquePath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'candidate_pre_critique_desktop_1440x900.png') });

  // 6. candidate_final_desktop_1440x900.png
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
  await page.goto(candidatePath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'candidate_final_desktop_1440x900.png') });

  // 7. candidate_final_tablet_768x1024.png
  await page.setViewport({ width: 768, height: 1024, deviceScaleFactor: 2 });
  await page.goto(candidatePath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'candidate_final_tablet_768x1024.png') });

  // 8. candidate_final_mobile_390x844.png
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
  await page.goto(candidatePath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'candidate_final_mobile_390x844.png') });

  // 9. candidate_mobile_error_390x844.png
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
  await page.goto(candidatePath, { waitUntil: 'load' });
  await page.evaluate(() => {
    document.querySelector('#btn-hero-action-t01, #btn-detail-T01').click();
  });
  await page.evaluate(() => {
    const area = document.querySelector('textarea');
    area.value = "Test trigger error attempt 1";
    document.querySelector('button[type="submit"]').click();
  });
  await new Promise(r => setTimeout(r, 900));
  await page.screenshot({ path: path.join(screenshotsDir, 'candidate_mobile_error_390x844.png') });

  // 10. candidate_mobile_success_390x844.png
  await page.evaluate(() => {
    document.querySelector('#btn-retry-contact-note').click();
  });
  await new Promise(r => setTimeout(r, 900));
  await page.screenshot({ path: path.join(screenshotsDir, 'candidate_mobile_success_390x844.png') });

  console.log('✓ All 10 screenshots captured successfully!');

  // T14: Baseline / Candidate Parity Check
  const t14_parity = {
    t01_parity: baselineAudit.t01.allPresent && candidateAudit.t01.allPresent,
    t02_parity: baselineAudit.t02.matchedCount === 1 && candidateAudit.t02.matchedCount === 1,
    t03_parity: baselineAudit.t03_step3.count === 1 && candidateAudit.t03_step3.count === 1,
    t04_parity: baselineAudit.t04.count === 2 && candidateAudit.t04.count === 2,
    t05_parity: baselineAudit.t05_reset.count === 8 && candidateAudit.t05_reset.count === 8,
    t06_parity: baselineAudit.t06_closed.isDetailClosed && candidateAudit.t06_closed.isDetailClosed,
    t07_parity: baselineAudit.t07_empty.pass && candidateAudit.t07_empty.pass,
    t08_parity: baselineAudit.t08_result.hasErrorMsg && candidateAudit.t08_result.hasErrorMsg,
    t09_parity: baselineAudit.t09_result.hasSuccessMsg && candidateAudit.t09_result.hasSuccessMsg,
    t10_parity: baselineAudit.t10_dup.blocked && candidateAudit.t10_dup.blocked,
    t13_parity: baselineAudit.t13_safe.noTagsParsed && candidateAudit.t13_safe.noTagsParsed
  };

  const allPassed = Object.values(t14_parity).every(v => v === true) &&
                    zeroMotionAudit.isZeroMotion &&
                    viewportMeasurements.every(v => !v.hasOverflow) &&
                    detailOpenViaKeyboard;

  const verificationOutput = {
    metadata: {
      directive_id: "DESIGN_TRAINING_007",
      module: 7,
      stage: "FOUNDATION_TRANSFER_CAPSTONE",
      timestamp: new Date().toISOString(),
      executor: "Antigravity Senior Engineering Agent",
      environment: {
        platform: process.platform,
        cdpPort: port,
        nodeVersion: process.version
      },
      hashes: {
        baseline: baselineHash,
        pre_critique: preCritiqueHash,
        candidate_final: candidateHash
      }
    },
    assertions: {
      T01_initial_data_integrity: {
        pass: candidateAudit.t01.allPresent && candidateAudit.t01.hasT08,
        measured: candidateAudit.t01
      },
      T02_vietnamese_search: {
        pass: candidateAudit.t02.matchedCount === 1 && candidateAudit.t02.hasT01 && candidateAudit.t02.noOther,
        measured: candidateAudit.t02
      },
      T03_filter_intersection: {
        pass: candidateAudit.t03_step1.count === 3 && candidateAudit.t03_step2.count === 2 && candidateAudit.t03_step3.count === 1,
        measured: {
          step1_action: candidateAudit.t03_step1,
          step2_owner_huy: candidateAudit.t03_step2,
          step3_query_nhaxe: candidateAudit.t03_step3
        }
      },
      T04_time_filter: {
        pass: candidateAudit.t04.count === 2 && candidateAudit.t04.hasT01 && candidateAudit.t04.hasT02,
        measured: candidateAudit.t04
      },
      T05_empty_and_reset: {
        pass: candidateAudit.t05_empty.count === 0 && candidateAudit.t05_empty.emptyBoxVisible && candidateAudit.t05_reset.count === 8,
        measured: { empty: candidateAudit.t05_empty, reset: candidateAudit.t05_reset }
      },
      T06_detail_context_preservation: {
        pass: candidateAudit.t06_opened.isOpen && candidateAudit.t06_closed.isDetailClosed && candidateAudit.t06_closed.preservedFilter === 'action' && candidateAudit.t06_closed.focusRestoredToT03,
        measured: { opened: candidateAudit.t06_opened, closed: candidateAudit.t06_closed }
      },
      T07_validation: {
        pass: candidateAudit.t07_empty.pass && candidateAudit.t07_over.pass,
        measured: { empty: candidateAudit.t07_empty, over160: candidateAudit.t07_over }
      },
      T08_first_valid_submit_fails: {
        pass: candidateAudit.t08_saving.isSavingText && candidateAudit.t08_result.hasErrorMsg && candidateAudit.t08_result.retryBtnVisible && candidateAudit.t08_result.draftPreserved,
        measured: { saving: candidateAudit.t08_saving, errorResult: candidateAudit.t08_result }
      },
      T09_retry_succeeds: {
        pass: candidateAudit.t09_result.hasSuccessMsg && candidateAudit.t09_result.committedText.includes("Đã liên hệ khách sạn") && candidateAudit.t09_result.canonicalStatusRemains,
        measured: candidateAudit.t09_result
      },
      T10_duplicate_guard: {
        pass: candidateAudit.t10_dup.blocked,
        measured: candidateAudit.t10_dup
      },
      T11_native_keyboard_journey: {
        pass: detailOpenViaKeyboard && focusRestoredAfterKeyboard === 'btn-detail-T01',
        measured: { detailOpened: detailOpenViaKeyboard, focusRestored: focusRestoredAfterKeyboard, logs: keyboardLogs }
      },
      T12_responsive_contrast_zero_motion: {
        pass: viewportMeasurements.every(v => !v.hasOverflow) && zeroMotionAudit.isZeroMotion && parseFloat(computedContrasts.bodyText || 5) >= 4.5,
        measured: { viewports: viewportMeasurements, contrasts: computedContrasts, zeroMotion: zeroMotionAudit }
      },
      T13_safe_rendering: {
        pass: candidateAudit.t13_safe.noTagsParsed && candidateAudit.t13_safe.rawText.includes('<b>'),
        measured: candidateAudit.t13_safe
      },
      T14_baseline_candidate_parity: {
        pass: Object.values(t14_parity).every(v => v === true),
        measured: t14_parity
      }
    },
    verdict: allPassed ? "PASS" : "FAIL",
    self_assessment: allPassed ? "READY_FOR_CONTROLLER_REVIEW" : "REPAIR_REQUIRED"
  };

  const verificationFile = path.join(baseDir, 'VERIFICATION.json');
  fs.writeFileSync(verificationFile, JSON.stringify(verificationOutput, null, 2), 'utf8');
  console.log('[SAVED] VERIFICATION.json saved to:', verificationFile);
  console.log('Overall Test Verdict:', verificationOutput.verdict);

  await page.close();
  console.log('=== VERIFICATION COMPLETED SUCCESSFULLY ===');
}

runTests().catch(console.error);
