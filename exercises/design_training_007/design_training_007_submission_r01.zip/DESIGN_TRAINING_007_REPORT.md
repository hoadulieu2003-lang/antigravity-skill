# BÁO CÁO NGHIỆM THU: DESIGN_TRAINING_007 (TRANSFER CAPSTONE)

> **Mã chỉ thị**: `DESIGN_TRAINING_007`  
> **Chặng**: `FOUNDATION_TRANSFER_CAPSTONE`  
> **Sản phẩm**: `TRIPFLOW — Bảng điều phối tour khởi hành`  
> **Thực thi**: Antigravity Senior Engineering Agent  
> **Thời điểm**: 13/09/2026 21:58:00 ICT  
> **Môi trường**: Windows 11, Node v24.18.0, Chrome CDP port 9222  

---

## 1. Executive Summary (Tóm Tắt Điều Hành)
Bài thi kiểm tra chuyển giao năng lực thiết kế (`Transfer Testing`) **DESIGN_TRAINING_007** được tiến hành trên một đề bài và ngữ cảnh nghiệp vụ hoàn toàn mới: hệ thống điều phối tour khởi hành **TRIPFLOW** dành cho nhà điều hành lữ hành vừa và nhỏ (SMB tour operator), giải quyết điểm nghẽn điều phối tại mốc giờ chuẩn `18:00 13/09/2026 ICT`.

Hệ thống đã hoàn tất đầy đủ 8 Cổng chất lượng (`G01–G08`) và vượt qua 14 kịch bản kiểm thử khóa cứng (`T01–T14`), đáp ứng nghiêm ngặt các bất biến hệ thống:
* **Anti-Copy Invariant**: DNA thiết kế hoàn toàn mới, không sao chép cấu trúc hero chia đôi hay phong cách của dự án TRACE trước đó;
* **Mandatory Light Theme Default Invariant**: 100% giao diện sáng (`Light Theme`) trang nhã với sắc giấy ấm `Warm Paper (#FAF9F6)`;
* **Zero Motion Invariant**: Khóa chết `transition: none !important` và `animation: none !important`;
* **Self-contained Vanilla Stack**: Thuần HTML5/CSS3/ES6 không thư viện ngoài hay CDN, hoạt động offline 100%.

---

## 2. Source and Hash Ledger (Bảng Đối Soát Mã Nguồn & Băm SHA-256)

| Tệp / Phiên Bản | Đường Dẫn Tương Đối | SHA-256 Checksum | Trạng Thái |
| :--- | :--- | :--- | :---: |
| **Baseline** | `baseline/index.html` | `377b4572f62c607c76ac8bad2a771dfe634cb874a0521402005daa518dc75958` | `LOCKED` |
| **Candidate Pre-Critique** | `candidate/pre_critique.html` | `a90bbc8c3440bd8461dce45106e6e84336d2a4932d592e833c2818f86ffd17e2` | `LOCKED` |
| **Candidate Final** | `candidate/index.html` | `5b9672066670df1db8bb5e8dd4ebb051f39d2abd175ed36cc35e6bca4c777913` | `FINAL` |
| **Direction A Specimen** | `directions/option_a.html` | `c6a2dbd5292eb5f91753c15d5ecdd94fb797c23101eb89caefaa9dc90b39679f` | `VERIFIED` |
| **Direction B Specimen** | `directions/option_b.html` | `0b15a63901b0f5b9d3e8e1966a0129c54238e8ecaaecfcadfaeb81d2f00a29ea` | `VERIFIED` |
| **Design Contract** | `DESIGN_CONTRACT.yaml` | `[Structured Specification]` | `ACTIVE` |
| **Verification Ledger** | `VERIFICATION.json` | `[Automated Evidence Report]` | `PASS` |

---

## 3. Canonical Data Confirmation (Xác Nhận Dữ Liệu Chuẩn Mực)
Toàn bộ 8 tour xuất phát được ánh xạ đầy đủ theo chuẩn mốc quy chiếu `18:00 13/09/2026 ICT`:
1. `T01` — Hạ Long 2N1Đ (Khởi hành: 14/09 07:30, < 24h, Phụ trách: Lan, Trạng thái: Chờ đối tác, Ghi chú: Chờ khách sạn xác nhận phòng 204)
2. `T02` — Ninh Bình 1N (Khởi hành: 15/09 08:00, < 48h, Phụ trách: Huy, Trạng thái: Sẵn sàng, Ghi chú: Đã chốt danh sách đoàn 16 khách)
3. `T03` — Sapa 3N2Đ (Khởi hành: 16/09 21:00, Phụ trách: Huy, Trạng thái: Thiếu thông tin, Ghi chú: Thiếu CCCD 2 khách cuối)
4. `T04` — Đà Nẵng - Hội An 4N3Đ (Khởi hành: 17/09 06:00, Phụ trách: Lan, Trạng thái: Đang chuẩn bị, Ghi chú: Đã đặt vé máy bay, chờ HDV nhận tour)
5. `T05` — Huế Di Sản 3N2Đ (Khởi hành: 18/09 08:30, Phụ trách: Huy, Trạng thái: Sẵn sàng, Ghi chú: Đầy đủ dịch vụ và bảo hiểm)
6. `T06` — Mộc Châu Mùa Hoa 2N1Đ (Khởi hành: 19/09 06:30, Phụ trách: Huy, Trạng thái: Chờ đối tác, Ghi chú: Chờ nhà xe chốt biển số xe 29B)
7. `T07` — Cát Bà 2N1Đ (Khởi hành: 20/09 07:00, Phụ trách: Lan, Trạng thái: Đang chuẩn bị, Ghi chú: Chờ phà Tuần Châu trả lời chuyến 8h)
8. `T08` — Hà Giang Mùa Lúa 3N2Đ (Khởi hành: 12/09 05:30, Tour đã đi về, Phụ trách: Huy, Trạng thái: Hoàn thành, Ghi chú: Quyết toán đoàn 12 khách xong)

*Bảo đảm dữ liệu gốc:* Tuyệt đối không làm mất `T08` ở màn hình ban đầu; Candidate hiển thị khối tiêu điểm T01 nhưng duy trì lối dẫn rõ ràng tới toàn bộ 8 bản ghi.

---

## 4. IA Comparison and Decision (So Sánh & Quyết Định Cấu Trúc Thông Tin)
Đã khảo sát và thử nghiệm 2 phương án cấu trúc thông tin (IA):
* **Phương án A — Theo mốc thời gian khởi hành**:
  * Nhóm: *Hôm nay / < 24h*, *Trong 48 giờ*, *Tuần này*, *Lịch sử hoàn thành*.
  * *Hạn chế:* Người điều phối phải lướt qua nhiều nhóm thời gian để tìm tour đang gặp trục trặc kỹ thuật hoặc thiếu đối tác.
* **Phương án B (ĐƯỢC CHỌN) — Theo luồng xử lý nghiệp vụ (`Task-Oriented Dispatch Flow`)**:
  * Nhóm bộ lọc tương tác:
    * `Tất cả` (8 tour)
    * `Cần xử lý` (3 tour: `T01, T03, T06` — Chờ đối tác & Thiếu thông tin)
    * `Trong 48 giờ` (2 tour: `T01, T02` — Tính toán theo mốc quy chiếu 18:00 13/09)
    * `Sẵn sàng` (2 tour: `T02, T05`)
    * `Đã hoàn thành` (1 tour: `T08`)
  * *Lý do chọn:* Tối ưu hóa triệt để hiệu suất công việc của Điều hành viên (Dispatch Operator), cho phép cô lập ngay lập tức các tour có nguy cơ đổ vỡ trong ngày trước khi xử lý các tour khởi hành xa.

---

## 5. Art Direction A/B and Decision (Định Hướng Mỹ Thuật & Đánh Đổi)
Đã thiết kế 2 phương án mỹ thuật độc lập:
* **Hướng A — Dispatch Ledger (Sổ Điều Phối Hành Trình) — ĐÃ CHỌN**:
  * *Thẩm mỹ:* Cảm hứng sổ cái điều phối hành chính cao cấp, nền giấy ấm `Warm Paper (#FAF9F6)`, đường kẻ tóc hairline `1px solid #E2E8F0`, chữ đen than `Obsidian (#0F172A)`, điểm nhấn hổ phách `Terracotta Amber (#D97706)` cho tour khẩn cấp `T01`.
  * *Điểm đánh đổi 1:* Mật độ thông tin cao hơn (Compact ledger cadence) đòi hỏi kiểm soát chặt chẽ nhịp điệu 2 dòng trên thiết bị di động.
  * *Điểm đánh đổi 2:* Cần bố trí nhãn nhịp điệu cột rõ ràng để tránh hiểu nhầm giữa giờ khởi hành và giờ quy chiếu.
* **Hướng B — Departure Board (Bảng Ga Khởi Hành)**:
  * *Thẩm mỹ:* Lấy cảm hứng bảng thông tin nhà ga sân bay hiện đại nhưng chạy trên nền sáng, typography đậm, tương phản khối cao.
  * *Lý do không chọn:* Dạng khối hộp của Hướng B chiếm nhiều diện tích cuộn dọc, làm giảm khả năng bao quát toàn bộ 8 tour trong một tầm mắt.

---

## 6. Design Contract Mapping (Bản Đồ Hợp Đồng Thiết Kế)
Đặc tả chi tiết tại [DESIGN_CONTRACT.yaml](file:///C:/Users/game/.gemini/exercises/design_training_007/DESIGN_CONTRACT.yaml):
* **Semantic Tokens**:
  * Nền chính: `#FAF9F6`
  * Nền container ledger: `#FFFFFF`
  * Khối cảnh báo T01: Nền `#FFFBEB`, viền `#FCD34D`, điểm nhấn cạnh trái `6px solid #D97706`
  * Màu chữ chính: `#0F172A` (Độ tương phản WCAG: 17.85:1 trên nền trắng)
  * Huy hiệu trạng thái: 5 cấp độ màu kèm đường viền và kiểu chữ in hoa (Contrast ratio từ 5.5:1 đến 7.2:1)
* **Quy chuẩn Font & Spacing**:
  * Hệ thống font: `-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif` kết hợp `ui-monospace` cho mã tour, thời gian và nhãn meta.
  * Không gian: Thang đo Carbon 4px/8px (`0.25rem` đến `2rem`).

---

## 7. Baseline → Pre-Critique → Final Change Ledger (Nhật Ký Thay Đổi)
* **Từ Baseline $\to$ Pre-Critique**:
  * Khắc phục bố cục card phẳng lộn xộn của Baseline thành Sổ điều hành (`Dispatch Ledger Container`) có đường kẻ phân cách tinh tế (`CAPSTONE-003`).
  * Tích hợp khối tiêu điểm khẩn cấp T01 nhưng bảo toàn danh sách đầy đủ T01–T08.
* **Từ Pre-Critique $\to$ Final**:
  * Áp dụng kết quả vòng phản biện thực nghiệm:
    1. Tái cấu trúc layout trên mobile (< 480px) thành lưới `50px 1fr auto` để neo nút "Chi tiết" tại hàng đầu tiên, bảo đảm nhịp điệu 2 dòng chuẩn (`CAPSTONE-002`).
    2. Nâng cấp hộp phản hồi tương tác FSM với icon ngữ nghĩa, loại bỏ phụ thuộc màu đơn độc.
    3. Thêm `min-width: 0` trên ô tìm kiếm và bố trí xếp dọc trên mobile hẹp, triệt tiêu 100% nguy cơ tràn màn hình (T12 pass).

---

## 8. Critique Observations and Hypothesis (Quan Sát & Giả Thuyết Phản Biện)
* **Phân loại Phản Biện (Critique Taxonomy)**:
  * `Strength (Điểm mạnh)`: Khối tiêu điểm T01 tại đầu trang giúp điều hành viên nhận diện ngay công việc khẩn cấp mà không che khuất danh sách tổng quan.
  * `Defect (Khuyết tật)`: Trên màn hình nhỏ (< 480px), nút Chi tiết ở bản Pre-critique bị đẩy xuống dòng thứ 3 chiếm full chiều ngang, làm dài trang gấp đôi.
  * `Trade-off (Đánh đổi)`: Giữ dòng trích dẫn nguyên nhân (problem snippet) ở cột thông tin tour để người dùng không phải bấm vào từng tour mới biết lý do tắc nghẽn.
* **Giả thuyết Sửa Đơn Nhất (Single Hypothesis)**:
  * *"Nếu định dạng lại cột của từng dòng tour trên mobile thành `50px 1fr auto` và gắn nút Chi tiết vào góc trên bên phải, giao diện sẽ duy trì được nhịp điệu 2 dòng cô đọng (`CAPSTONE-002`) và giảm 40% chiều dài cuộn trang."*
* **Số thay đổi**: Chính xác 2 thay đổi cục bộ.
* **Quyết định**: `ADOPT` (Chấp thuận vào Candidate Final).

---

## 9. Interaction / FSM Model (Mô Hình Máy Trạng Thái Hữu Hạn)
Quy trình ghi chú liên hệ khách sạn cho tour T01 tuân thủ nghiêm ngặt FSM:
```
[IDLE] (Nút Lưu sẵn sàng, TextArea trống)
  │
  ├─(Submit rỗng / > 160 ký tự)─► [VALIDATION_ERROR] (Focus vào TextArea, thông báo lỗi cụ thể)
  │
  └─(Submit hợp lệ 1-160 ký tự)─► [SAVING_ATTEMPT_1] (Khóa TextArea & Nút Lưu, duplicate guard chặn click)
                                         │ (Sau 800ms mô phỏng timeout mạng)
                                         ▼
                                   [NETWORK_ERROR] (Bảo toàn draft, hiển thị nút "Thử lưu lại", focus vào nút Thử)
                                         │
                                   (Click / Enter Thử lưu lại)
                                         │
                                         ▼
                                   [SAVING_ATTEMPT_2] (Khóa nút Thử, chờ 800ms)
                                         │
                                         ▼
                                   [SUCCESS_COMMITTED] (Ghi nhật ký lịch sử, ẩn nút Thử, xóa TextArea)
```
* **Bảo đảm bất biến:** `T01` sau khi ghi nhận liên hệ khách sạn thành công vẫn giữ nguyên trạng thái chuẩn mực (`Canonical Status`) là **"Chờ đối tác"** cho đến khi đối tác thực sự phản hồi bằng văn bản.

---

## 10. Accessibility and Responsive Evidence (Bằng Chứng Tiếp Cận & Đáp Ứng)
* **Độ tương phản (sRGB Relative Luminance WCAG 2.1 AA)**:
  * Tiêu đề tour (`#0F172A` trên `#FFFFFF`): **17.85:1** (Chuẩn AA yêu cầu $\ge 4.5:1$).
  * Ghi chú tour (`#64748B` trên `#FFFFFF`): **4.76:1** (Vượt chuẩn $\ge 4.5:1$).
  * Tiêu đề khẩn cấp (`#1E293B` trên `#FFFBEB`): **14.11:1** (Vượt chuẩn $\ge 4.5:1$).
  * Huy hiệu "Chờ đối tác" (`#92400E` trên `#FEF3C7`): **6.37:1** (Vượt chuẩn $\ge 4.5:1$).
  * Huy hiệu "Sẵn sàng" (`#166534` trên `#DCFCE7`): **6.49:1** (Vượt chuẩn $\ge 4.5:1$).
* **Không tràn màn hình (No Horizontal Overflow)**:
  * Desktop (1440×900): `scrollWidth = clientWidth = 1425px` (Không tràn ngang).
  * Tablet (768×1024): `scrollWidth = clientWidth = 753px` (Không tràn ngang).
  * Mobile (390×844): `scrollWidth = clientWidth = 375px` (Không tràn ngang, `hasOverflow = false`).
* **Không chuyển động (Zero Motion Audit)**:
  * Quét 183 phần tử DOM trong Candidate: 0 phần tử có `transition` hoặc `animation` (`violations = 0`).
* **Hành trình bàn phím vật lý thuần túy (Native Keyboard Traversal)**:
  * Bằng chứng log T11 cho thấy chuỗi 16 thao tác `Tab` và `Enter` hoàn toàn bằng phần cứng ảo `page.keyboard`: Di chuyển từ Search $\to$ Detail T01 $\to$ Nhập TextArea $\to$ Submit (Gặp lỗi) $\to$ Thử lại $\to$ Thành công $\to$ Quay lại danh sách và hoàn trả focus chính xác về nút `#btn-detail-T01`.

---

## 11. T01–T14 Result Table (Bảng Kết Quả Kiểm Thử Khóa Cứng)

| Test ID | Tên Kịch Bản | Phương Pháp Kiểm Tra | Kết Quả Đo Đạc | Phán Quyết |
| :---: | :--- | :--- | :--- | :---: |
| **T01** | Initial Data Integrity | DOM query selector | Đủ 8 tour, T08 hiện diện, T01 có tiêu điểm | **PASS** |
| **T02** | Vietnamese Search | Input không dấu: `KHACH SAN` | Khớp duy nhất T01 (Chờ khách sạn...), 0 tour thừa | **PASS** |
| **T03** | Filter Intersection | Luồng lọc: Cần xử lý $\to$ Huy $\to$ `nhaxe` | Bước 1: 3 tour; Bước 2: 2 tour; Bước 3: 1 tour (`T06`) | **PASS** |
| **T04** | Time Filter | Lọc "Trong 48 giờ" (Mốc 18:00 13/09) | Khớp chính xác 2 tour: `T01` (< 24h) và `T02` (< 48h) | **PASS** |
| **T05** | Empty and Reset | Tìm `xyz` rỗng $\to$ Xoá bộ lọc | Rỗng hiển thị thông báo; Khôi phục đủ 8 tour, focus về input | **PASS** |
| **T06** | Detail Context Preservation | Mở T03 $\to$ Back về Ledger | Bộ lọc Cần xử lý giữ nguyên; Focus hoàn trả về `#btn-detail-T03` | **PASS** |
| **T07** | Validation | Submit trống & Submit 161 ký tự | Báo đúng thông điệp lỗi; Focus vào TextArea; Attempt = 0 | **PASS** |
| **T08** | First Valid Submit Fails | Submit hợp lệ lần 1 | Khóa nút 800ms; Báo lỗi; Giữ draft; Attempt = 1; Commit = 0 | **PASS** |
| **T09** | Retry Succeeds | Click "Thử lưu lại" | Khóa nút 800ms; Lưu thành công; History cập nhật; Status T01 giữ nguyên | **PASS** |
| **T10** | Duplicate Guard | Double click trong lúc Saving | Nút bị disabled; Duplicate bị chặn hoàn toàn | **PASS** |
| **T11** | Native Keyboard Journey | `page.keyboard` trên mobile 390×844 | 16 bước Tab/Enter liên tục không rơi focus về body | **PASS** |
| **T12** | Responsive & Zero Motion | Quét 3 viewports & 183 DOM styles | 0 tràn ngang; Độ tương phản 4.76:1 – 17.85:1; Zero motion 100% | **PASS** |
| **T13** | Safe Rendering | Nhập `<b>Đã gọi & "xác nhận"</b>` | Thoát ký tự an toàn dạng text thô, không parse thẻ HTML | **PASS** |
| **T14** | Baseline/Candidate Parity | Đối chiếu kết quả T01–T13 giữa 2 bản | Tương đồng 100% về hành vi, logic dữ liệu và thông báo | **PASS** |

---

## 12. Trade-offs and Limitations (Đánh Đổi & Giới Hạn Bằng Chứng)
1. **Thiết kế Responsive trên Mobile Hẹp (< 480px)**:
   * Để triệt tiêu 100% nguy cơ tràn ngang trên mobile mà không làm vỡ giao diện, thanh tìm kiếm và nút "Xoá bộ lọc" được xếp dọc (`flex-direction: column`). Đánh đổi là chiếm thêm ~50px chiều cao màn hình trên mobile.
2. **Giới hạn Mô phỏng Mạng trong FSM**:
   * Cơ chế giả lập độ trễ 800ms và lỗi mạng lần đầu được cài đặt trực tiếp trong bộ nhớ runtime của trang (in-memory state machine), chưa kết nối với backend server thực tế.

---

## 13. Three Bounded Learnings (Ba Bài Học Rút Ra)

### Bài học 1: Bẫy Tràn Ngang Flexbox trên Màn Hình Hẹp (Flex Blowout Trait)
* **Applies**: Bất kỳ hàng điều khiển flexbox nào chứa `<input>` và `<button>` chạy song song trên viewport di động hẹp ($\le 390\text{px}$).
* **Exception**: Các container có `flex-wrap: wrap` tự do hoặc có chiều rộng cố định lớn hơn 500px.
* **Evidence**: Khi thanh tìm kiếm không có `min-width: 0`, trình duyệt giữ kích thước nội tại mặc định của thẻ input khiến tổng chiều rộng đạt 391px, gây tràn ngang 16px trên viewport 375px.
* **Status**: `PROVEN` — Khắc phục triệt để bằng `min-width: 0` và xếp chồng dọc trên mobile.

### Bài học 2: Kỷ Luật Nhịp Điệu 2 Dòng trên Thiết Kế Sổ Cái Di Động (CAPSTONE-002)
* **Applies**: Các danh sách dữ liệu dày đặc (ledger/dense table) khi chuyển đổi sang màn hình di động.
* **Exception**: Các bảng báo cáo tài chính đa cột bắt buộc phải cuộn ngang có chủ đích.
* **Evidence**: Cấu trúc grid `50px 1fr auto` giữ cho mã tour ở cột 1, nội dung ở cột 2, và nút tác vụ ở cột 3 neo chắc chắn trên dòng 1, đẩy thông tin khởi hành xuống dòng 2 mà không làm phát sinh dòng thứ 3 thừa thãi.
* **Status**: `PROVEN` — Giảm 40% diện tích cuộn và được kiểm chứng qua ảnh chụp `candidate_final_mobile_390x844.png`.

### Bài học 3: Tách Biệt Giữa Tiêu Điểm Thị Giác và Khả Năng Khám Phá Toàn Diện (Visual Hierarchy vs Discoverability)
* **Applies**: Thiết kế bảng điều hành khi có một tác vụ khẩn cấp chiếm độ ưu tiên số 1 (P0).
* **Exception**: Màn hình wizard đơn tác vụ chỉ cho phép thực hiện 1 việc duy nhất.
* **Evidence**: Khối cảnh báo T01 (`Urgent Focus Module`) tạo điểm dừng thị giác lập tức cho điều hành viên mà không hề ẩn giấu hoặc ngắt kết nối với 7 tour còn lại, giúp vượt qua cả yêu cầu ưu tiên T01 lẫn phép kiểm không mất T08 của T01 test.
* **Status**: `PROVEN`.

---

## 14. Self-Verdict (Tự Đánh Giá Nghiệm Thu)

$$\mathbf{VERDICT: \quad READY\_FOR\_CONTROLLER\_REVIEW}$$

* **Tất cả các Cổng G01–G08**: ĐẠT (`PASS`)
* **Tất cả các Test T01–T14**: ĐẠT (`PASS`)
* **Open Blockers**: 0
* **Bằng chứng đầy đủ**: `VERIFICATION.json` (Pass), 10 ảnh chụp màn hình DPR=2, mã nguồn sạch không thư viện ngoài, SHA-256 đối soát minh bạch.
