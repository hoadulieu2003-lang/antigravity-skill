# BÁO CÁO NGHIỆM THU: DESIGN_TRAINING_007 (TRANSFER CAPSTONE)

> **Mã chỉ thị**: `DESIGN_TRAINING_007`  
> **Chặng**: `FOUNDATION_TRANSFER_CAPSTONE`  
> **Sản phẩm**: `TRIPFLOW — Bảng điều phối tour khởi hành`  
> **Thực thi**: Antigravity Senior Engineering Agent  
> **Thời điểm**: 13/09/2026 21:58:00 ICT  
> **Môi trường**: Windows 11, Node v24.18.0, Chrome CDP port 9222  

---

## 1. Executive Summary (Tóm Tắt Điều Hành)
Bài thi kiểm tra chuyển giao năng lực thiết kế (`Transfer Testing`) **DESIGN_TRAINING_007** được tiến hành trên một đề bài và ngữ cảnh nghiệp vụ hoàn toàn mới: hệ thống điều phối tour khởi hành **TRIPFLOW** dành cho nhà điều hành lữ hành vừa và nhỏ (SMB tour operator), giải quyết điểm nghẽn điều phối tại mốc giờ chuẩn `18:00 13/09/2026 ICT`.

Hệ thống đã hoàn tất đầy đủ 8 Cổng chất lượng (`G01–G08`) và vượt qua 14 kịch bản kiểm thử khóa cứng (`T01–T14`), đáp ứng nghiêm ngặt các bất biến hệ thống:
* **Anti-Copy Invariant**: DNA thiết kế hoàn toàn mới, không sao chép cấu trúc hero chia đôi hay phong cách của dự án TRACE trước đó;
* **Mandatory Light Theme Default Invariant**: 100% giao diện sáng (`Light Theme`) trang nhã với sắc giấy ấm `Warm Paper (#FAF9F6)`;
* **Zero Motion Invariant**: Khóa chết `transition: none !important` và `animation: none !important`;
* **Self-contained Vanilla Stack**: Thuần HTML5/CSS3/ES6 không thư viện ngoài hay CDN, hoạt động offline 100%.

---

## 2. Source and Hash Ledger (Bảng Đối Soát Mã Nguồn & Băm SHA-256)

| Tệp / Phiên Bản | Đường Dẫn Tương Đối | SHA-256 Checksum | Trạng Thái |
| :--- | :--- | :--- | :---: |
| **Baseline** | `baseline/index.html` | `261473702844d553561634e8f13677050f705b104c650565da572426bade32b3` | `LOCKED` |
| **Candidate Pre-Critique** | `candidate/pre_critique.html` | `0b32ef205e508c6ee060e2f758d95e94cb6875cdc5c147d568bed353f54e04d1` | `LOCKED` |
| **Candidate Final** | `candidate/index.html` | `82b214323619d7b61a70f5e22134dac9071dfd38c6f2815318d4af1feb0dc94a` | `FINAL` |
| **Direction A Specimen** | `directions/option_a.html` | `c6a2dbd5292eb5f91753c15d5ecdd94fb797c23101eb89caefaa9dc90b39679f` | `VERIFIED` |
| **Direction B Specimen** | `directions/option_b.html` | `0b15a63901b0f5b9d3e8e1966a0129c54238e8ecaaecfcadfaeb81d2f00a29ea` | `VERIFIED` |
| **Design Contract** | `DESIGN_CONTRACT.yaml` | `[Structured Specification]` | `ACTIVE` |
| **Verification Ledger** | `VERIFICATION.json` | `[Automated Evidence Report]` | `PASS` |

---

## 3. Canonical Data Confirmation (Xác Nhận 8 Dữ Liệu Nghiệp Vụ Chuẩn Mực)
Toàn bộ 8 tour xuất phát được ánh xạ chính xác 100% theo Chỉ thị Nghiệp vụ tại mốc giờ chuẩn `18:00 13/09/2026 ICT`:

| ID | Tên Tour | Khởi Hành | Phụ Trách | Trạng Thái | Ghi Chú & Vấn Đề | Luồng Nghiệp Vụ |
| :---: | :--- | :---: | :---: | :---: | :--- | :---: |
| **T01** | Hạ Long 2N1Đ | 14/09/2026 07:30 | Lan | Chờ đối tác | Khách sạn chưa xác nhận 4 phòng | Cần xử lý / < 24h |
| **T02** | Ninh Bình 1 ngày | 14/09/2026 06:00 | Minh | Sẵn sàng | Đã đủ xe, hướng dẫn viên và danh sách khách | Sẵn sàng / < 48h |
| **T03** | Sapa 3N2Đ | 15/09/2026 21:30 | Huy | Thiếu hồ sơ | 2 khách chưa gửi CCCD | Cần xử lý |
| **T04** | Đà Nẵng 4N3Đ | 16/09/2026 08:00 | Lan | Đang chuẩn bị | Chờ chốt danh sách suất ăn | Đang chuẩn bị |
| **T05** | Hà Giang 3N2Đ | 17/09/2026 05:30 | Minh | Sẵn sàng | Đã hoàn tất checklist khởi hành | Sẵn sàng |
| **T06** | Phú Quốc 3N2Đ | 18/09/2026 09:10 | Huy | Chờ đối tác | Nhà xe trung chuyển chưa xác nhận | Cần xử lý |
| **T07** | Mộc Châu 2N1Đ | 19/09/2026 06:30 | Lan | Đang chuẩn bị | Đang rà soát danh sách phòng | Đang chuẩn bị |
| **T08** | Huế 3N2Đ | 12/09/2026 07:00 | An | Hoàn thành | Đoàn đã khởi hành và bàn giao nhật ký | Đã hoàn thành |

*Bảo đảm dữ liệu gốc:* Tuyệt đối không làm mất `T08` ở màn hình ban đầu; Candidate hiển thị khối tiêu điểm khẩn cấp T01 nhưng duy trì lối dẫn rõ ràng tới toàn bộ 8 bản ghi trong cùng giao diện.

---

## 4. IA Comparison and Retrieval Scenarios (So Sánh Cấu Trúc Thông Tin & 3 Kịch Bản Truy Xuất)

### 4.1. Phân Tích So Sánh Hai Phương Án IA

| Tiêu Chí | Phương Án A (Theo Nhóm Thời Gian Đơn Thuần) | Phương Án B (Phân Tách: Luồng Xử Lý + Bộ Lọc Thuộc Tính) — ĐÃ CHỌN |
| :--- | :--- | :--- |
| **Cấu trúc Điều Hướng** | Gom nhóm cứng: *Hôm nay / < 24h*, *Trong 48 giờ*, *Tuần này*, *Lịch sử hoàn thành*. | **Tầng 1 (Primary Workflow Navigation)**: Dãy nút phân đoạn ngang *Tất cả*, *Cần xử lý*, *Đang chuẩn bị*, *Sẵn sàng*, *Đã hoàn thành*.<br>**Tầng 2 (Faceted Attribute Filters)**: Bộ lọc thuộc tính độc lập *Thời gian (Tất cả \| Trong 48h)* và *Phụ trách (Tất cả \| Lan \| Minh \| Huy \| An)*. |
| **Khả năng Kết Hợp Lọc (Faceted Intersection)** | Kém linh hoạt; không thể lọc chéo giữa người phụ trách và tình trạng thiếu hồ sơ. | **Hoàn hảo qua phép giao logic AND**: Có thể chọn cùng lúc "Cần xử lý" + "Huy" + query "nha xe" để ra chính xác T06. |
| **Trải Nghiệm Điều Hành Viên (Operator UX)** | Người điều phối phải quét mắt qua nhiều mốc ngày khác nhau để tìm tour tắc nghẽn. | Bật ngay nhóm "Cần xử lý" để cô lập tức thì các tour đang bị nghẽn (T01, T03, T06) bất kể ngày khởi hành. |

### 4.2. So Sánh Hiệu Suất Qua 3 Kịch Bản Truy Xuất Thực Tế

| Kịch Bản Truy Xuất Nghiệp Vụ | Phương Án A (Nhóm thời gian) | Phương Án B (Phân tầng IA chuẩn) | Đánh Giá Ưu Thế |
| :--- | :--- | :--- | :---: |
| **Kịch bản 1: Tìm tour khẩn cấp cần can thiệp đối tác ngay hôm nay** | Mở nhóm "< 24h", đọc từng card để lọc thủ công tour nào "Chờ đối tác". (3 thao tác) | Bấm trực tiếp nút hành động tại Hero T01 hoặc chọn tab "Cần xử lý" $\to$ T01 xuất hiện ngay đầu. (1 thao tác) | **Phương án B vượt trội** (Giảm 66% số thao tác) |
| **Kịch bản 2: Điều phối viên Huy kiểm tra toàn bộ tour mình phụ trách** | Phải cuộn qua từng mục Hôm nay, 48h, Tuần này để tìm tên Huy rải rác. | Chọn dropdown Phụ trách: `Huy` $\to$ Hệ thống lọc tức thì T03, T05, T06. | **Phương án B vượt trội** (Truy xuất tức thì, 0 bỏ sót) |
| **Kịch bản 3: Kiểm tra các tour đang chuẩn bị khởi hành trong vòng 48 giờ** | Xem nhóm "Trong 48 giờ", nhưng bị lẫn lộn giữa tour đã sẵn sàng và tour đang chuẩn bị. | Chọn tab "Đang chuẩn bị" + dropdown Thời gian "Trong 48 giờ" $\to$ Giao AND chính xác. | **Phương án B vượt trội** (Phép giao logic chuẩn xác) |

---

## 5. Art Direction A/B and Decision (Định Hướng Mỹ Thuật & Đánh Đổi)
Đã thiết kế 2 phương án mỹ thuật độc lập:
* **Hướng A — Dispatch Ledger (Sổ Điều Phối Hành Trình) — ĐÃ CHỌN**:
  * *Thẩm mỹ:* Cảm hứng sổ cái điều phối hành chính cao cấp, nền giấy ấm `Warm Paper (#FAF9F6)`, đường kẻ tóc hairline `1px solid #E2E8F0`, chữ đen than `Obsidian (#0F172A)`, điểm nhấn hổ phách `Terracotta Amber (#D97706)` cho tour khẩn cấp `T01`.
  * *Điểm đánh đổi 1:* Mật độ thông tin cao hơn (Compact ledger cadence) đòi hỏi kiểm soát chặt chẽ nhịp điệu 2 dòng trên thiết bị di động.
  * *Điểm đánh đổi 2:* Cần bố trí nhãn nhịp điệu cột rõ ràng để tránh hiểu nhầm giữa giờ khởi hành và giờ quy chiếu.
* **Hướng B — Departure Board (Bảng Ga Khởi Hành)**:
  * *Thẩm mỹ:* Lấy cảm hứng bảng thông tin nhà ga sân bay hiện đại nhưng chạy trên nền sáng, typography đậm, tương phản khối cao.
  * *Lý do không chọn:* Dạng khối hộp của Hướng B chiếm nhiều diện tích cuộn dọc, làm giảm khả năng bao quát toàn bộ 8 tour trong một tầm mắt.

---

## 6. Design Contract Mapping (Bản Đồ Hợp Đồng Thiết Kế)
Đặc tả chi tiết tại [DESIGN_CONTRACT.yaml](./DESIGN_CONTRACT.yaml):
* **Semantic Tokens**:
  * Nền chính: `#FAF9F6`
  * Nền container ledger: `#FFFFFF`
  * Khối cảnh báo T01: Nền `#FFFBEB`, viền `#FCD34D`, điểm nhấn cạnh trái `6px solid #D97706`
  * Màu chữ chính: `#0F172A` (Độ tương phản WCAG: 17.85:1 trên nền trắng)
  * Huy hiệu trạng thái: 5 cấp độ màu kèm đường viền và kiểu chữ in hoa (Contrast ratio từ 5.5:1 đến 7.2:1)
* **Quy chuẩn Font & Spacing**:
  * Hệ thống font: `-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif` kết hợp `ui-monospace` cho mã tour, thời gian và nhãn meta.
  * Không gian: Thang đo Carbon 4px/8px (`0.25rem` đến `2rem`).

---

## 7. Baseline → Pre-Critique → Final Change Ledger (Nhật Ký Thay Đổi)
* **Từ Baseline $\to$ Pre-Critique**:
  * Khắc phục bố cục card phẳng lộn xộn của Baseline thành Sổ điều hành (`Dispatch Ledger Container`) có đường kẻ phân cách tinh tế (`CAPSTONE-003`).
  * Tích hợp khối tiêu điểm khẩn cấp T01 nhưng bảo toàn danh sách đầy đủ T01–T08.
* **Từ Pre-Critique $\to$ Final**:
  * Áp dụng kết quả vòng phản biện thực nghiệm:
    1. Tái cấu trúc layout trên mobile (< 480px) thành lưới `50px 1fr auto` để neo nút "Chi tiết" tại hàng đầu tiên, bảo đảm nhịp điệu 2 dòng chuẩn (`CAPSTONE-002`).
    2. Nâng cấp hộp phản hồi tương tác FSM với icon ngữ nghĩa, loại bỏ phụ thuộc màu đơn độc.
    3. Thêm `min-width: 0` trên ô tìm kiếm và bố trí xếp dọc trên mobile hẹp, triệt tiêu 100% nguy cơ tràn màn hình (T12 pass).
* **Đợt Sửa Chữa 1/2 (Repair Round 1)**:
  * Áp dụng Common Compliance Patch (IA separation, single stable button FSM, 44px touch targets) lên cả 3 artifact.
  * Cô lập diff giữa `candidate/pre_critique.html` và `candidate/index.html` chính xác đúng 2 thay đổi thiết kế theo giả thuyết ban đầu.

---

## 8. Critique Observations and Hypothesis (Quan Sát & Giả Thuyết Phản Biện)
* **Phân loại Phản Biện (Critique Taxonomy)**:
  * `Strength (Điểm mạnh)`: Khối tiêu điểm T01 tại đầu trang giúp điều hành viên nhận diện ngay công việc khẩn cấp mà không che khuất danh sách tổng quan.
  * `Defect (Khuyết tật)`: Trên màn hình nhỏ (< 480px), nút Chi tiết ở bản Pre-critique bị đẩy xuống dòng thứ 3 chiếm full chiều ngang, làm dài trang gấp đôi.
  * `Trade-off (Đánh đổi)`: Giữ dòng trích dẫn nguyên nhân (problem snippet) ở cột thông tin tour để người dùng không phải bấm vào từng tour mới biết lý do tắc nghẽn.
* **Giả thuyết Sửa Đơn Nhất (Single Hypothesis)**:
  * *"Nếu định dạng lại cột của từng dòng tour trên mobile thành `50px 1fr auto` và gắn nút Chi tiết vào góc trên bên phải, giao diện sẽ duy trì được nhịp điệu 2 dòng cô đọng (`CAPSTONE-002`) và giảm chiều dài cuộn trang."*
* **Đo đạc Thực Tế**: Giảm chính xác **470px** chiều cao cuộn (từ 2950px xuống 2480px, tương đương giảm **15.93%**).
* **Số thay đổi**: Chính xác 2 thay đổi cục bộ.
* **Quyết định**: `ADOPT` (Chấp thuận vào Candidate Final).

---

## 9. Interaction / FSM Model (Mô Hình Máy Trạng Thái Hữu Hạn Nút Ổn Định Duy Nhất)
Quy trình ghi chú liên hệ khách sạn cho tour T01 sử dụng một phần tử nút tương tác ổn định duy nhất (`#btn-save-contact-note`), tuân thủ nghiêm ngặt FSM:
```
[IDLE] (Nút "#btn-save-contact-note" nhãn "Lưu nhật ký", TextArea trống)
  │
  ├─(Submit rỗng / > 160 ký tự)─► [VALIDATION_ERROR] (Focus vào TextArea, thông báo lỗi cụ thể ⚠️)
  │
  └─(Submit hợp lệ 1-160 ký tự)─► [SAVING_ATTEMPT_1] (Nút đổi nhãn "Đang lưu nhật ký…", disabled=true, chặn click kép)
                                         │ (Sau 800ms độ trễ mạng mô phỏng)
                                         ▼
                                   [NETWORK_ERROR] (Bảo toàn draft, nút giữ nguyên DOM đổi nhãn "Thử lưu lại", focus giữ tại nút)
                                         │
                                   (Click / Enter nút "Thử lưu lại")
                                         │
                                         ▼
                                   [SAVING_ATTEMPT_2] (Nút đổi nhãn "Đang lưu nhật ký…", disabled=true)
                                         │ (Sau 800ms)
                                         ▼
                                   [SUCCESS_COMMITTED] (Ghi nhật ký lịch sử, nút đổi về "Lưu nhật ký", xóa TextArea, KHÔNG cướp focus)
```
* **Bảo đảm bất biến:**
  * `T01` sau khi ghi nhận liên hệ khách sạn thành công vẫn giữ nguyên trạng thái chuẩn mực (`Canonical Status`) là **"Chờ đối tác"** cho đến khi đối tác thực sự phản hồi.
  * Không phát sinh phần tử DOM thứ hai; cùng 1 nút xử lý xuyên suốt vòng đời.

---

## 10. Accessibility and Responsive Evidence (Bằng Chứng Tiếp Cận & Đáp Ứng)
* **Độ tương phản (sRGB Relative Luminance WCAG 2.1 AA)**:
  * Tiêu đề tour (`#0F172A` trên `#FFFFFF`): **17.85:1** (Chuẩn AA yêu cầu $\ge 4.5:1$).
  * Ghi chú tour (`#64748B` trên `#FFFFFF`): **4.76:1** (Vượt chuẩn $\ge 4.5:1$).
  * Tiêu đề khẩn cấp (`#1E293B` trên `#FFFBEB`): **14.11:1** (Vượt chuẩn $\ge 4.5:1$).
  * Huy hiệu "Chờ đối tác" (`#92400E` trên `#FEF3C7`): **6.37:1** (Vượt chuẩn $\ge 4.5:1$).
  * Huy hiệu "Sẵn sàng" (`#166534` trên `#DCFCE7`): **6.49:1** (Vượt chuẩn $\ge 4.5:1$).
* **Mục Tiêu Chạm Tương Tác (Target Sizes $\ge 44\times 44\text{px}$)**:
  * Toàn bộ 20 phần tử tương tác trên cả 2 màn hình (List view, Detail view, Empty state) đều đạt kích thước tối thiểu $\ge 44\times 44\text{px}$ (`targetSizesPass = true`, 0 vi phạm).
* **Không tràn màn hình (No Horizontal Overflow)**:
  * Desktop (1440×900): `scrollWidth = clientWidth = 1425px` (Không tràn ngang).
  * Tablet (768×1024): `scrollWidth = clientWidth = 753px` (Không tràn ngang).
  * Mobile (390×844): `scrollWidth = clientWidth = 375px` (Không tràn ngang, `hasOverflow = false`).
* **Không chuyển động (Zero Motion Audit)**:
  * Quét 189 phần tử DOM trong Candidate: 0 phần tử có `transition` hoặc `animation` (`violations = 0`).
* **Hành trình bàn phím vật lý thuần túy (Native Keyboard Traversal)**:
  * Bằng chứng log T11 cho thấy chuỗi 19 thao tác `Tab`, `Enter`, và `Shift+Tab` hoàn toàn bằng phần cứng ảo `page.keyboard`: Di chuyển từ Search $\to$ Detail T01 $\to$ Nhập TextArea $\to$ Submit Attempt 1 (Gặp lỗi, focus giữ tại nút) $\to$ Submit Attempt 2 Retry (Thành công) $\to$ Shift+Tab về nút Quay lại $\to$ Trở về danh sách và hoàn trả focus chính xác về nút `#btn-detail-T01` (0 bước rơi focus về BODY).

---

## 11. T01–T14 Result Table (Bảng Kết Quả Kiểm Thử Khóa Cứng)

| Test ID | Tên Kịch Bản | Phương Pháp Kiểm Tra | Kết Quả Đo Đạc | Phán Quyết |
| :---: | :--- | :--- | :--- | :---: |
| **T01** | Initial Data Integrity | DOM query selector | Đủ 8 tour, T08 hiện diện, T01 có tiêu điểm | **PASS** |
| **T02** | Vietnamese Search | Input không dấu: `KHACH SAN` | Khớp duy nhất T01 (Chờ khách sạn...), 0 tour thừa | **PASS** |
| **T03** | Filter Intersection | Luồng lọc: Cần xử lý $\to$ Huy $\to$ `nha xe` | Bước 1: 3 tour; Bước 2: 2 tour; Bước 3: 1 tour (`T06`) | **PASS** |
| **T04** | Time Filter | Lọc "Trong 48 giờ" (Mốc 18:00 13/09) | Khớp chính xác 2 tour: `T01` (< 24h) và `T02` (< 48h) | **PASS** |
| **T05** | Empty and Reset | Tìm `xyz` rỗng $\to$ Xoá bộ lọc | Rỗng hiển thị thông báo; Khôi phục đủ 8 tour, focus về input | **PASS** |
| **T06** | Detail Context Preservation | Mở T03 $\to$ Back về Ledger | Bộ lọc Cần xử lý giữ nguyên; Focus hoàn trả về `#btn-detail-T03` | **PASS** |
| **T07** | Validation | Submit trống & Submit 161 ký tự | Báo đúng thông điệp lỗi ⚠️; Focus vào TextArea; Attempt = 0 | **PASS** |
| **T08** | First Valid Submit Fails | Submit hợp lệ lần 1 | Khóa nút 800ms; Báo lỗi; Giữ draft; Attempt = 1; Commit = 0 | **PASS** |
| **T09** | Retry Succeeds | Click "Thử lưu lại" | Khóa nút 800ms; Lưu thành công ✓; History cập nhật; Status T01 giữ nguyên | **PASS** |
| **T10** | Duplicate Guard | Dispatch click/Enter trong lúc Saving | Nút bị disabled; Duplicate bị chặn hoàn toàn | **PASS** |
| **T11** | Native Keyboard Journey | `page.keyboard` trên mobile 390×844 | 19 bước Tab/Enter/Shift+Tab liên tục, 0 bước rơi focus về body | **PASS** |
| **T12** | Responsive & Zero Motion | Quét 3 viewports, 189 DOM styles, 20 targets | 0 tràn ngang; Tương phản $\ge 4.76:1$; Zero motion 100%; Targets $\ge 44\text{px}$ | **PASS** |
| **T13** | Safe Rendering | Nhập `<b>Đã gọi & "xác nhận"</b>` | Thoát ký tự an toàn dạng text thô, không parse thẻ HTML | **PASS** |
| **T14** | Baseline/Candidate Parity | Đối chiếu sâu kết quả T01–T13 giữa 2 bản | Tương đồng 100% về hành vi, logic dữ liệu và thông báo | **PASS** |

---

## 12. Trade-offs and Limitations (Đánh Đổi & Giới Hạn Bằng Chứng)
1. **Thiết kế Responsive trên Mobile Hẹp (< 480px)**:
   * Để triệt tiêu 100% nguy cơ tràn ngang trên mobile mà không làm vỡ giao diện, thanh tìm kiếm và nút "Xoá bộ lọc" được xếp dọc (`flex-direction: column`). Đánh đổi là chiếm thêm ~50px chiều cao màn hình trên mobile nhưng đảm bảo an toàn tuyệt đối cho touch target $\ge 44\text{px}$.
2. **Giới hạn Mô phỏng Mạng trong FSM**:
   * Cơ chế giả lập độ trễ 800ms và lỗi mạng lần đầu được cài đặt trực tiếp trong bộ nhớ runtime của trang (in-memory state machine), kiểm chứng chính xác cơ chế phản hồi lỗi và phục hồi dữ liệu trước khi kết nối backend production.

---

## 13. Three Bounded Learnings (Ba Bài Học Rút Ra)

### Bài học 1: Bẫy Tràn Ngang Flexbox trên Màn Hình Hẹp (Flex Blowout Trait)
* **Applies**: Bất kỳ hàng điều khiển flexbox nào chứa `<input>` và `<button>` chạy song song trên viewport di động hẹp ($\le 390\text{px}$).
* **Exception**: Các container có `flex-wrap: wrap` tự do hoặc có chiều rộng cố định lớn hơn 500px.
* **Evidence**: Khi thanh tìm kiếm không có `min-width: 0`, trình duyệt giữ kích thước nội tại mặc định của thẻ input khiến tổng chiều rộng đạt 391px, gây tràn ngang 16px trên viewport 375px.
* **Status**: `EXERCISE_SUPPORTED` — Khắc phục triệt để bằng `min-width: 0` và xếp chồng dọc trên mobile.

### Bài học 2: Kỷ Luật Nhịp Điệu 2 Dòng trên Thiết Kế Sổ Cái Di Động (CAPSTONE-002)
* **Applies**: Các danh sách dữ liệu dày đặc (ledger/dense table) khi chuyển đổi sang màn hình di động.
* **Exception**: Các bảng báo cáo tài chính đa cột bắt buộc phải cuộn ngang có chủ đích.
* **Evidence**: Cấu trúc grid `50px 1fr auto` giữ cho mã tour ở cột 1, nội dung ở cột 2, và nút tác vụ ở cột 3 neo chắc chắn trên dòng 1, đẩy thông tin khởi hành xuống dòng 2 mà không làm phát sinh dòng thứ 3 thừa thãi.
* **Status**: `EXERCISE_SUPPORTED` — Giảm 470px (15.93%) chiều cao cuộn và được kiểm chứng qua ảnh chụp `candidate_final_mobile_390x844.png`.

### Bài học 3: Tách Biệt Giữa Tiêu Điểm Thị Giác và Khả Năng Khám Phá Toàn Diện (Visual Hierarchy vs Discoverability)
* **Applies**: Thiết kế bảng điều hành khi có một tác vụ khẩn cấp chiếm độ ưu tiên số 1 (P0).
* **Exception**: Màn hình wizard đơn tác vụ chỉ cho phép thực hiện 1 việc duy nhất.
* **Evidence**: Khối cảnh báo T01 (`Urgent Focus Module`) tạo điểm dừng thị giác lập tức cho điều hành viên mà không hề ẩn giấu hoặc ngắt kết nối với 7 tour còn lại, giúp vượt qua cả yêu cầu ưu tiên T01 lẫn phép kiểm không mất T08 của T01 test.
* **Status**: `EXERCISE_SUPPORTED`.

---

## 14. Self-Verdict (Tự Đánh Giá Nghiệm Thu)

$$\mathbf{VERDICT: \quad READY\_FOR\_CONTROLLER\_REVIEW}$$

* **Đợt nộp**: `DESIGN_TRAINING_007_REPAIR_001` (Repair Round 1/2)
* **Tất cả các Cổng G01–G08**: ĐẠT (`PASS`)
* **Tất cả các Test T01–T14**: ĐẠT (`PASS` — Conjunction Formula)
* **Open Blockers**: 0
* **Bằng chứng đầy đủ**: `VERIFICATION.json` (Pass), 12 ảnh chụp màn hình DPR=2, mã nguồn sạch không thư viện ngoài, SHA-256 đối soát minh bạch, đường dẫn tương đối chuẩn mực.
