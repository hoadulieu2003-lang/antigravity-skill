let puppeteer;
try {
  puppeteer = require('puppeteer-core');
} catch (e) {
  puppeteer = require('C:/Users/game/cdp_reader/node_modules/puppeteer-core');
}

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Port from CLI argument or environment variable, defaulting to 9222
const port = process.argv[2] || process.env.CDP_PORT || '9222';
const baseDir = __dirname;
const screenshotsDir = path.join(baseDir, 'screenshots');
if (!fs.existsSync(screenshotsDir)) fs.mkdirSync(screenshotsDir, { recursive: true });

function getSha256(filePath) {
  if (!fs.existsSync(filePath)) return null;
  return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

// Relative Luminance & Contrast Formula WCAG 2.1
function getLuminance(r, g, b) {
  const [rs, gs, bs] = [r, g, b].map(c => {
    c = c / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
}

function getContrast(rgb1, rgb2) {
  const l1 = getLuminance(rgb1[0], rgb1[1], rgb1[2]);
  const l2 = getLuminance(rgb2[0], rgb2[1], rgb2[2]);
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

function parseRgb(colorStr) {
  if (!colorStr) return [0, 0, 0];
  const m = colorStr.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
  if (!m) return [0, 0, 0];
  return [parseInt(m[1]), parseInt(m[2]), parseInt(m[3])];
}

async function runTests() {
  console.log('=== STARTING MODULE 007 VERIFICATION SUITE (REV 002) ===');
  console.log(`Connecting to Chrome CDP at port: ${port}`);
  
  const browser = await puppeteer.connect({ browserURL: `http://127.0.0.1:${port}` });
  const page = await browser.newPage();

  const baselinePath = 'file:///' + path.join(baseDir, 'baseline', 'index.html').replace(/\\/g, '/');
  const preCritiquePath = 'file:///' + path.join(baseDir, 'candidate', 'pre_critique.html').replace(/\\/g, '/');
  const candidatePath = 'file:///' + path.join(baseDir, 'candidate', 'index.html').replace(/\\/g, '/');
  const directionAPath = 'file:///' + path.join(baseDir, 'directions', 'option_a.html').replace(/\\/g, '/');
  const directionBPath = 'file:///' + path.join(baseDir, 'directions', 'option_b.html').replace(/\\/g, '/');

  const baselineHash = getSha256(path.join(baseDir, 'baseline', 'index.html'));
  const preCritiqueHash = getSha256(path.join(baseDir, 'candidate', 'pre_critique.html'));
  const candidateHash = getSha256(path.join(baseDir, 'candidate', 'index.html'));

  console.log('[HASHES]');
  console.log(`  Baseline: ${baselineHash}`);
  console.log(`  Pre-Critique: ${preCritiqueHash}`);
  console.log(`  Candidate Final: ${candidateHash}`);

  // Test Engine Helper to run scenarios on an arbitrary page
  async function testPageCore(targetUrl, isCandidate = false) {
    await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
    await page.goto(targetUrl, { waitUntil: 'load' });

    // T01: Initial Data Integrity & Deep Tuple Inspection
    const t01 = await page.evaluate(() => {
      const items = Array.from(document.querySelectorAll('.tour-card, .ledger-item'));
      const text = document.body.innerText;
      const tours = (window.CANONICAL_TOURS || []).map(t => ({
        id: t.id,
        name: t.name,
        depart: t.depart,
        owner: t.owner,
        status: t.status,
        notes: t.notes
      }));
      return {
        count: items.length,
        hasT08: text.includes("T08") && text.includes("Huế"),
        hasT01: text.includes("T01") && text.includes("Hạ Long"),
        allPresent: ["T01", "T02", "T03", "T04", "T05", "T06", "T07", "T08"].every(id => text.includes(id)),
        deepTuples: tours
      };
    });

    // T02: Vietnamese Search "KHACH SAN" (unaccented uppercase)
    const searchSel = isCandidate ? '#input-tour-search' : '#search-input';
    await page.focus(searchSel);
    await page.evaluate((sel) => { document.querySelector(sel).value = ""; }, searchSel);
    await page.type(searchSel, "KHACH SAN");
    await new Promise(r => setTimeout(r, 200));

    const t02 = await page.evaluate(() => {
      const items = Array.from(document.querySelectorAll('.tour-card, .ledger-item'));
      const text = items.map(el => el.innerText).join('\n');
      return {
        matchedCount: items.length,
        hasT01: text.includes("T01"),
        noOther: !text.includes("T02") && !text.includes("T03") && !text.includes("T08")
      };
    });

    // Clear search
    await page.evaluate((sel) => {
      document.querySelector(sel).value = "";
      document.querySelector(sel).dispatchEvent(new Event('input'));
    }, searchSel);
    await new Promise(r => setTimeout(r, 200));

    // T03: Filter Intersection
    // Step 1: Click "Cần xử lý"
    await page.evaluate(() => {
      const btn = document.querySelector('button[data-workflow="action"], button[data-group="action"]');
      if (btn) btn.click();
    });
    await new Promise(r => setTimeout(r, 200));
    const t03_step1 = await page.evaluate(() => {
      const items = Array.from(document.querySelectorAll('.tour-card, .ledger-item'));
      const text = items.map(el => el.innerText).join('\n');
      return {
        count: items.length,
        hasT01: text.includes("T01"),
        hasT03: text.includes("T03"),
        hasT06: text.includes("T06"),
        noT02: !text.includes("T02")
      };
    });

    // Step 2: Select Owner "Huy"
    const ownerSel = isCandidate ? '#select-tour-owner' : '#select-owner';
    await page.select(ownerSel, 'Huy');
    await new Promise(r => setTimeout(r, 200));
    const t03_step2 = await page.evaluate(() => {
      const items = Array.from(document.querySelectorAll('.tour-card, .ledger-item'));
      const text = items.map(el => el.innerText).join('\n');
      return {
        count: items.length,
        hasT03: text.includes("T03"),
        hasT06: text.includes("T06"),
        noT01: !text.includes("T01")
      };
    });

    // Step 3: Add Query "nha xe"
    await page.type(searchSel, "nha xe");
    await new Promise(r => setTimeout(r, 200));
    const t03_step3 = await page.evaluate(() => {
      const items = Array.from(document.querySelectorAll('.tour-card, .ledger-item'));
      const text = items.map(el => el.innerText).join('\n');
      return {
        count: items.length,
        hasT06: text.includes("T06"),
        noT03: !text.includes("T03")
      };
    });

    // Reset filters
    const resetBtnSel = isCandidate ? '#btn-reset-filters' : '#btn-reset';
    await page.click(resetBtnSel);
    await new Promise(r => setTimeout(r, 200));

    // T04: Independent Time Filter "Trong 48 giờ"
    const timeSel = isCandidate ? '#select-tour-time' : '#select-time';
    await page.select(timeSel, '48h');
    await new Promise(r => setTimeout(r, 200));
    const t04 = await page.evaluate(() => {
      const items = Array.from(document.querySelectorAll('.tour-card, .ledger-item'));
      const text = items.map(el => el.innerText).join('\n');
      return {
        count: items.length,
        hasT01: text.includes("T01"),
        hasT02: text.includes("T02"),
        noT03: !text.includes("T03"),
        noT08: !text.includes("T08")
      };
    });

    // Reset again
    await page.click(resetBtnSel);
    await new Promise(r => setTimeout(r, 200));

    // T05: Empty State & Reset Restoration
    await page.type(searchSel, "xyz_not_exist_query");
    await new Promise(r => setTimeout(r, 200));
    const t05_empty = await page.evaluate(() => {
      const items = document.querySelectorAll('.tour-card, .ledger-item');
      const emptyBox = document.querySelector('#empty-state, #empty-results-view');
      return {
        count: items.length,
        emptyBoxVisible: emptyBox && emptyBox.style.display !== 'none'
      };
    });

    await page.click(resetBtnSel);
    await new Promise(r => setTimeout(r, 200));
    const t05_reset = await page.evaluate((searchSel) => {
      const items = document.querySelectorAll('.tour-card, .ledger-item');
      const isInputFocused = document.activeElement === document.querySelector(searchSel);
      return { count: items.length, isInputFocused };
    }, searchSel);

    // T06: Detail Context Preservation
    // Set workflow filter to "action"
    await page.evaluate(() => {
      const btn = document.querySelector('button[data-workflow="action"], button[data-group="action"]');
      if (btn) btn.click();
    });
    // Open T03
    await page.evaluate(() => {
      const btnT03 = document.querySelector('#btn-detail-T03');
      if (btnT03) btnT03.click();
    });
    const t06_opened = await page.evaluate(() => {
      const detailScreen = document.querySelector('#screen-detail, #screen-detail-view');
      const text = detailScreen ? detailScreen.innerText : '';
      return { isOpen: detailScreen && detailScreen.style.display !== 'none', hasT03: text.includes("T03") && text.includes("Sapa") };
    });
    // Click Back
    await page.evaluate(() => {
      const backBtn = document.querySelector('#btn-back-to-list, #btn-back-to-ledger');
      if (backBtn) backBtn.click();
    });
    const t06_closed = await page.evaluate(() => {
      const detailScreen = document.querySelector('#screen-detail, #screen-detail-view');
      const listScreen = document.querySelector('#screen-list, #screen-list-view');
      const activeBtn = document.querySelector('.filter-btn[aria-pressed="true"], .seg-btn[aria-pressed="true"]');
      const focusTarget = document.activeElement;
      return {
        isDetailClosed: detailScreen && detailScreen.style.display === 'none',
        isListVisible: listScreen && listScreen.style.display !== 'none',
        preservedWorkflow: activeBtn ? (activeBtn.getAttribute('data-workflow') || activeBtn.getAttribute('data-group')) : null,
        focusRestoredToT03: focusTarget && focusTarget.id === 'btn-detail-T03'
      };
    });

    // Reset filters for FSM tests
    await page.click(resetBtnSel);
    await new Promise(r => setTimeout(r, 200));

    // Open T01 for FSM tests
    await page.evaluate(() => {
      const btnT01 = document.querySelector('#btn-detail-T01, #btn-hero-action-t01');
      if (btnT01) btnT01.click();
    });

    // T07: Validation on T01 form
    const formSel = isCandidate ? '#form-hotel-log' : '#form-contact-log';
    const noteSel = isCandidate ? '#textarea-hotel-note' : '#contact-note-input';
    const submitBtnSel = isCandidate ? '#btn-save-contact-note' : '#btn-submit-contact';
    const fbSel = isCandidate ? '#status-contact-feedback' : '#contact-feedback';

    // 1. Submit empty
    await page.evaluate((formSel, noteSel, submitBtnSel) => {
      document.querySelector(noteSel).value = "";
      document.querySelector(submitBtnSel).click();
    }, formSel, noteSel, submitBtnSel);
    const t07_empty = await page.evaluate((fbSel) => {
      const fb = document.querySelector(fbSel);
      const activeEl = document.activeElement;
      return {
        text: fb ? fb.innerText : '',
        isFocused: activeEl.tagName === 'TEXTAREA',
        pass: fb && fb.innerText.includes("Nhập nội dung liên hệ trước khi lưu")
      };
    }, fbSel);

    // 2. Submit 161 chars
    await page.evaluate((noteSel, submitBtnSel) => {
      document.querySelector(noteSel).value = "A".repeat(161);
      document.querySelector(submitBtnSel).click();
    }, noteSel, submitBtnSel);
    const t07_over = await page.evaluate((fbSel) => {
      const fb = document.querySelector(fbSel);
      const activeEl = document.activeElement;
      return {
        text: fb ? fb.innerText : '',
        isFocused: activeEl.tagName === 'TEXTAREA',
        pass: fb && fb.innerText.includes("Ghi chú cần tối đa 160 ký tự")
      };
    }, fbSel);

    // 3. Edit to 160 chars and clear error
    await page.evaluate((noteSel) => {
      document.querySelector(noteSel).value = "A".repeat(160);
      document.querySelector(noteSel).dispatchEvent(new Event('input'));
    }, noteSel);

    // T08 & T10: First Valid Submit Fails + Duplicate Guard
    await page.evaluate((noteSel) => {
      document.querySelector(noteSel).value = "Khách sạn Mường Thanh đã nghe máy, đang kiểm tra phòng.";
      document.querySelector(noteSel).dispatchEvent(new Event('input'));
    }, noteSel);

    // Click submit for Attempt 1
    await page.evaluate((submitBtnSel) => {
      document.querySelector(submitBtnSel).click();
    }, submitBtnSel);

    // Immediate check during saving:
    const t08_saving = await page.evaluate((fbSel, submitBtnSel, noteSel) => {
      const fb = document.querySelector(fbSel);
      const submitBtn = document.querySelector(submitBtnSel);
      const noteInput = document.querySelector(noteSel);
      return {
        isSavingText: fb ? fb.innerText.includes("Đang lưu") : false,
        isDisabled: submitBtn.disabled && noteInput.disabled,
        btnText: submitBtn.textContent
      };
    }, fbSel, submitBtnSel, noteSel);

    // T10 Duplicate Guard Test: Dispatch pointer click AND native Enter during saving
    const t10_dup = await page.evaluate((submitBtnSel, formSel) => {
      const btn = document.querySelector(submitBtnSel);
      const form = document.querySelector(formSel);
      
      // 1. Pointer click attempt
      btn.click();
      
      // 2. Form submit event attempt
      form.dispatchEvent(new Event('submit', { cancelable: true }));
      
      return {
        btnStillDisabled: btn.disabled,
        activeTag: document.activeElement ? document.activeElement.tagName : null
      };
    }, submitBtnSel, formSel);

    // Also dispatch native keyboard Enter on the page
    await page.keyboard.press('Enter');

    // Wait 900ms for delay to resolve attempt 1
    await new Promise(r => setTimeout(r, 900));

    const t08_result = await page.evaluate((fbSel, submitBtnSel, noteSel) => {
      const fb = document.querySelector(fbSel);
      const submitBtn = document.querySelector(submitBtnSel);
      const noteInput = document.querySelector(noteSel);
      const activeEl = document.activeElement;
      const attempts = typeof attemptCount !== 'undefined' ? attemptCount : (window.attemptCount || 1);
      const commits = typeof commitCount !== 'undefined' ? commitCount : (window.commitCount || 0);
      return {
        text: fb ? fb.innerText : '',
        btnText: submitBtn.textContent,
        btnId: submitBtn.id,
        isButtonFocused: activeEl === submitBtn,
        hasErrorMsg: fb && fb.innerText.includes("Chưa lưu được nhật ký liên hệ"),
        draftPreserved: noteInput.value === "Khách sạn Mường Thanh đã nghe máy, đang kiểm tra phòng.",
        attemptCount: attempts,
        commitCount: commits
      };
    }, fbSel, submitBtnSel, noteSel);

    // T09: Retry Succeeds via the SAME stable action button
    // User clicks the SAME button (which now says "Thử lưu lại")
    await page.evaluate((submitBtnSel) => {
      document.querySelector(submitBtnSel).click();
    }, submitBtnSel);

    // Check retry saving state
    const t09_saving = await page.evaluate((fbSel, submitBtnSel) => {
      const fb = document.querySelector(fbSel);
      const submitBtn = document.querySelector(submitBtnSel);
      return {
        isSaving: fb && fb.innerText.includes("Đang lưu"),
        btnText: submitBtn.textContent,
      };
    }, fbSel, submitBtnSel);

    // Wait 900ms for retry to complete
    await new Promise(r => setTimeout(r, 900));

    const t09_result = await page.evaluate((fbSel, submitBtnSel, isCandidate) => {
      const fb = document.querySelector(fbSel);
      const submitBtn = document.querySelector(submitBtnSel);
      const histList = document.querySelector(isCandidate ? '#committed-history-list' : '#committed-activities-list');
      const tourT01 = (typeof CANONICAL_TOURS !== 'undefined' ? CANONICAL_TOURS : (window.CANONICAL_TOURS || [])).find(t => t.id === "T01");
      const statusEl = document.querySelector(isCandidate ? '#d-val-status' : '#detail-tour-status');
      const attempts = typeof attemptCount !== 'undefined' ? attemptCount : (window.attemptCount || 2);
      const commits = typeof commitCount !== 'undefined' ? commitCount : (window.commitCount || 1);
      return {
        hasSuccessMsg: fb && (fb.innerText.includes("Đã lưu nhật ký") || fb.innerText.includes("thành công")),
        committedCount: histList ? histList.children.length : 0,
        committedText: histList && histList.lastElementChild ? histList.lastElementChild.innerText : '',
        canonicalStatusRemains: Boolean((tourT01 && tourT01.status === "Chờ đối tác") || (statusEl && statusEl.textContent.includes("Chờ đối tác"))),
        btnText: submitBtn.textContent,
        attemptCount: attempts,
        commitCount: commits
      };
    }, fbSel, submitBtnSel, isCandidate);

    // T13: Safe Rendering Test (XSS check)
    await page.evaluate((noteSel, submitBtnSel) => {
      document.querySelector(noteSel).value = '<b>Đã gọi & "xác nhận"</b>';
      document.querySelector(submitBtnSel).click();
    }, noteSel, submitBtnSel);
    await new Promise(r => setTimeout(r, 900));

    const t13_safe = await page.evaluate((isCandidate) => {
      const histList = document.querySelector(isCandidate ? '#committed-history-list' : '#committed-activities-list');
      const lastItem = histList ? histList.lastElementChild : null;
      if (!lastItem) return { noTagsParsed: false };
      const rawHtml = lastItem.innerHTML;
      const rawText = lastItem.innerText;
      return {
        rawText,
        rawHtml,
        noTagsParsed: !rawHtml.includes('<b>') && rawHtml.includes('&lt;b&gt;')
      };
    }, isCandidate);

    return {
      t01,
      t02,
      t03_step1,
      t03_step2,
      t03_step3,
      t04,
      t05_empty,
      t05_reset,
      t06_opened,
      t06_closed,
      t07_empty,
      t07_over,
      t08_saving,
      t10_dup,
      t08_result,
      t09_saving,
      t09_result,
      t13_safe
    };
  }

  // 1. Audit Baseline
  console.log('[TESTING BASELINE]');
  const baselineAudit = await testPageCore(baselinePath, false);

  // 2. Audit Candidate Final
  console.log('[TESTING CANDIDATE]');
  const candidateAudit = await testPageCore(candidatePath, true);

  // 3. T11: Native Hardware Keyboard Journey on Mobile 390x844
  console.log('[TESTING T11: Native Keyboard Journey on Mobile 390x844]');
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
  await page.goto(candidatePath, { waitUntil: 'load' });

  const keyboardLogs = [];
  let stepIndex = 0;

  async function recordStep(keyName, expectedTag) {
    stepIndex++;
    const state = await page.evaluate(() => {
      const el = document.activeElement;
      const rect = el ? el.getBoundingClientRect() : null;
      const inView = rect ? (rect.top >= 0 && rect.bottom <= window.innerHeight) : false;
      return {
        tag: el ? el.tagName : null,
        id: el ? el.id : null,
        isBody: el === document.body,
        inView
      };
    });
    keyboardLogs.push({
      step: stepIndex,
      key: keyName,
      tag: state.tag,
      id: state.id,
      inViewport: state.inView,
      focusInBody: state.isBody
    });
    return state;
  }

  // Tab 1: Hero Action
  await page.keyboard.press('Tab');
  await recordStep('Tab', 'BUTTON');

  // Tab 2: Search Input
  await page.keyboard.press('Tab');
  const searchFocus = await recordStep('Tab', 'INPUT');

  // Type search "T01"
  await page.keyboard.type('T01');
  await new Promise(r => setTimeout(r, 200));

  // Tab through to detail button of T01 (up to 15 tabs to reach #btn-detail-T01)
  let detailFound = false;
  for (let i = 0; i < 15; i++) {
    await page.keyboard.press('Tab');
    const s = await recordStep('Tab', 'BUTTON');
    if (s.id === 'btn-detail-T01') {
      detailFound = true;
      break;
    }
  }

  // Enter to open detail
  await page.keyboard.press('Enter');
  await new Promise(r => setTimeout(r, 400));
  await recordStep('Enter', 'BUTTON');

  // Tab to textarea
  for (let i = 0; i < 4; i++) {
    await page.keyboard.press('Tab');
    const s = await recordStep('Tab', 'TEXTAREA');
    if (s.tag === 'TEXTAREA') break;
  }

  // Type note
  await page.keyboard.type('Keyboard traversal contact note for hotel verification.');

  // Tab to Submit button
  await page.keyboard.press('Tab');
  await recordStep('Tab', 'BUTTON');

  // Enter to submit (Attempt 1 fails) - wait 900ms for async FSM error state before recording step
  await page.keyboard.press('Enter');
  await new Promise(r => setTimeout(r, 900));
  await recordStep('Enter', 'BUTTON');

  // Button is now "Thử lưu lại" with focus kept on it!
  const retryBtnState = await page.evaluate(() => ({
    id: document.activeElement ? document.activeElement.id : null,
    text: document.activeElement ? document.activeElement.textContent : null
  }));

  // Enter to Retry (Attempt 2 succeeds) - wait 900ms for async FSM success state before recording step
  await page.keyboard.press('Enter');
  await new Promise(r => setTimeout(r, 900));
  await recordStep('Enter', 'BUTTON');

  // Shift+Tab back to Back button
  for (let i = 0; i < 6; i++) {
    await page.keyboard.down('Shift');
    await page.keyboard.press('Tab');
    await page.keyboard.up('Shift');
    const s = await recordStep('Shift+Tab', 'BUTTON');
    if (s.id === 'btn-back-to-ledger') break;
  }

  // Enter on Back to Ledger - wait 400ms for detail view close and focus restoration to trigger
  await page.keyboard.press('Enter');
  await new Promise(r => setTimeout(r, 400));
  await recordStep('Enter', 'BUTTON');

  // Verify focus restored to #btn-detail-T01
  const focusRestoredAfterKeyboard = await page.evaluate(() => {
    return document.activeElement ? document.activeElement.id : null;
  });

  const t11_pass = keyboardLogs.every(log => !log.focusInBody) &&
                   focusRestoredAfterKeyboard === 'btn-detail-T01' &&
                   retryBtnState.text === "Thử lưu lại";

  // 4. T12: Responsive Viewport, Contrast, Zero Motion & Target Size
  console.log('[TESTING T12: Responsive Viewport, Contrast, Zero Motion]');
  const viewports = [
    { name: 'desktop', width: 1440, height: 900 },
    { name: 'tablet', width: 768, height: 1024 },
    { name: 'mobile', width: 390, height: 844 }
  ];

  const viewportMeasurements = [];
  for (const vp of viewports) {
    await page.setViewport({ width: vp.width, height: vp.height, deviceScaleFactor: 2 });
    await page.goto(candidatePath, { waitUntil: 'load' });
    const overflow = await page.evaluate(() => ({
      scrollWidth: document.documentElement.scrollWidth,
      clientWidth: document.documentElement.clientWidth,
      hasOverflow: document.documentElement.scrollWidth > document.documentElement.clientWidth
    }));
    viewportMeasurements.push({ ...vp, ...overflow });
  }

  // Baseline overflow measurement
  const baselineOverflows = [];
  for (const vp of viewports) {
    await page.setViewport({ width: vp.width, height: vp.height, deviceScaleFactor: 2 });
    await page.goto(baselinePath, { waitUntil: 'load' });
    const overflow = await page.evaluate(() => ({
      scrollWidth: document.documentElement.scrollWidth,
      clientWidth: document.documentElement.clientWidth,
      hasOverflow: document.documentElement.scrollWidth > document.documentElement.clientWidth
    }));
    baselineOverflows.push({ ...vp, ...overflow });
  }

  // Measure ScrollHeight difference between Pre-Critique and Candidate Final at 390px
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
  await page.goto(preCritiquePath, { waitUntil: 'load' });
  const preCritiqueScrollHeight = await page.evaluate(() => document.documentElement.scrollHeight);

  await page.goto(candidatePath, { waitUntil: 'load' });
  const candidateScrollHeight = await page.evaluate(() => document.documentElement.scrollHeight);
  const scrollHeightDifference = preCritiqueScrollHeight - candidateScrollHeight;
  console.log(`[SCROLL HEIGHT] Pre-Critique: ${preCritiqueScrollHeight}px | Final: ${candidateScrollHeight}px | Reduction: ${scrollHeightDifference}px`);

  // Target Size Audit at 390px
  const targetSizes = await page.evaluate(() => {
    function auditVisible(sel) {
      const els = Array.from(document.querySelectorAll(sel));
      return els.filter(el => el.offsetParent !== null).map(el => {
        const r = el.getBoundingClientRect();
        return {
          selector: sel,
          id: el.id,
          text: el.innerText.trim().slice(0, 20),
          width: Math.round(r.width),
          height: Math.round(r.height),
          pass: r.width >= 44 && r.height >= 44
        };
      });
    }

    const listSelectors = [
      '.btn-open-detail',
      '.seg-btn',
      '.btn-clear-action',
      '.btn-urgent-action',
      '.owner-select'
    ];
    let results = [];
    listSelectors.forEach(sel => {
      results = results.concat(auditVisible(sel));
    });

    // Open detail view to audit detail buttons
    const detailBtn = document.querySelector('#btn-detail-T01');
    if (detailBtn) detailBtn.click();

    const detailSelectors = [
      '.btn-action-primary',
      '#btn-back-to-ledger'
    ];
    detailSelectors.forEach(sel => {
      results = results.concat(auditVisible(sel));
    });

    // Restore back to list view
    const backBtn = document.querySelector('#btn-back-to-ledger');
    if (backBtn) backBtn.click();

    // Audit empty state reset button when empty state is displayed
    const emptyView = document.querySelector('#empty-results-view');
    if (emptyView) {
      emptyView.style.display = 'flex';
      results = results.concat(auditVisible('#empty-results-view .btn-clear-action'));
      emptyView.style.display = 'none';
    }

    return results;
  });
  const allTargetSizesPass = targetSizes.every(t => t.pass);

  // Contrast measurements on Candidate (No fallback || 5 allowed!)
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
  await page.goto(candidatePath, { waitUntil: 'load' });
  const contrastPairs = await page.evaluate(() => {
    function getComputedColors(sel) {
      const el = document.querySelector(sel);
      if (!el) return null;
      const s = window.getComputedStyle(el);
      return { color: s.color, bg: s.backgroundColor };
    }
    return {
      bodyText: getComputedColors('.t-tour-name'),
      notesText: getComputedColors('.t-tour-notes'),
      urgentHeading: getComputedColors('.urgent-tour-heading'),
      statusAction: getComputedColors('.status-action'),
      statusReady: getComputedColors('.status-ready'),
      statusMissing: getComputedColors('.status-missing'),
      statusPrep: getComputedColors('.status-prep'),
      statusDone: getComputedColors('.status-done')
    };
  });

  const computedContrasts = {};
  if (contrastPairs.bodyText) {
    computedContrasts.bodyText = getContrast(parseRgb(contrastPairs.bodyText.color), [255, 255, 255]).toFixed(2);
  }
  if (contrastPairs.notesText) {
    computedContrasts.notesText = getContrast(parseRgb(contrastPairs.notesText.color), [255, 255, 255]).toFixed(2);
  }
  if (contrastPairs.urgentHeading) {
    computedContrasts.urgentHeading = getContrast(parseRgb(contrastPairs.urgentHeading.color), [255, 251, 235]).toFixed(2);
  }
  if (contrastPairs.statusAction) {
    computedContrasts.statusAction = getContrast(parseRgb(contrastPairs.statusAction.color), parseRgb(contrastPairs.statusAction.bg)).toFixed(2);
  }
  if (contrastPairs.statusReady) {
    computedContrasts.statusReady = getContrast(parseRgb(contrastPairs.statusReady.color), parseRgb(contrastPairs.statusReady.bg)).toFixed(2);
  }
  if (contrastPairs.statusMissing) {
    computedContrasts.statusMissing = getContrast(parseRgb(contrastPairs.statusMissing.color), parseRgb(contrastPairs.statusMissing.bg)).toFixed(2);
  }
  if (contrastPairs.statusPrep) {
    computedContrasts.statusPrep = getContrast(parseRgb(contrastPairs.statusPrep.color), parseRgb(contrastPairs.statusPrep.bg)).toFixed(2);
  }
  if (contrastPairs.statusDone) {
    computedContrasts.statusDone = getContrast(parseRgb(contrastPairs.statusDone.color), parseRgb(contrastPairs.statusDone.bg)).toFixed(2);
  }

  const allContrastsPass = Object.values(computedContrasts).every(c => parseFloat(c) >= 4.5);

  // Full DOM Zero Motion Audit
  const zeroMotionAudit = await page.evaluate(() => {
    const els = Array.from(document.querySelectorAll('*'));
    let violations = 0;
    els.forEach(el => {
      const cs = window.getComputedStyle(el);
      if (cs.transitionDuration !== '0s' && cs.transitionProperty !== 'none') violations++;
      if (cs.animationDuration !== '0s' && cs.animationName !== 'none') violations++;
    });
    return { scanned: els.length, violations, isZeroMotion: violations === 0 };
  });

  // 5. Capture all 12 required screenshots
  console.log('[CAPTURING 12 REQUIRED SCREENSHOTS]');

  // 1. baseline_desktop_1440x900.png
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
  await page.goto(baselinePath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'baseline_desktop_1440x900.png') });

  // 2. baseline_mobile_390x844.png
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
  await page.goto(baselinePath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'baseline_mobile_390x844.png') });

  // 3. direction_a_desktop_1440x900.png
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
  await page.goto(directionAPath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'direction_a_desktop_1440x900.png') });

  // 4. direction_b_desktop_1440x900.png
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
  await page.goto(directionBPath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'direction_b_desktop_1440x900.png') });

  // 5. pre_critique_desktop_1440x900.png
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
  await page.goto(preCritiquePath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'pre_critique_desktop_1440x900.png') });

  // 6. pre_critique_mobile_390x844.png
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
  await page.goto(preCritiquePath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'pre_critique_mobile_390x844.png') });

  // 7. candidate_final_desktop_1440x900.png
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
  await page.goto(candidatePath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'candidate_final_desktop_1440x900.png') });

  // 8. candidate_final_tablet_768x1024.png
  await page.setViewport({ width: 768, height: 1024, deviceScaleFactor: 2 });
  await page.goto(candidatePath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'candidate_final_tablet_768x1024.png') });

  // 9. candidate_final_mobile_390x844.png
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
  await page.goto(candidatePath, { waitUntil: 'load' });
  await page.screenshot({ path: path.join(screenshotsDir, 'candidate_final_mobile_390x844.png') });

  // 10. candidate_t01_error_mobile_390x844.png
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
  await page.goto(candidatePath, { waitUntil: 'load' });
  await page.click('#btn-hero-action-t01');
  await page.type('#textarea-hotel-note', 'Khách sạn Mường Thanh phản hồi bận.');
  await page.click('#btn-save-contact-note');
  await new Promise(r => setTimeout(r, 900));
  await page.screenshot({ path: path.join(screenshotsDir, 'candidate_t01_error_mobile_390x844.png') });

  // 11. candidate_t01_retry_saving_mobile_390x844.png
  // Trigger retry and capture screenshot immediately during saving!
  page.click('#btn-save-contact-note');
  await new Promise(r => setTimeout(r, 100)); // capture during 800ms saving
  await page.screenshot({ path: path.join(screenshotsDir, 'candidate_t01_retry_saving_mobile_390x844.png') });

  // 12. candidate_t01_success_mobile_390x844.png
  await new Promise(r => setTimeout(r, 800)); // wait for success
  await page.screenshot({ path: path.join(screenshotsDir, 'candidate_t01_success_mobile_390x844.png') });

  console.log('✓ All 12 screenshots captured successfully!');

  // T14: Baseline / Candidate Parity Check with Deep Comparisons
  const t14_parity = {
    t01_parity: JSON.stringify(baselineAudit.t01.deepTuples) === JSON.stringify(candidateAudit.t01.deepTuples),
    t02_parity: baselineAudit.t02.matchedCount === candidateAudit.t02.matchedCount &&
                baselineAudit.t02.hasT01 === candidateAudit.t02.hasT01,
    t03_parity: baselineAudit.t03_step1.count === candidateAudit.t03_step1.count &&
                baselineAudit.t03_step2.count === candidateAudit.t03_step2.count &&
                baselineAudit.t03_step3.count === candidateAudit.t03_step3.count,
    t04_parity: baselineAudit.t04.count === candidateAudit.t04.count &&
                baselineAudit.t04.hasT01 === candidateAudit.t04.hasT01 &&
                baselineAudit.t04.hasT02 === candidateAudit.t04.hasT02,
    t05_parity: baselineAudit.t05_empty.count === candidateAudit.t05_empty.count &&
                baselineAudit.t05_reset.count === candidateAudit.t05_reset.count &&
                baselineAudit.t05_reset.isInputFocused === candidateAudit.t05_reset.isInputFocused,
    t06_parity: baselineAudit.t06_opened.isOpen === candidateAudit.t06_opened.isOpen &&
                baselineAudit.t06_closed.isDetailClosed === candidateAudit.t06_closed.isDetailClosed &&
                baselineAudit.t06_closed.focusRestoredToT03 === candidateAudit.t06_closed.focusRestoredToT03,
    t07_parity: baselineAudit.t07_empty.pass === candidateAudit.t07_empty.pass &&
                baselineAudit.t07_over.pass === candidateAudit.t07_over.pass,
    t08_parity: baselineAudit.t08_result.hasErrorMsg === candidateAudit.t08_result.hasErrorMsg &&
                baselineAudit.t08_result.attemptCount === candidateAudit.t08_result.attemptCount &&
                baselineAudit.t08_result.commitCount === candidateAudit.t08_result.commitCount,
    t09_parity: baselineAudit.t09_result.hasSuccessMsg === candidateAudit.t09_result.hasSuccessMsg &&
                baselineAudit.t09_result.committedCount === candidateAudit.t09_result.committedCount &&
                baselineAudit.t09_result.canonicalStatusRemains === candidateAudit.t09_result.canonicalStatusRemains &&
                baselineAudit.t09_result.attemptCount === candidateAudit.t09_result.attemptCount &&
                baselineAudit.t09_result.commitCount === candidateAudit.t09_result.commitCount,
    t10_parity: baselineAudit.t10_dup.btnStillDisabled === candidateAudit.t10_dup.btnStillDisabled,
    t13_parity: baselineAudit.t13_safe.noTagsParsed === candidateAudit.t13_safe.noTagsParsed
  };

  // Compile full verification output assertions
  const verificationOutput = {
    metadata: {
      directive_id: "DESIGN_TRAINING_007",
      module: 7,
      stage: "TRANSFER_TESTING_ON_NEW_BRIEF",
      repair_round: "1/2",
      submission_id: "DESIGN_TRAINING_007_REPAIR_001",
      timestamp: new Date().toISOString(),
      executor: "Antigravity Senior Engineering Agent",
      environment: {
        platform: process.platform,
        cdpPort: port,
        nodeVersion: process.version
      },
      hashes: {
        baseline: baselineHash,
        pre_critique: preCritiqueHash,
        candidate_final: candidateHash
      }
    },
    assertions: {
      T01_initial_data_integrity: {
        pass: candidateAudit.t01.allPresent && candidateAudit.t01.count === 8 && candidateAudit.t01.hasT08,
        measured: candidateAudit.t01
      },
      T02_vietnamese_search: {
        pass: candidateAudit.t02.matchedCount === 1 && candidateAudit.t02.hasT01 && candidateAudit.t02.noOther,
        measured: candidateAudit.t02
      },
      T03_filter_intersection: {
        pass: candidateAudit.t03_step1.count === 3 && candidateAudit.t03_step2.count === 2 && candidateAudit.t03_step3.count === 1,
        measured: {
          step1: candidateAudit.t03_step1,
          step2: candidateAudit.t03_step2,
          step3: candidateAudit.t03_step3
        }
      },
      T04_time_filter: {
        pass: candidateAudit.t04.count === 2 && candidateAudit.t04.hasT01 && candidateAudit.t04.hasT02 && candidateAudit.t04.noT03,
        measured: candidateAudit.t04
      },
      T05_empty_and_reset: {
        pass: candidateAudit.t05_empty.count === 0 && candidateAudit.t05_empty.emptyBoxVisible && candidateAudit.t05_reset.count === 8 && candidateAudit.t05_reset.isInputFocused,
        measured: {
          empty: candidateAudit.t05_empty,
          reset: candidateAudit.t05_reset
        }
      },
      T06_detail_context_preservation: {
        pass: candidateAudit.t06_opened.isOpen && candidateAudit.t06_closed.isDetailClosed && candidateAudit.t06_closed.focusRestoredToT03,
        measured: {
          opened: candidateAudit.t06_opened,
          closed: candidateAudit.t06_closed
        }
      },
      T07_validation: {
        pass: candidateAudit.t07_empty.pass && candidateAudit.t07_empty.isFocused && candidateAudit.t07_over.pass && candidateAudit.t07_over.isFocused,
        measured: {
          empty: candidateAudit.t07_empty,
          over: candidateAudit.t07_over
        }
      },
      T08_first_valid_submit_fails: {
        pass: candidateAudit.t08_result.hasErrorMsg && candidateAudit.t08_result.draftPreserved && candidateAudit.t08_result.attemptCount === 1 && candidateAudit.t08_result.commitCount === 0 && candidateAudit.t08_result.btnText === "Thử lưu lại",
        measured: candidateAudit.t08_result
      },
      T09_retry_succeeds: {
        pass: Boolean(candidateAudit.t09_result.hasSuccessMsg && candidateAudit.t09_result.committedCount === 1 && candidateAudit.t09_result.canonicalStatusRemains && candidateAudit.t09_result.attemptCount === 2 && candidateAudit.t09_result.commitCount === 1 && candidateAudit.t09_result.btnText === "Lưu nhật ký"),
        measured: candidateAudit.t09_result
      },
      T10_duplicate_guard: {
        pass: candidateAudit.t10_dup.btnStillDisabled === true && candidateAudit.t08_result.attemptCount === 1 && candidateAudit.t08_result.commitCount === 0,
        measured: candidateAudit.t10_dup
      },
      T11_native_keyboard_journey: {
        pass: t11_pass,
        measured: {
          totalSteps: keyboardLogs.length,
          logs: keyboardLogs,
          focusRestored: focusRestoredAfterKeyboard
        }
      },
      T12_responsive_contrast_zero_motion: {
        pass: viewportMeasurements.every(v => !v.hasOverflow) &&
              baselineOverflows.every(v => !v.hasOverflow) &&
              allContrastsPass &&
              allTargetSizesPass &&
              zeroMotionAudit.isZeroMotion,
        measured: {
          viewports: viewportMeasurements,
          baselineViewports: baselineOverflows,
          contrasts: computedContrasts,
          targetSizesPass: allTargetSizesPass,
          zeroMotion: zeroMotionAudit,
          critiqueCadenceMeasurement: {
            preCritiqueScrollHeight,
            candidateScrollHeight,
            reductionPixels: scrollHeightDifference
          }
        }
      },
      T13_safe_rendering: {
        pass: candidateAudit.t13_safe.noTagsParsed,
        measured: candidateAudit.t13_safe
      },
      T14_baseline_candidate_parity: {
        pass: Object.values(t14_parity).every(v => v === true),
        measured: t14_parity
      }
    }
  };

  // Controller Mandated Overall Verdict Formula: Conjunction of ALL T01-T14
  const assertionEntries = Object.values(verificationOutput.assertions);
  const allPassed = assertionEntries.every(test => test.pass === true);

  verificationOutput.verdict = allPassed ? "PASS" : "FAIL";
  verificationOutput.self_assessment = allPassed ? "READY_FOR_CONTROLLER_REVIEW" : "REPAIR_REQUIRED";

  const outputPath = path.join(baseDir, 'VERIFICATION.json');
  fs.writeFileSync(outputPath, JSON.stringify(verificationOutput, null, 2), 'utf8');
  console.log(`[SAVED] VERIFICATION.json saved to: ${outputPath}`);
  console.log(`Overall Test Verdict: ${verificationOutput.verdict}`);
  console.log(`Self Assessment: ${verificationOutput.self_assessment}`);
  console.log('=== VERIFICATION COMPLETED ===');

  await page.close();
  await browser.disconnect();

  if (!allPassed) {
    console.error('ERROR: One or more assertions failed!');
    process.exit(1);
  }
  process.exit(0);
}

runTests().catch(err => {
  console.error('[FATAL ERROR IN TEST SUITE]', err);
  process.exit(1);
});
