# BÁO CÁO NGHIỆM THU MODULE 06: DESIGN CRITIQUE
**Phản biện thiết kế dựa trên bằng chứng & Thử nghiệm cải tiến có giới hạn**

- **Mã nộp bài (Submission Code)**: `DESIGN_TRAINING_006_SUBMISSION_R01`
- **Mã Module**: `DESIGN_TRAINING_006` (Design Critique — Phản biện thiết kế dựa trên bằng chứng)
- **Executor (Tác tử thi hành)**: Antigravity (Senior AI Pair-Programmer)
- **Reviewer (Bộ điều khiển kiến trúc)**: ChatGPT Controller
- **Product Owner / Taste Authority**: Anh — Lead Architect / Product Owner
- **Trạng thái (Status)**: `READY_FOR_CONTROLLER_REVIEW`
- **Ngân sách sửa (Repair Budget)**: Vòng 1 / Tối đa 2 vòng

---

## 1. Nguồn gốc & Tính xác thực của Baseline (Q01)

Bài tập Module 06 sử dụng bản sao chính xác từ kết quả nghiệm thu **Module 05 Rev 002**:
- **Gói nộp nguồn gốc (Source Archive)**: `exercises/design_training_005/design_training_005_submission_r02.zip`
- **Mã băm SHA-256 đã xác minh**: `12302f8c948dd48126cb756f20c4e64639642eba8394a0501006c6034c850bf1`
- **Trạng thái hợp đồng nguồn**: Hướng B (`ACCEPTED_FOR_EXERCISE`), phán quyết `DESIGN_TRAINING_005_FINAL_REVIEW_002.md` (`PASS — MODULE_COMPLETED: true`).
- **Thư mục lưu trữ**:
  - `baseline/index.html`: Bản sao nguyên vẹn 100% từ mã nguồn đã vượt qua Module 05.
  - `baseline/DESIGN_CONTRACT.yaml`: Hợp đồng thiết kế kèm trạng thái nghiệm thu Module 05.
- **Đối chiếu mã băm tự động**: Xác nhận khớp tuyệt đối với kỳ vọng (`hash_matched: true` trong `VERIFICATION.json`).

---

## 2. Vòng quan sát ban đầu — Bảng nhận xét phân loại (Q02)

Quá trình khảo sát được tiến hành khách quan trên Baseline tại hai khung nhìn chuẩn: Desktop 1440×900 và Mobile 390×844 (DPR = 2), bao gồm màn hình đầu trang (above the fold) và toàn bộ nội dung khi cuộn trang.

Dưới đây là 5 nhận xét được phân loại nghiêm ngặt theo 4 danh mục: `strength (điểm mạnh)`, `tradeoff (đánh đổi)`, `preference (sở thích)`, `defect (lỗi hiển thị/chức năng)`:

### C01: [STRENGTH] Hiển thị bảng thích ứng 2 dòng trên màn hình di động
- **id**: `C01`
- **location**: `Section 02 Data Matrix` trên Mobile (390×844), file `baseline/index.html` dòng 590–630; minh chứng tại `screenshots/baseline_mobile_fullpage.png`.
- **observation**: Cấu trúc bảng trên màn hình hẹp (<600px) tự động chuyển sang dạng thẻ danh sách phân dòng thông minh: Dòng 1 hiển thị đầy đủ tên tài liệu kèm biểu tượng mà không bị cắt cụt; Dòng 2 bố trí người phụ trách bên trái và huy hiệu trạng thái bên phải.
- **interpretation**: Giúp người dùng lướt nhanh tình trạng 3 tài liệu trọng yếu mà không cần thao tác cuộn ngang (horizontal scroll) và không bị hiện tượng chồng chéo nhãn.
- **classification**: `strength`
- **user_task**: "Kiểm tra nhanh tình trạng và quyền sở hữu tài liệu khi truy cập trên thiết bị di động".
- **evidence**:
  - kind: `visual`
  - reference: `screenshots/baseline_mobile_fullpage.png`
- **confidence**: `high`
- **recommendation**: `keep`
- **reason**: Đây là thế mạnh cốt lõi đã giải quyết triệt để lỗi F01 từ Module 05; cấu trúc này đảm bảo trải nghiệm đọc tối ưu trên màn hình nhỏ và cần được bảo vệ nguyên vẹn.

---

### C02: [TRADEOFF] Độ nặng hình khối hộp (Boxiness Fatigue) tại Section 03 trên Desktop
- **id**: `C02`
- **location**: `Section 03 ('Quyết định thiết kế')` trên Desktop (1440×900), file `baseline/index.html` dòng 450–480; minh chứng tại `screenshots/baseline_desktop_fullpage.png`.
- **observation**: Ba khối thẻ card độc lập đều sử dụng nền trắng (`--color-surface`), bo góc (`border-radius: 4px`), viền xám (`1px solid --color-border`) và bóng đổ nổi (`box-shadow`), đặt cạnh nhau trên nền xám nhạt (`--color-bg: #F8FAFC`).
- **interpretation**: Việc lặp lại liên tiếp các khối hộp đóng kín (sau khối Hero Preview và Section 02 Data Matrix Table) tạo cảm giác phân mảnh thị giác và bão hòa hình khối hộp ("boxiness fatigue"), làm tăng độ nặng thị giác không cần thiết và giảm nhịp thở mở của trang web kỹ thuật.
- **classification**: `tradeoff`
- **user_task**: "Đọc hiểu 3 nguyên tắc thiết kế cốt lõi của hệ thống TRACE một cách liền mạch, thanh thoát".
- **evidence**:
  - kind: `visual`
  - reference: `screenshots/baseline_desktop_fullpage.png`
- **confidence**: `high`
- **recommendation**: `experiment`
- **reason**: Có cơ sở thị giác rõ ràng để thử nghiệm chuyển đổi từ 3 khối hộp rời rạc sang một cấu trúc cột kiến trúc mở (Architectural Column Structure) phân cách bằng đường hairline dọc tinh tế, nhằm tạo nhịp thở thoáng đãng và phân tầng kiến trúc cao cấp hơn.

---

### C03: [TRADEOFF] Trùng lặp mẫu vật tài liệu giữa Hero Specimen và Section 02 Table
- **id**: `C03`
- **location**: `Hero Section Specimen Card`, file `baseline/index.html` dòng 210–265; minh chứng tại `screenshots/baseline_desktop_fullpage.png`.
- **observation**: Khung xem trước trong Hero hiển thị 3 hàng tài liệu thu nhỏ, lặp lại chính xác 3 đối tượng tài liệu được trình bày đầy đủ ở Section 02 Data Matrix Table ngay bên dưới.
- **interpretation**: Đánh đổi tính cô đọng dữ liệu để đổi lấy bằng chứng trực quan tức thì ngay tại màn hình đầu tiên (above the fold), giúp người xem nắm bắt ngay bản chất của công cụ mà chưa cần cuộn chuột.
- **classification**: `tradeoff`
- **user_task**: "Hiểu ngay công năng và giao diện của TRACE ngay khi vừa truy cập trang web".
- **evidence**:
  - kind: `visual`
  - reference: `screenshots/baseline_desktop_fullpage.png`
- **confidence**: `medium`
- **recommendation**: `keep`
- **reason**: Đây là một sự đánh đổi có chủ đích và có lợi ích rõ rệt đối với trang giới thiệu công cụ kỹ thuật. Việc loại bỏ mẫu vật sẽ khiến màn hình Hero bị rỗng và giảm tính thuyết phục trực quan.

---

### C04: [PREFERENCE] Tông nền Slate-50 lạnh so với tông ấm / trung tính
- **id**: `C04`
- **location**: Biến màu nền toàn trang `--color-bg: #F8FAFC` (Slate-50), file `baseline/index.html` dòng 34.
- **observation**: Trang sử dụng nền xám ánh lam lạnh (Slate-50) kết hợp viền Slate-200, thay vì các tông màu kem ấm (Warm Beige / Sand) hay trung tính hoàn toàn (Zinc / Neutral Gray).
- **interpretation**: Lựa chọn này phản ánh gu thẩm mỹ định hướng công cụ hạ tầng kỹ thuật (Developer Tooling / Enterprise Console) hơn là phong cách tạp chí xuất bản hay phần mềm nghệ thuật.
- **classification**: `preference`
- **user_task**: "Cảm nhận bản sắc thương hiệu và độ tin cậy chuyên nghiệp của hệ thống công cụ".
- **evidence**:
  - kind: `code`
  - reference: `baseline/index.html:L34`
- **confidence**: `medium`
- **recommendation**: `keep`
- **reason**: Đây là sở thích thẩm mỹ phù hợp với bản sắc "công cụ vận hành kỹ thuật", đạt độ tương phản văn bản 14.8:1 (vượt xa chuẩn WCAG AAA). Không có bất kỳ khiếm khuyết chức năng nào đòi hỏi phải thay đổi.

---

### C05: [STRENGTH] Ràng buộc Zero Motion & Cuộn trang tức thì (Instant Scroll)
- **id**: `C05`
- **location**: CSS Reset & Typography, file `baseline/index.html` dòng 24–28 (`scroll-behavior: auto !important`), transition / animation = none.
- **observation**: Toàn bộ hệ thống giao diện không có bất kỳ hiệu ứng chuyển cảnh mềm, phóng to thu nhỏ (hover scale) hay animation tự động nào khi tải trang hoặc tương tác.
- **interpretation**: Đảm bảo tốc độ hiển thị tức thì, giảm tải xử lý GPU, không gây mệt mỏi thị giác hoặc chóng mặt đối với người dùng nhạy cảm chuyển động (vestibular disorders).
- **classification**: `strength`
- **user_task**: "Điều hướng nhanh, tra cứu và kiểm tra thông tin mà không bị chậm trễ bởi chuyển động thừa".
- **evidence**:
  - kind: `runtime`
  - reference: `VERIFICATION.json` (`zeroMotion: true`)
- **confidence**: `high`
- **recommendation**: `keep`
- **reason**: Tuân thủ tuyệt đối quy tắc Zero Motion của toàn bộ khóa huấn luyện, là điểm mạnh về tính tin cậy và hiệu năng kỹ thuật cần được bảo toàn 100%.

---

## 3. Kế hoạch thử nghiệm: Một giả thuyết & Tối đa hai thay đổi (Q03)

Dựa trên nhận xét `C02 (tradeoff)`, Antigravity xây dựng bản thử nghiệm cải tiến tại `candidate/index.html`:

### 3.1. Giả thuyết khoa học (Single Hypothesis)
> *"Nếu tại Section 03 ('Quyết định thiết kế'), chúng ta chuyển từ 3 thẻ hộp đóng kín độc lập sang cấu trúc 3 cột kiến trúc mở (Architectural Column Structure) phân cách bằng đường kẻ hairline dọc tinh tế trên desktop kết hợp số thứ tự monospace dạng thẻ nhãn kỹ thuật, thì sẽ giảm bớt độ nặng hình khối hộp (boxiness fatigue), tạo nhịp thở mở và tăng tính phân tầng kiến trúc giữa các khối nội dung, trong khi vẫn bảo toàn 100% nội dung văn bản và khả năng đọc trên mobile."*

### 3.2. Bằng chứng ban đầu (Initial Evidence)
Quan sát thực tế tại `screenshots/baseline_desktop_fullpage.png` cho thấy sự xuất hiện dồn dập của 3 khối card bo góc viền kép ngay sau Section 02 tạo cảm giác nặng nề, cạnh tranh thị giác trực tiếp với bảng dữ liệu trọng tâm.

### 3.3. Điều bắt buộc phải giữ (Invariants to Preserve)
- 100% nội dung nguyên bản của 3 quyết định thiết kế (Typography, Bố cục, Hình ảnh).
- 3 hàng dữ liệu chuẩn, trạng thái và chủ sở hữu của Module 05.
- 2 liên kết CTA điều hướng (`cta-organization`, `cta-decisions`).
- Thuộc tính Zero Motion (`animation: none`, `transition: none`, `scroll-behavior: auto`).
- Độ tương phản WCAG AA/AAA và hoàn toàn không có thanh cuộn ngang ở mọi kích thước màn hình.

### 3.4. Cách thức so sánh (Fair Comparison Protocol)
- Chụp ảnh fullpage ở 1440×900 (Desktop) và 390×844 (Mobile) với DPR = 2, mức zoom 100%, sử dụng cùng bộ font hệ thống.
- Đối chiếu độ thoáng thị giác, phân tầng phân đoạn, và đo đạc `scrollWidth` so với `clientWidth`.

### 3.5. Điều kiện dừng thử nghiệm (Stopping Condition)
Nếu cấu trúc cột mới làm suy giảm khả năng đọc trên mobile, gây tràn ngang, hoặc khiến nội dung 3 quyết định bị dính chùm mất ranh giới, lập tức hủy bỏ thử nghiệm và giữ nguyên Baseline (`KEEP_BASELINE`).

---

### 3.6. Chi tiết tối đa hai thay đổi thực tế (Max 2 Changes)

#### Thay đổi 1 (Bố cục Section 03 Desktop — Kiến trúc 3 cột mở):
- **Trước (Baseline)**: `.decisions-grid` chứa 3 phần tử `.decision-card` riêng biệt, mỗi thẻ có nền trắng riêng, viền riêng (`1px solid var(--color-border)`), bo góc (`border-radius: 4px`) và bóng đổ riêng (`box-shadow`).
- **Sau (Candidate)**: Hợp nhất toàn bộ Section 03 thành một khung kiến trúc 3 cột mở đồng nhất. Xóa bỏ viền và bóng đổ riêng của từng card. Sử dụng đường phân cách hairline dọc siêu mảnh (`border-right: 1px solid var(--color-border)`) cho 2 cột đầu, cột cuối cùng không viền.
- **Kết quả người dùng nhìn thấy**: Khối nội dung 3 quyết định trở nên thoáng đãng, hòa nhập tự nhiên vào trang, không còn cảm giác bị giam hãm trong 3 "chiếc hộp" đóng kín.

#### Thay đổi 2 (Nhãn định danh kỹ thuật & Thích ứng Mobile):
- **Trước (Baseline)**: Nhãn thứ tự là chữ đơn giản `01.`, `02.`, `03.` đặt trần trên tiêu đề. Trên mobile các thẻ card vẫn giữ dạng hộp riêng biệt.
- **Sau (Candidate)**: Định hình số thứ tự thành dạng thẻ nhãn kỹ thuật monospace gọn gàng (`.decision-num`: `font-family: var(--font-mono)`, nền nhẹ `var(--color-surface-subtle)`, viền mảnh `1px solid var(--color-border)`). Trên màn hình Mobile (≤860px), các cột tự động chuyển thành các phân đoạn dọc ngăn cách bởi đường hairline ngang (`border-bottom: 1px solid var(--color-border)`), loại bỏ hoàn toàn viền hộp thừa.
- **Kết quả người dùng nhìn thấy**: Trên desktop, nhãn tạo điểm neo thị giác kỹ thuật rõ ràng; trên mobile, danh sách chuyển thành dòng chảy phân đoạn thanh lịch, dễ đọc khi cuộn ngón tay.

---

## 4. Ma trận so sánh công bằng trước / sau (Q04)

Đối chiếu trực tiếp giữa `baseline/` và `candidate/` trong cùng điều kiện hiển thị nghiêm ngặt:

| STT | Câu hỏi thẩm định | Quan sát Baseline | Quan sát Candidate | Kết luận & Bằng chứng kiểm chứng |
| :--- | :--- | :--- | :--- | :--- |
| **1** | **Nhiệm vụ mục tiêu được hỗ trợ thế nào?** | Người dùng đọc được 3 quyết định nhưng cảm giác bị nặng nề bởi các đường viền hộp lặp lại liên tiếp sau Section 02. | Nhịp thở mở rộng rãi; mắt người dùng lướt qua 3 nguyên tắc một cách tự nhiên và liền mạch như một bảng tra cứu kiến trúc chuyên nghiệp. | **TỐT HƠN** *(Minh chứng: `screenshots/candidate_desktop_fullpage.png`)*. |
| **2** | **Điểm mạnh đã xác định (C01, C05) có được giữ?** | C01 (bảng 2 dòng mobile) và C05 (zero motion) hoạt động hoàn hảo. | C01 và C05 được bảo toàn nguyên vẹn 100%, không bị tác động hay suy giảm. | **CÓ — BẢO TOÀN TRỌN VẸN** *(Minh chứng: `VERIFICATION.json`)*. |
| **3** | **Desktop và Mobile cùng được xét chưa?** | Desktop có 3 hộp; mobile có 3 hộp xếp dọc chiếm nhiều diện tích cuộn. | Desktop hiển thị 3 cột mở hairline dọc; mobile hiển thị 3 phân đoạn hairline ngang tối giản, gọn gàng. | **ĐÃ XÉT ĐỒNG BỘ** *(Minh chứng: 4 ảnh fullpage chụp tại 1440×900 và 390×844)*. |
| **4** | **Cái giá mới phát sinh (New Tradeoff) là gì?** | Các thẻ hộp độc lập cho phép người xem nhận biết ranh giới cực kỳ rõ ràng dù nhìn lướt qua từ xa. | Khi chuyển sang hairline divider, ranh giới giữa 3 cột nhẹ nhàng hơn, đòi hỏi khoảng đệm (padding) phải chuẩn xác để tránh cảm giác chữ bị dính gần nhau. | **ĐÁNH ĐỔI ĐÃ KIỂM SOÁT** *(Khoảng đệm `var(--space-md)` đảm bảo khoảng cách an toàn 32px giữa các cột)*. |

---

## 5. Quyết định cuối cùng & Đánh đổi kiến trúc (Q06)

### Phán quyết: `ADOPT` (Áp dụng Candidate cho bản thử nghiệm Module 06)

### Lập luận đánh giá có căn cứ:
1. **Lợi ích thị giác vượt trội**: Cấu trúc 3 cột kiến trúc mở giải quyết triệt để sự mỏi mắt do bão hòa hình khối hộp (`boxiness fatigue`), mang lại nhịp thở trang nhã và phân tầng kiến trúc đồng bộ với bản sắc "Hệ thống công cụ kỹ thuật TRACE".
2. **Không có bất kỳ sự đánh đổi tiêu cực nào về khả năng đọc hay chức năng**:
   - 100% nội dung văn bản được giữ nguyên.
   - Bảng số liệu và CTA hoạt động ổn định.
   - Trải nghiệm trên thiết bị di động trở nên mượt mà và gọn gàng hơn nhờ việc loại bỏ các đường viền kép của card.
3. **Cái giá phát sinh đã được hấp thụ an toàn**: Sự phụ thuộc vào hairline dọc được cân bằng hoàn hảo bằng thẻ nhãn neo monospace (`.decision-num`), giúp phân biệt rõ ràng 3 phân đoạn mà không cần đến viền hộp đóng kín.

---

## 6. Kiểm chứng vừa đủ — Bảng kiểm soát Q01–Q07 (Q05)

| Ca kiểm tra | Nội dung kiểm tra | Phương thức kiểm tra | Kết quả đo đạc thực tế | Trạng thái |
| :--- | :--- | :--- | :--- | :--- |
| **Q01** | Baseline đúng nguồn gốc và không bị sửa đổi | Đo băm SHA-256 đối chiếu với Module 05 Rev 002 | `12302f8c948dd48126cb756f20c4e64639642eba8394a0501006c6034c850bf1` (Khớp 100%) | **PASS** |
| **Q02** | Nhận xét phân loại đúng, có vị trí và bằng chứng | Đối chiếu schema 5 quan sát C01–C05 | Đầy đủ `strength`, `tradeoff`, `preference`; có vị trí code và ảnh minh chứng | **SELF_REVIEW_PENDING_CONTROLLER** |
| **Q03** | Một giả thuyết, tối đa 2 thay đổi | Đối chiếu diff giữa baseline và candidate | Duy nhất Section 03: (1) 3 cột mở hairline desktop, (2) tag monospace & hairline ngang mobile | **PASS** |
| **Q04** | So sánh trước / sau công bằng | Chụp ảnh tự động qua Chrome CDP | Cùng DPR=2, 1440×900 và 390×844, cùng font, cùng nội dung | **PASS** |
| **Q05** | Không làm hỏng điều đã đạt (No Regressions) | Đếm phần tử DOM, đo kích thước scroll | H1 đầy đủ, 3 hàng bảng đủ, 2 CTA đủ, scrollWidth = clientWidth (không tràn ngang), zeroMotion = true | **PASS** |
| **Q06** | Quyết định có căn cứ và có xét cái giá | Phân tích được/mất và cái giá phát sinh | Quyết định ADOPT với lập luận giảm boxiness và hấp thụ đánh đổi khoảng đệm | **SELF_REVIEW_PENDING_CONTROLLER** |
| **Q07** | Bài học có phạm vi và ngoại lệ | Đúc kết 3 bài học có điều kiện ứng dụng | 3 bài học kèm đầy đủ Observation, Rule candidate, Applies when, Exception, Evidence | **SELF_REVIEW_PENDING_CONTROLLER** |

### Số liệu kỹ thuật chi tiết từ `VERIFICATION.json`:
- **Desktop (1440×900)**: `clientWidth: 1425px`, `scrollWidth: 1425px` $\to$ `hasHorizontalOverflow: false`.
- **Mobile (390×844)**: `clientWidth: 375px`, `scrollWidth: 375px` $\to$ `hasHorizontalOverflow: false`.
- **Dữ liệu chuẩn**: `hasAllRows: true` (Yêu cầu sản phẩm / Bản mẫu đăng nhập / Biên bản bàn giao).
- **CTA & Bản mẫu tĩnh**: `hasCtas: true`, `hasStaticLabel: true`.
- **Hiệu năng chuyển động**: `zeroMotion: true` (`transition: none`, `animation: none`).

---

## 7. Ba bài học có giới hạn phạm vi (Bounded Learnings) (Q07)

### Bài học 1: Nhịp thở khối & Chống bão hòa hình khối hộp (Anti-Boxiness Cadence)
- **Observation (Điều quan sát thấy)**: Khi một trang web liên tục bao bọc mọi nhóm nội dung trong các thẻ card viền nổi bo góc (Hero Specimen Card, Data Matrix Card, 3 Decision Cards), giao diện sinh ra hiện tượng "bão hòa khối hộp", khiến thị giác người dùng bị chia cắt vụn vặt và nặng nề.
- **Rule candidate (Nguyên tắc ứng viên)**: Trong một trang tài liệu hoặc công cụ kỹ thuật có từ hai khối card lớn trở lên, nên luân phiên giữa khối hộp khép kín (dành cho bảng số liệu / mẫu vật tương tác) và cấu trúc kiến trúc mở phân cách bằng hairline dọc (dành cho các khối giải thích / nguyên tắc).
- **Applies when (Áp dụng khi)**: Thiết kế trang thông tin kỹ thuật, dashboard phân tích hoặc landing page công cụ hạ tầng có nhiều khối nội dung xếp kế tiếp nhau.
- **Exception (Ngoại lệ)**: Khi các thành phần con cần hỗ trợ các thao tác tương tác độc lập (ví dụ: kéo thả từng card, chọn checkbox từng card để xử lý hàng loạt, hoặc click mở modal riêng biệt), bắt buộc phải giữ ranh giới khối hộp khép kín độc lập.
- **Evidence (Bằng chứng)**: Đối chiếu Section 03 giữa `screenshots/baseline_desktop_fullpage.png` và `screenshots/candidate_desktop_fullpage.png`.
- **Status**: `EXERCISE_SUPPORTED`

---

### Bài học 2: Phân chia 2 dòng thích ứng cho bảng dữ liệu di động (2-Line Mobile Row Partitioning)
- **Observation (Điều quan sát thấy)**: Nỗ lực ép một bảng dữ liệu 3 cột của desktop hiển thị trên màn hình hẹp (390px) thường dẫn đến hai kết cục xấu: hoặc chữ bị co cụm vỡ vụn, hoặc xuất hiện thanh cuộn ngang gây ức chế ngón tay người dùng.
- **Rule candidate (Nguyên tắc ứng viên)**: Đối với bảng dữ liệu gọn (3–4 trường thông tin) trên màn hình di động (<600px), ưu tiên cấu trúc linh hoạt 2 dòng: Dòng 1 dành trọn vẹn bề ngang cho Tiêu đề thực thể; Dòng 2 phân bổ người phụ trách bên trái và huy hiệu trạng thái bên phải.
- **Applies when (Áp dụng khi)**: Màn hình điện thoại di động hiển thị danh sách thực thể có tên dài cần đọc trọn vẹn kèm trạng thái xử lý.
- **Exception (Ngoại lệ)**: Khi bảng có từ 5 cột số liệu toán học/tài chính trở lên bắt buộc phải so sánh dóng hàng theo chiều dọc giữa các dòng (như bảng cân đối kế toán), lúc này giải pháp cuộn ngang kèm cố định cột đầu tiên (sticky column) lại là bắt buộc.
- **Evidence (Bằng chứng)**: Nhận xét C01 và kết quả đo đạc `hasHorizontalOverflow: false` trên Mobile tại `screenshots/candidate_mobile_fullpage.png`.
- **Status**: `EXERCISE_SUPPORTED`

---

### Bài học 3: Kỷ luật phân loại phản biện thiết kế (Critique Taxonomy Discipline)
- **Observation (Điều quan sát thấy)**: Đa phần các tranh cãi trong thiết kế giao diện trở nên bế tắc khi người đánh giá đánh đồng "sở thích cá nhân" (như màu xám lạnh hay màu kem ấm) hoặc "sự đánh đổi có chủ đích" (như lặp mẫu vật ở Hero để chứng minh công năng) thành "lỗi chức năng".
- **Rule candidate (Nguyên tắc ứng viên)**: Mọi nhận xét phản biện giao diện bắt buộc phải bắt đầu bằng việc phân định rạch ròi 1 trong 4 loại (`defect`, `tradeoff`, `preference`, `strength`) dựa trên bằng chứng kiểm chứng cụ thể (visual/runtime/code) và nhiệm vụ người dùng (user task) trước khi đề xuất bất kỳ hành động sửa đổi nào.
- **Applies when (Áp dụng khi)**: Toàn bộ các phiên duyệt thiết kế (design review), phản biện kiến trúc (critique) và kiểm toán chất lượng giao diện người dùng.
- **Exception (Ngoại lệ)**: Trong các buổi thảo luận định hướng ý tưởng sơ khai (early brainstorming / moodboarding), việc phân loại khắt khe có thể được nới lỏng để khuyến khích sự bộc lộ cảm xúc và ý tưởng tự do.
- **Evidence (Bằng chứng)**: Cấu trúc 5 quan sát C01–C05 tại Bảng nhận xét phân loại trong báo cáo này.
- **Status**: `EXERCISE_SUPPORTED`

---

## 8. Giới hạn nghiên cứu & Đánh đổi còn tồn tại (Limitations)

1. **Giới hạn môi trường thực nghiệm**: Thử nghiệm được kiểm chứng kỹ thuật qua Chrome DevTools Protocol (Puppeteer headless với DPR=2 trên hai kích thước viewport cố định 1440×900 và 390×844). Chưa bao gồm dữ liệu theo dõi ánh mắt (eye-tracking) hoặc phỏng vấn người dùng thực tế về thời gian đọc hiểu Section 03.
2. **Đánh đổi về sự nổi bật độc lập**: Cấu trúc 3 cột mở bằng hairline làm giảm độ độc lập thị giác của từng quyết định riêng lẻ nếu nhìn lướt nhanh từ khoảng cách xa so với 3 chiếc hộp đóng kín của Baseline. Tuy nhiên, trong bối cảnh người dùng đọc tài liệu kỹ thuật, đánh đổi này là hoàn toàn chấp nhận được và mang lại giá trị nhịp thở cao hơn.
