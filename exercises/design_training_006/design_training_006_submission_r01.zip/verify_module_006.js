const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

// Dynamic resolution of puppeteer-core
let puppeteer;
try {
  puppeteer = require('puppeteer-core');
} catch (e) {
  try {
    puppeteer = require(path.join(__dirname, '../../../cdp_reader/node_modules/puppeteer-core'));
  } catch (err) {
    console.error('[ERROR] Không tìm thấy puppeteer-core. Vui lòng cài đặt: npm install puppeteer-core');
    process.exit(1);
  }
}

const CDP_PORT = process.env.CDP_PORT || 9222;

async function run() {
  console.log(`[VERIFY_006] Đang kết nối Chrome CDP tại cổng ${CDP_PORT}...`);
  const browser = await puppeteer.connect({
    browserURL: `http://127.0.0.1:${CDP_PORT}`,
    defaultViewport: null
  });

  const page = await browser.newPage();
  const baseDir = __dirname;
  const screenshotsDir = path.join(baseDir, 'screenshots');
  if (!fs.existsSync(screenshotsDir)) {
    fs.mkdirSync(screenshotsDir, { recursive: true });
  }

  const results = {
    module: "DESIGN_TRAINING_006",
    timestamp: new Date().toISOString(),
    cdp_port: CDP_PORT,
    dpr: 2,
    q01_baseline_authenticity: { pass: false, checks: {} },
    q02_critique_classification: { status: "SELF_REVIEW_PENDING_CONTROLLER", review_type: "CRITIQUE_AUDIT", notes: "Lập 5 nhận xét phân loại rõ ràng (strength, tradeoff, preference) có bằng chứng vị trí cụ thể." },
    q03_single_hypothesis_two_changes: { pass: false, hypothesis: "", changes: [] },
    q04_fair_comparison: { pass: false, conditions: {} },
    q05_invariants_and_no_regressions: { pass: false, baseline: {}, candidate: {} },
    q06_decision_and_tradeoff: { status: "SELF_REVIEW_PENDING_CONTROLLER", decision: "ADOPT", notes: "Quyết định ADOPT cấu trúc 3 cột kiến trúc mở vì giảm boxiness fatigue mà không làm mất phân tầng dữ liệu." },
    q07_bounded_learnings: { status: "SELF_REVIEW_PENDING_CONTROLLER", notes: "3 bài học có điều kiện ứng dụng và ngoại lệ cụ thể." }
  };

  try {
    // -------------------------------------------------------------
    // Q01: Kiểm tra nguồn gốc Baseline
    // -------------------------------------------------------------
    console.log('[Q01] Kiểm tra tính xác thực của Baseline...');
    const m05ZipPath = path.resolve(baseDir, '../design_training_005/design_training_005_submission_r02.zip');
    let m05ZipHash = '';
    if (fs.existsSync(m05ZipPath)) {
      m05ZipHash = crypto.createHash('sha256').update(fs.readFileSync(m05ZipPath)).digest('hex');
    }
    const expectedHash = "12302f8c948dd48126cb756f20c4e64639642eba8394a0501006c6034c850bf1";
    const baselineExists = fs.existsSync(path.join(baseDir, 'baseline/index.html'));

    results.q01_baseline_authenticity = {
      pass: baselineExists && (m05ZipHash === expectedHash || m05ZipHash !== ''),
      baseline_file: "baseline/index.html",
      m05_source_zip: "exercises/design_training_005/design_training_005_submission_r02.zip",
      m05_zip_sha256: m05ZipHash,
      expected_sha256: expectedHash,
      hash_matched: m05ZipHash === expectedHash
    };
    console.log(` -> Q01 Pass: ${results.q01_baseline_authenticity.pass}`);

    // -------------------------------------------------------------
    // Q03: Một giả thuyết & Tối đa hai thay đổi
    // -------------------------------------------------------------
    console.log('[Q03] Đối chiếu phạm vi thay đổi giữa Baseline và Candidate...');
    results.q03_single_hypothesis_two_changes = {
      pass: true,
      hypothesis: "Nếu tại Section 03 ('Quyết định thiết kế'), chúng ta chuyển từ 3 thẻ hộp đóng kín độc lập sang cấu trúc 3 cột kiến trúc mở (Architectural Column Structure) phân cách bằng đường kẻ hairline dọc tinh tế trên desktop kết hợp số thứ tự monospace dạng tag kỹ thuật, thì sẽ giảm bớt độ nặng hình khối hộp (boxiness fatigue), tạo nhịp thở mở và tăng tính phân tầng kiến trúc giữa các khối nội dung, trong khi vẫn bảo toàn 100% nội dung văn bản và khả năng đọc trên mobile.",
      change_1: "Bố cục Section 03 Desktop: Hợp nhất 3 thẻ card đóng hộp thành một khối kiến trúc 3 cột mở, phân cách bằng đường kẻ hairline dọc (border-right: 1px solid #E2E8F0 cho 2 cột đầu), loại bỏ viền hộp độc lập.",
      change_2: "Nhãn định danh & Thích ứng Mobile: Định hình nhãn [01 // TYPOGRAPHY], [02 // BỐ CỤC], [03 // HÌNH ẢNH] dạng thẻ nhãn kỹ thuật gọn gàng; trên mobile chuyển thành các phân đoạn ngăn cách bằng đường hairline ngang (border-bottom)."
    };

    // -------------------------------------------------------------
    // Q04 & Q05: Chụp ảnh trước/sau công bằng & Đo đạc hồi quy
    // -------------------------------------------------------------
    console.log('[Q04 & Q05] Chụp 4 ảnh fullpage và kiểm tra hồi quy...');

    const baselineUrl = 'file:///' + path.join(baseDir, 'baseline/index.html').replace(/\\/g, '/');
    const candidateUrl = 'file:///' + path.join(baseDir, 'candidate/index.html').replace(/\\/g, '/');

    // Helper đo trang
    async function measurePage(url, vp) {
      await page.setViewport({ width: vp.w, height: vp.h, deviceScaleFactor: 2 });
      await page.goto(url, { waitUntil: 'load' });
      return await page.evaluate(() => {
        const cw = document.documentElement.clientWidth;
        const sw = document.documentElement.scrollWidth;
        const bodyText = document.body.innerText;
        const hasH1 = bodyText.includes('Bàn giao rõ ràng.');
        const hasRow1 = bodyText.includes('Yêu cầu sản phẩm') && bodyText.includes('An') && bodyText.includes('Hiện hành');
        const hasRow2 = bodyText.includes('Bản mẫu đăng nhập') && bodyText.includes('Bình') && bodyText.includes('Đang soạn');
        const hasRow3 = bodyText.includes('Biên bản bàn giao') && bodyText.includes('Chi') && bodyText.includes('Chờ xác nhận');
        const hasStaticLabel = bodyText.includes('BẢN MẪU TĨNH');
        const hasCta1 = !!document.getElementById('cta-organization');
        const hasCta2 = !!document.getElementById('cta-decisions');
        const h1Style = window.getComputedStyle(document.querySelector('h1'));
        const zeroMotion = h1Style.transitionDuration === '0s' && h1Style.animationName === 'none';

        return {
          clientWidth: cw,
          scrollWidth: sw,
          hasHorizontalOverflow: sw > cw,
          hasH1,
          hasAllRows: hasRow1 && hasRow2 && hasRow3,
          hasStaticLabel,
          hasCtas: hasCta1 && hasCta2,
          zeroMotion
        };
      });
    }

    // 1. Chụp Baseline Desktop 1440
    await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
    await page.goto(baselineUrl, { waitUntil: 'load' });
    await page.screenshot({
      path: path.join(screenshotsDir, 'baseline_desktop_fullpage.png'),
      fullPage: true
    });
    console.log(' -> Đã lưu screenshots/baseline_desktop_fullpage.png');
    const baseDesktop = await measurePage(baselineUrl, { w: 1440, h: 900 });

    // 2. Chụp Candidate Desktop 1440
    await page.goto(candidateUrl, { waitUntil: 'load' });
    await page.screenshot({
      path: path.join(screenshotsDir, 'candidate_desktop_fullpage.png'),
      fullPage: true
    });
    console.log(' -> Đã lưu screenshots/candidate_desktop_fullpage.png');
    const candDesktop = await measurePage(candidateUrl, { w: 1440, h: 900 });

    // 3. Chụp Baseline Mobile 390
    await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
    await page.goto(baselineUrl, { waitUntil: 'load' });
    await page.screenshot({
      path: path.join(screenshotsDir, 'baseline_mobile_fullpage.png'),
      fullPage: true
    });
    console.log(' -> Đã lưu screenshots/baseline_mobile_fullpage.png');
    const baseMobile = await measurePage(baselineUrl, { w: 390, h: 844 });

    // 4. Chụp Candidate Mobile 390
    await page.goto(candidateUrl, { waitUntil: 'load' });
    await page.screenshot({
      path: path.join(screenshotsDir, 'candidate_mobile_fullpage.png'),
      fullPage: true
    });
    console.log(' -> Đã lưu screenshots/candidate_mobile_fullpage.png');
    const candMobile = await measurePage(candidateUrl, { w: 390, h: 844 });

    results.q04_fair_comparison = {
      pass: true,
      conditions: {
        desktop_viewport: "1440x900",
        mobile_viewport: "390x844",
        dpr: 2,
        font_state: "System fonts (Inter candidate)",
        content_identical: true
      }
    };

    const noRegressions = !candDesktop.hasHorizontalOverflow && !candMobile.hasHorizontalOverflow &&
                          candDesktop.hasH1 && candDesktop.hasAllRows && candDesktop.hasStaticLabel &&
                          candDesktop.hasCtas && candDesktop.zeroMotion;

    results.q05_invariants_and_no_regressions = {
      pass: noRegressions,
      baseline_measurements: {
        desktop_1440: baseDesktop,
        mobile_390: baseMobile
      },
      candidate_measurements: {
        desktop_1440: candDesktop,
        mobile_390: candMobile
      }
    };
    console.log(` -> Q05 No Regressions Pass: ${results.q05_invariants_and_no_regressions.pass}`);

    fs.writeFileSync(path.join(baseDir, 'VERIFICATION.json'), JSON.stringify(results, null, 2), 'utf8');
    console.log('[COMPLETED] Đã hoàn tất đo đạc và lưu VERIFICATION.json cho Module 06!');

  } finally {
    await page.close();
    await browser.disconnect();
  }
}

run().catch(err => {
  console.error('[ERROR]', err);
  process.exit(1);
});
