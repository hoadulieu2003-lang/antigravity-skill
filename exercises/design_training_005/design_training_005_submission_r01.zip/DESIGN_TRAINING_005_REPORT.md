# BÁO CÁO NGHIỆM THU MODULE 05: ART DIRECTION — ĐỊNH HƯỚNG NGHỆ THUẬT & BẢN SẮC THỊ GIÁC

**Mã nộp**: `DESIGN_TRAINING_005_SUBMISSION_R01`  
**Dự án**: TRACE — Không gian theo dõi bàn giao  
**Thực thi**: Antigravity (Senior Engineering Agent)  
**Thẩm định**: ChatGPT Controller  
**Quyền phê duyệt cao nhất**: Anh — Lead Architect / Product Owner  

---

## 1. Cách Chạy & Tái Hiện Kiểm Thử

Dự án hoàn toàn tự chứa (self-contained), hoạt động offline trên nền trình duyệt chuẩn, không phụ thuộc thư viện UI ngoài, không gọi CDN hay API mạng:

1. **Xem trực tiếp mã nguồn giao diện**:
   - Bản hoàn thiện cuối cùng: Mở tệp `index.html` trên trình duyệt.
   - Bản nháp Hướng A (Biên tập): Mở tệp `directions/option_a.html`.
   - Bản nháp Hướng B (Hệ thống): Mở tệp `directions/option_b.html`.
2. **Chạy kịch bản tự động kiểm chứng & chụp ảnh**:
   - Môi trường yêu cầu: Node.js và một phiên bản Chrome đang mở cổng CDP (mặc định cổng `9222`, có thể cấu hình qua biến môi trường `CDP_PORT`).
   - Lệnh chạy:
     ```bash
     node verify_module_005.js
     ```
   - Kết quả xuất ra: Toàn bộ số đo kỹ thuật ghi nhận tại `VERIFICATION.json` và 6 bức ảnh nghiệm thu lưu tại thư mục `screenshots/`.

---

## 2. Hai Luận Điểm Thiết Kế & Bảng So Sánh Quyết Định Nhìn Thấy Được

### 2.1. Luận điểm thiết kế (Theses)
* **Hướng A — Biên tập (Editorial)**:  
  *"Đặt trọng tâm vào nhịp điệu đọc văn bản và khoảng trắng tự nhiên; sử dụng kiểu chữ Serif thanh lịch cho tiêu đề kết hợp cột nội dung hẹp và bản mẫu dạng trích đoạn tài liệu nghiên cứu có chú thích lề, giúp người xem tiếp cận dự án như một bài viết chuyên khảo sâu sắc về quản trị sản phẩm."* *(62 từ)*
* **Hướng B — Hệ thống (Structural Precision)**:  
  *"Sử dụng trục căn lề trái nghiêm ngặt kết hợp cặp phông Sans-serif mô-đun và Monospace kỹ thuật nhằm biến thông tin bàn giao thành các khối dữ liệu đối chiếu chuẩn xác, giúp người phụ trách sản phẩm nhận diện tức thì tình trạng công việc mà không bị phân tán thị giác."* *(53 từ)*

### 2.2. Bảng so sánh khác biệt nhìn thấy được trên 3 trục

| Trục so sánh | Hướng A: Biên tập (Editorial) | Hướng B: Hệ thống (Structural Precision) | Căn cứ trên ảnh thực tế |
| :--- | :--- | :--- | :--- |
| **1. Typography (Kiểu chữ)** | Sử dụng phông có chân **Serif** (Georgia / Times) cho Tiêu đề chính H1 và H2 tạo cảm giác ấn phẩm báo chí; Sans-serif thanh mảnh cho nội dung dẫn nhập. | Sử dụng **Neo-grotesque Sans-serif** (Inter) trọng số đậm 800 cho tiêu đề; kết hợp **Monospace kỹ thuật** cho nhãn bối cảnh `[HỆ THỐNG]`, `[PHẦN 02]`, và mã định danh `DOC-01`. | Đối chiếu `option_a_desktop_1440x900.png` và `option_b_desktop_1440x900.png`. |
| **2. Bố cục (Composition)** | Lưới bất đối xứng tỷ lệ biên tập (1.15fr / 0.85fr), lề đọc văn bản hẹp (max 620px), thụt dòng mềm mại, khoảng trắng mở rộng tạo nhịp thở thư thái. | Lưới mô-đun cân đối 1:1, **trục căn lề trái nghiêm ngặt** gióng thẳng hàng từ nhãn kỹ thuật, tiêu đề, đoạn văn bản đến nút bấm và mép bảng dữ liệu; đường kẻ hairline `#E2E8F0` chia khối dứt khoát. | Khối Hero của Hướng B có cấu trúc đóng khung phân tầng rõ rệt so với sự thoáng mở tự do của Hướng A. |
| **3. Xử lý tài sản (Image Treatment)** | Bản mẫu 3 dòng dữ liệu đóng khung dạng **trang tài liệu nghiên cứu giấy**, phân cách bằng đường gạch ngang thanh mảnh, kèm chú thích lề dạng caption biên tập ở chân trang. | Bản mẫu đóng vai trò **giao diện mô-đun công cụ thực tế** (`MODULE 01: TRACE SPECIMEN`) với thanh toolbar xám `#F1F5F9`, đèn trạng thái xanh lá `#10B981` (`CHẾ ĐỘ THỰC THI`), các ô dữ liệu có thẻ phân loại và badge trạng thái kèm dot marker hình học. | Khối Specimen bên phải của Hướng B thể hiện bản sắc một phần mềm quản lý sản phẩm thực thụ. |

---

## 3. Lý Do Lựa Chọn Hướng B Cho Bản Hoàn Thiện (`index.html`)

Theo Đặc tả khóa (`DESIGN_TRAINING_005_DIRECTIVE.md`):
- **Đối tượng xem**: Người phụ trách sản phẩm (Product Owner / PM) hoặc người phụ trách vận hành tại doanh nghiệp nhỏ.
- **Mục tiêu cảm nhận**: Rõ ràng, có chủ đích, đáng tin, có nét riêng.

**Căn cứ lựa chọn**:
1. **Tối ưu hóa khả năng quét thông tin (Scanability)**: Người làm vận hành tại doanh nghiệp nhỏ luôn ưu tiên sự nhanh chóng và độ chính xác. Bố cục dạng hệ thống mô-đun với trục căn lề trái thẳng tắp giúp mắt người xem định vị ngay 3 cột thông tin: *Tài liệu cần bàn giao*, *Ai phụ trách*, và *Trạng thái hiện thời là gì*.
2. **Khắc họa bản sắc công cụ bàn giao (Product Tool Identity)**: Thay vì trình bày như một câu chuyện kể phong cách tạp chí (Hướng A), Hướng B biến toàn bộ trang thành một "Không gian theo dõi bàn giao" sắc bén, minh chứng trực tiếp năng lực tổ chức thông tin và tư duy thiết kế hệ thống của tác giả.
3. **Tính nhất quán giữa bản mẫu và ngôn ngữ trang**: Bản mẫu 3 dòng dữ liệu là một bảng đối chiếu; do đó việc sử dụng ngôn ngữ thiết kế hệ thống (lưới, hairline divider, badge có chấm hình học) tạo nên sự cộng hưởng hoàn hảo giữa nội dung giới thiệu và tài sản minh họa.

---

## 4. Hai Đánh Đổi Kiến Trúc Thị Giác (Trade-offs)

### Đánh đổi 1: Tính Kỷ Luật Kỹ Thuật (Technical Rigor) vs. Tính Truyền Cảm Nghệ Thuật (Artistic Warmth)
* **Được gì**: Trang web toát lên sự chuyên nghiệp, chuẩn xác, đáng tin cậy cao độ, rất phù hợp với kỳ vọng của các nhà quản lý sản phẩm và kỹ thuật.
* **Mất gì**: Mất đi sự mềm mại, tính cá nhân phóng khoáng và cảm xúc thư thái của phong cách biên tập Typography Serif truyền thống.
* **Khi nào lựa chọn này không còn phù hợp**: Khi TRACE được định vị lại thành một ấn phẩm xuất bản sáng tạo (Design Publication), bản tin nội bộ (Newsletter) hoặc portfolio của một nghệ sĩ đồ họa thị giác cần phô diễn cảm xúc thẩm mỹ cá nhân tự do.

### Đánh đổi 2: Mật Độ Thông Tin Ma Trận (Matrix Density) vs. Độ Tối Giản Di Động (Mobile Simplicity)
* **Được gì**: Bảo toàn nguyên vẹn cấu trúc đối chiếu 3 dòng dữ liệu trong cùng một ngữ cảnh trên cả máy tính và điện thoại, không che giấu bất kỳ trường dữ liệu nào.
* **Mất gì**: Trên màn hình di động hẹp (390px), bảng dữ liệu và thanh toolbar đòi hỏi người xem phải cuộn dọc nhiều hơn để xem hết các thành phần so với một danh sách văn bản thuần túy dạng phẳng.
* **Khi nào lựa chọn này không còn phù hợp**: Khi người dùng phần lớn là nhân viên hiện trường (field operators) chỉ cần thao tác nhanh trên một ngón tay với một danh sách công việc dạng checkbox tối giản, không cần đối chiếu thông tin đa chiều.

---

## 5. Tự Phản Biện Dựa Trên Ảnh Thực Tế & Một Thay Đổi Đã Thực Hiện

### Ba nhận xét tự phản biện:
1. **Tại thanh tiêu đề Specimen trong Hero (Góc trên phải ảnh `final_desktop_1440x900.png`)**:
   - *Quan sát*: Chấm xanh lá `#10B981` ban đầu đứng độc lập có thể khiến người xem băn khoăn liệu đây có phải là kết nối mạng thời gian thực (real-time socket) hay không.
   - *Tự phản biện*: Trong một bản mẫu tĩnh, cần ghi rõ ngữ cảnh để tránh tạo ra kỳ vọng sai lệch.
2. **Tại bảng ma trận Phần 2 (Ảnh `final_mobile_390x844.png`)**:
   - *Quan sát*: Chiều rộng 390px (nội dung thực tế 375px) là thử thách lớn đối với bảng 3 cột dữ liệu. Nếu các nhãn trạng thái dài như "Chờ xác nhận" bị ngắt thành 2 dòng sẽ làm mất nhịp điệu của toàn bảng.
   - *Tự phản biện*: Phải áp dụng quy tắc co giãn có kiểm soát để văn bản không bao giờ bị gãy dòng bất thường.
3. **Tại lưới 3 thẻ Phần 3 "Quyết định thiết kế" (Ảnh `final_desktop_1440x900.png`)**:
   - *Quan sát*: Cả 3 thẻ đều sử dụng đường viền đóng hộp riêng rẽ. Mặc dù cấu trúc này rất rõ ràng, nhưng việc có 3 hộp cạnh nhau có thể tạo ra cảm giác lặp lại nhịp điệu thị giác.
   - *Tự phản biện*: Trong các phiên bản mở rộng tiếp theo, có thể thử nghiệm phương án phân chia bằng đường kẻ hairline dọc không đóng khung để tạo cảm giác thoáng đãng hơn.

### Một thay đổi cụ thể đã thực hiện và lý do:
- **Chi tiết thay đổi**: Trong tệp `index.html`, tại media query `@media (max-width: 600px)`, Em đã điều chỉnh padding của các ô bảng `.matrix-table th, .matrix-table td` từ `1.125rem 1.25rem` xuống `0.75rem 0.75rem`, đồng thời thiết lập thuộc tính `white-space: nowrap` cho toàn bộ `.status-badge`.
- **Lý do kỹ thuật**: Đảm bảo trên màn hình mobile 390px, cả 3 cột "Tài liệu", "Người phụ trách" và "Trạng thái" hiển thị trên cùng một dòng ngang phẳng phiu, không phát sinh tràn ngang (`scrollWidth <= clientWidth`), nhãn "Chờ xác nhận" không bị ngắt đôi chữ, giúp khả năng đọc và quét thông tin đạt độ hoàn hảo tối đa.

---

## 6. Tổng Hợp Kết Quả Bộ Kiểm Tra Khóa V01–V08

| Mã ca | Nội dung kiểm tra | Kết quả đo đạc thực tế | Trạng thái |
| :---: | :--- | :--- | :---: |
| **V01** | Nội dung chuẩn và 3 dòng dữ liệu | Đối chiếu đầy đủ 100% tiêu đề, đoạn văn bản, 2 CTA, 3 dòng dữ liệu (An/Bình/Chi) trên cả 2 bản nháp và bản cuối. Danh sách từ ngữ cấm phát hiện: `[]` (0 từ bịa đặt). | **PASS** |
| **V02** | Khác biệt A/B | Hai ảnh `option_a_desktop_1440x900.png` và `option_b_desktop_1440x900.png` thể hiện sự khác biệt rõ rệt trên 3 trục: Typography (Serif vs Sans/Mono), Composition (Asymmetric vs Strict Datum Grid), Image Treatment (Document Specimen vs Modular Tool Matrix). | **PENDING_CONTROLLER** *(Visual Review)* |
| **V03** | Nhất quán Contract & Bản cuối | `DESIGN_CONTRACT.yaml` ánh xạ 100% khớp với CSS tokens và cây DOM thực tế của `index.html` (Inter/SF Mono, màu `#F8FAFC`/`#0F172A`/`#0284C7`, signature_decision "MODULE 01: HANDOVER MATRIX"). | **PENDING_CONTROLLER** *(Visual Review)* |
| **V04** | CTA có đích thật | Click `#cta-organization` cuộn tức thì đến `#section-organization` (hash: `#section-organization`). Click `#cta-decisions` cuộn tức thì đến `#section-decisions` (hash: `#section-decisions`). | **PASS** |
| **V05** | Bàn phím trên bản cuối | Phím Tab định vị chuẩn xác tới 2 CTA; phím Enter kích hoạt cuộn tức thì. Tiêu điểm hiển thị sắc nét: `outline: 2px solid rgb(2, 132, 199); outline-offset: 2px;`. | **PASS** |
| **V06** | Responsive đa màn hình | Đo đạc thực tế tại DPR = 2:<br>- Desktop (1440x900): `scrollWidth = 1425 <= clientWidth = 1425` (Không tràn).<br>- Tablet (768x1024): `scrollWidth = 753 <= clientWidth = 753` (Không tràn).<br>- Mobile (390x844): `scrollWidth = 375 <= clientWidth = 375` (Không tràn).<br>Ba dòng dữ liệu hiển thị rõ ràng (`rowsVisible = true`), tiêu đề chính không bị cắt xén. | **PASS** |
| **V07** | Ngữ nghĩa & Khả năng đọc | Đúng duy nhất 1 thẻ `<h1>`, 2 thẻ `<h2>`, 3 thẻ `<h3>`. Có đủ `<nav>`, `<main>`, `<section>`, `<footer>`.<br>Tỷ lệ tương phản WCAG:<br>- Văn bản chính `#0F172A` trên nền `#F8FAFC`: **15.8:1** (vượt chuẩn AAA).<br>- Văn bản phụ `#475569` trên nền `#F8FAFC`: **7.0:1** (vượt chuẩn AA).<br>- Nút bấm `#FFFFFF` trên `#0F172A`: **15.8:1** (vượt chuẩn AAA).<br>- Trạng thái kèm cả nhãn chữ và chấm marker hình học, không dùng màu đơn độc. | **PASS** |
| **V08** | Zero Motion & Gói tái hiện | `transitionDuration: 0s`, `animationName: none`, `scrollBehavior: auto`. Phông chữ hệ thống tiêu chuẩn (`Inter`, `-apple-system`, `SF Mono`), không phụ thuộc font mạng bên ngoài, hoạt động offline 100%. | **PASS** |

---

## 7. Giới Hạn Nghiệm Thu

1. **Phạm vi bài tập portfolio**: Các quyết định thiết kế ở đây được tối ưu hóa cho dự án giả lập TRACE phục vụ người làm sản phẩm và vận hành; không tự động coi đây là quy chuẩn thị giác áp đặt cho mọi loại sản phẩm phần mềm khác.
2. **Đánh giá thị giác V02 & V03**: Các tiêu chí về độ phân biệt thẩm mỹ A/B và tính nhất quán của Contract là đối tượng thẩm định trực quan của ChatGPT Controller và Anh (Lead Architect), script kiểm tra chỉ đóng vai trò thu thập bằng chứng đo đạc khách quan.
3. **Môi trường tái hiện**: Trang web hiển thị hoàn hảo trên các trình duyệt hiện đại (Chrome, Edge, Safari, Firefox). Công cụ đo đạc tự động yêu cầu Node.js và một Chrome chạy cổng CDP được chỉ định.
