/**
 * verify_module_009.js
 * Comprehensive Forensic Verification Harness for Module 09 (Accessibility Task Completion)
 * Stream A: Foundation Integrity · TRIPFLOW Passenger Support Intake Desk
 *
 * Repair Round 1 (Submission R02) Upgraded Harness:
 * - Configurable CDP port via env or CLI
 * - F01 & R01: Precondition test verifying clean initial state (all errors hidden, 0 live text)
 * - F02 & R02/R03: Native keyboard journey (Tab sequence, Enter trigger, Escape dismiss, focus restored, DIALOG TRAP ASSERTED)
 * - F02 & R04: Native duplicate activation guard (pointer click + Enter keypress within saving window)
 * - F02 & R05: Native no-steal focus audit (Tab to #btn-open-guidance during saving; preserved after async complete, 0 body focus)
 * - F03 & R06/R07/R08/R09: 5-viewport reflow matrix (320, 320@200%, 390, 768, 1440), 0 overflow masking, clipping & overlap collision measurement
 * - F04 & R10/R11: Forced-colors in gate conjunction (EXECUTED_PASS required), complete target inventory (button, textarea, radio/checkbox labels), 6-pair contrast inventory fail-closed
 * - F05 & R12/R13/R14: Dynamic audit of 4 byte-identical official Controller documents, AX tree snapshot, report governance, fail-closed exit behavior (exit 1 on any gate failure or uncaught error)
 * - F06 & R15: Bounded assistive tech review plan validation
 * - F08 & R17: Portable replay instructions
 */

const puppeteer = require('puppeteer-core');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Configuration
const CDP_PORT = process.env.CDP_PORT || process.argv[2] || 9223;
const BASE_DIR = __dirname;
const SCREENSHOTS_DIR = path.join(BASE_DIR, 'screenshots');
if (!fs.existsSync(SCREENSHOTS_DIR)) {
  fs.mkdirSync(SCREENSHOTS_DIR, { recursive: true });
}

const CANDIDATE_PATH = path.join(BASE_DIR, 'index.html');
const BASELINE_PATH = path.join(BASE_DIR, 'baseline', 'index.html');
const OPTION_A_PATH = path.join(BASE_DIR, 'directions', 'option_a.html');
const OPTION_B_PATH = path.join(BASE_DIR, 'directions', 'option_b.html');
const CONTRACT_PATH = path.join(BASE_DIR, 'ACCESSIBILITY_CONTRACT.yaml');
const REPORT_PATH = path.join(BASE_DIR, 'DESIGN_TRAINING_009_REPORT.md');
const PLAN_PATH = path.join(BASE_DIR, 'ASSISTIVE_TECH_REVIEW_PLAN.md');

const CANDIDATE_URL = 'file://' + CANDIDATE_PATH.replace(/\\/g, '/');
const BASELINE_URL = 'file://' + BASELINE_PATH.replace(/\\/g, '/');
const OPTION_A_URL = 'file://' + OPTION_A_PATH.replace(/\\/g, '/');
const OPTION_B_URL = 'file://' + OPTION_B_PATH.replace(/\\/g, '/');

// Official Controller Document Hashes (Byte-Identical Invariant)
const OFFICIAL_CONTROLLER_DOCS = {
  'DESIGN_TRAINING_009_DIRECTIVE.md': '0472f2d0df0360eee10f8c1a6c30f862409b89a88cbc206fa5db7b0d3463dee5',
  'DESIGN_TRAINING_009_FIRST_RESPONSE_REVIEW_001.md': 'ac7d03ebabf35e9faab61d5454d6c463629161d29bd14f65971ce78963508046',
  'DESIGN_TRAINING_009_FIRST_RESPONSE_REVIEW_002.md': 'e72022bc363eff194713ff5ba51a2f62d7123f3639fae386e62022212bff8577',
  'DESIGN_TRAINING_009_REVIEW_001.md': '4f5c4640e3eebdb19ac2935e89a1f0315f609c3ea3de4431dc334464d62b190b'
};

// Utilities
function getLuminance(r, g, b) {
  const [rs, gs, bs] = [r, g, b].map(c => {
    c = c / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
}

function getContrastRatio(rgb1, rgb2) {
  if (!rgb1 || !rgb2) return null;
  const lum1 = getLuminance(rgb1[0], rgb1[1], rgb1[2]);
  const lum2 = getLuminance(rgb2[0], rgb2[1], rgb2[2]);
  const brightest = Math.max(lum1, lum2);
  const darkest = Math.min(lum1, lum2);
  return (brightest + 0.05) / (darkest + 0.05);
}

function parseRgbFailClosed(colorStr) {
  if (!colorStr || typeof colorStr !== 'string') return null;
  const m = colorStr.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
  if (!m) return null;
  return [parseInt(m[1], 10), parseInt(m[2], 10), parseInt(m[3], 10)];
}

function computeSha256(filePath) {
  if (!fs.existsSync(filePath)) return null;
  const content = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(content).digest('hex');
}

(async () => {
  console.log('======================================================================');
  console.log(' MODULE 09 FORENSIC ACCESSIBILITY VERIFICATION HARNESS (REPAIR 001)');
  console.log(' STREAM A: FOUNDATION INTEGRITY · TRIPFLOW SUPPORT DESK AR-901');
  console.log(` CONNECTING TO CDP ON PORT: ${CDP_PORT}`);
  console.log('======================================================================\n');

  let browser;
  try {
    browser = await puppeteer.connect({ browserURL: `http://127.0.0.1:${CDP_PORT}`, defaultViewport: null });
  } catch (e) {
    console.error(`[FATAL] Cannot connect to Chrome CDP at port ${CDP_PORT}:`, e.message);
    process.exit(1);
  }

  const page = await browser.newPage();
  const cdpClient = await page.target().createCDPSession();

  // Fail-Closed Results Object (NOT PRE-INITIALIZED TO PASS)
  const results = {
    module_id: 'DESIGN_TRAINING_009_ACCESSIBILITY',
    repair_round: '1/2',
    submission_id: 'DESIGN_TRAINING_009_REPAIR_001',
    execution_timestamp: new Date().toISOString(),
    tests: {},
    gates: {},
    measurements: {},
    screenshots: {},
    file_hashes: {},
    official_documents_audit: {},
    overall_status: 'INITIALIZING'
  };

  try {
    // ------------------------------------------------------------------------
    // PRECONDITION CHECK: Clean Initial State (F01, R01)
    // ------------------------------------------------------------------------
    console.log('[PRECONDITION] Verifying Clean Initial Page State (F01/R01)...');
    await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
    await page.goto(CANDIDATE_URL, { waitUntil: 'load' });

    const precondData = await page.evaluate(() => {
      const errType = document.getElementById('error-support-type');
      const errDetails = document.getElementById('error-details-limit');
      const errConfirm = document.getElementById('error-confirmation');
      const errSummary = document.getElementById('error-summary');
      const liveStatus = document.getElementById('live-status-region');
      const liveAlert = document.getElementById('live-alert-region');
      const fsm = window.__TRIPFLOW_ACCESSIBILITY__;

      const isHidden = (el) => {
        if (!el) return true;
        const style = window.getComputedStyle(el);
        return el.hidden || style.display === 'none' || el.offsetParent === null;
      };

      const invalidControls = Array.from(document.querySelectorAll('[aria-invalid="true"]'));

      return {
        errTypeHidden: isHidden(errType),
        errDetailsHidden: isHidden(errDetails),
        errConfirmHidden: isHidden(errConfirm),
        errSummaryHidden: isHidden(errSummary),
        noInvalidControls: invalidControls.length === 0,
        attemptsCount: fsm ? fsm.getAttempts() : -1,
        commitsCount: fsm ? fsm.getCommits() : -1,
        liveStatusEmpty: liveStatus ? liveStatus.innerText.trim() === '' : false,
        liveAlertEmpty: liveAlert ? liveAlert.innerText.trim() === '' : false
      };
    });

    const precondPass = precondData.errTypeHidden && precondData.errDetailsHidden &&
                        precondData.errConfirmHidden && precondData.errSummaryHidden &&
                        precondData.noInvalidControls && precondData.attemptsCount === 0 &&
                        precondData.commitsCount === 0 && precondData.liveStatusEmpty && precondData.liveAlertEmpty;

    results.measurements.preconditionCleanState = { ...precondData, pass: precondPass };
    console.log(`[PRECONDITION RESULT] Errors Hidden: ${precondData.errTypeHidden && precondData.errDetailsHidden && precondData.errConfirmHidden} | Summary Hidden: ${precondData.errSummaryHidden} | 0 Invalid: ${precondData.noInvalidControls} | Attempts=0: ${precondData.attemptsCount === 0} => ${precondPass ? 'PASS' : 'FAIL'}\n`);
    if (!precondPass) throw new Error('Precondition clean state verification failed: F01 defect active!');

    // ------------------------------------------------------------------------
    // T01: Semantic Structure & Reading Order Scan (Gate A01)
    // ------------------------------------------------------------------------
    console.log('[RUNNING T01] Scanning Semantic Structure & Reading Order...');
    const t01Data = await page.evaluate(() => {
      const landmarks = {
        header: !!document.querySelector('header#site-header[role="banner"], header#site-header'),
        nav: !!document.querySelector('nav#site-nav[role="navigation"], nav#site-nav'),
        main: !!document.querySelector('main#main-content[role="main"], main#main-content'),
        footer: !!document.querySelector('footer#site-footer[role="contentinfo"], footer#site-footer')
      };
      const h1Els = Array.from(document.querySelectorAll('h1'));
      const h1Count = h1Els.length;
      const h1Text = h1Els[0] ? h1Els[0].innerText.trim() : '';

      const headings = Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6')).map(h => ({
        tag: h.tagName,
        level: parseInt(h.tagName.substring(1), 10),
        id: h.id,
        text: h.innerText.trim()
      }));

      let skippedLevels = false;
      for (let i = 0; i < headings.length - 1; i++) {
        if (headings[i+1].level - headings[i].level > 1) {
          skippedLevels = true;
          break;
        }
      }

      const skipLink = document.querySelector('a#skip-link');
      const skipLinkValid = !!skipLink && skipLink.getAttribute('href') === '#main-content';

      return {
        landmarks,
        landmarksComplete: landmarks.header && landmarks.nav && landmarks.main && landmarks.footer,
        h1Count,
        h1Text,
        singleH1: h1Count === 1 && h1Text === 'Ghi nhận yêu cầu hỗ trợ',
        headings,
        noSkippedLevels: !skippedLevels,
        skipLinkValid
      };
    });

    // Test skip link focus visibility via Tab
    await page.keyboard.press('Tab');
    const skipLinkFocused = await page.evaluate(() => {
      const active = document.activeElement;
      if (!active || active.id !== 'skip-link') return false;
      const rect = active.getBoundingClientRect();
      return rect.top >= 0 && rect.left >= 0 && rect.width > 50 && rect.height > 20;
    });

    const t01Pass = t01Data.landmarksComplete && t01Data.singleH1 && t01Data.noSkippedLevels && t01Data.skipLinkValid && skipLinkFocused;
    results.tests.T01 = {
      name: 'Semantic Structure & Reading Order Scan',
      gate: 'A01',
      pass: t01Pass,
      data: { ...t01Data, skipLinkFocused }
    };
    console.log(`[T01 RESULT] Landmarks: ${t01Data.landmarksComplete} | Single H1: ${t01Data.singleH1} | SkipLink: ${skipLinkFocused} => ${t01Pass ? 'PASS' : 'FAIL'}\n`);

    // ------------------------------------------------------------------------
    // T02: Accessible Name Graph & Reference Integrity (Gate A02)
    // ------------------------------------------------------------------------
    console.log('[RUNNING T02] Analyzing Accessible Name Graph & ARIA References...');
    const t02Data = await page.evaluate(() => {
      const allIds = Array.from(document.querySelectorAll('[id]')).map(el => el.id);
      const dupIds = allIds.filter((id, index) => allIds.indexOf(id) !== index);

      const controls = Array.from(document.querySelectorAll('button, input, textarea, select, a[href]')).map(c => {
        let name = '';
        if (c.getAttribute('aria-label')) name = c.getAttribute('aria-label');
        else if (c.getAttribute('aria-labelledby')) {
          const lEl = document.getElementById(c.getAttribute('aria-labelledby'));
          if (lEl) name = lEl.innerText.trim();
        } else if (c.labels && c.labels[0]) {
          name = c.labels[0].innerText.trim();
        } else if (c.innerText) {
          name = c.innerText.trim();
        } else if (c.value) {
          name = c.value;
        }
        return { tag: c.tagName, id: c.id, type: c.type || null, name };
      });

      const unnamedControls = controls.filter(c => !c.name || c.name.length === 0);

      const ariaRefAttrs = ['aria-labelledby', 'aria-describedby', 'aria-controls', 'aria-owns'];
      const orphanRefs = [];
      ariaRefAttrs.forEach(attr => {
        document.querySelectorAll(`[${attr}]`).forEach(el => {
          const val = el.getAttribute(attr);
          val.split(/\s+/).forEach(refId => {
            if (refId && !document.getElementById(refId)) {
              orphanRefs.push({ elementId: el.id, attribute: attr, missingId: refId });
            }
          });
        });
      });

      return {
        controlsCount: controls.length,
        unnamedCount: unnamedControls.length,
        unnamedControls,
        dupIdsCount: dupIds.length,
        dupIds,
        orphanRefsCount: orphanRefs.length,
        orphanRefs
      };
    });

    const t02Pass = t02Data.unnamedCount === 0 && t02Data.dupIdsCount === 0 && t02Data.orphanRefsCount === 0;
    results.tests.T02 = {
      name: 'Accessible Name Graph & Reference Integrity',
      gate: 'A02',
      pass: t02Pass,
      data: t02Data
    };
    console.log(`[T02 RESULT] Controls: ${t02Data.controlsCount} | Unnamed: ${t02Data.unnamedCount} | DupIDs: ${t02Data.dupIdsCount} | OrphanRefs: ${t02Data.orphanRefsCount} => ${t02Pass ? 'PASS' : 'FAIL'}\n`);

    // ------------------------------------------------------------------------
    // T03: Pure Native Dialog Journey & Trap Assertion (Gate A03, F02, R02, R03)
    // ------------------------------------------------------------------------
    console.log('[RUNNING T03] Executing Pure Native Dialog Journey (Zero Programmatic Focus)...');
    await page.goto(CANDIDATE_URL, { waitUntil: 'load' });

    // Native Tab Sequence from top to #btn-open-guidance (NO page.focus!)
    // Tab 1: Skip link
    await page.keyboard.press('Tab');
    // Tab 2: Header Open Guidance button
    await page.keyboard.press('Tab');

    const triggerActive = await page.evaluate(() => document.activeElement ? document.activeElement.id : null);
    if (triggerActive !== 'btn-open-guidance') {
      throw new Error(`Native Tab sequence failed to land on #btn-open-guidance! Landed on: ${triggerActive}`);
    }

    // Trigger open via Native Enter keypress
    await page.keyboard.press('Enter');
    await new Promise(r => setTimeout(r, 250));

    const dialogState1 = await page.evaluate(() => {
      const dialog = document.getElementById('support-guidance-dialog');
      const active = document.activeElement;
      return {
        isOpen: dialog && (dialog.open || dialog.hasAttribute('open')),
        isModal: dialog && dialog.getAttribute('aria-modal') === 'true',
        activeElementId: active ? active.id : null,
        activeElementText: active ? active.innerText.trim() : null
      };
    });

    // Rigorous Dialog Focus Trap Test: Tab forward and Shift+Tab backward inside dialog
    await page.keyboard.press('Tab');
    const trapFwd = await page.evaluate(() => {
      const dialog = document.getElementById('support-guidance-dialog');
      const active = document.activeElement;
      return { id: active ? active.id : null, insideDialog: dialog.contains(active) };
    });

    await page.keyboard.down('Shift');
    await page.keyboard.press('Tab');
    await page.keyboard.up('Shift');
    const trapBwd = await page.evaluate(() => {
      const dialog = document.getElementById('support-guidance-dialog');
      const active = document.activeElement;
      return { id: active ? active.id : null, insideDialog: dialog.contains(active) };
    });

    const trapAsserted = trapFwd.insideDialog && trapBwd.insideDialog;

    // Press Native Escape to dismiss
    await page.keyboard.press('Escape');
    await new Promise(r => setTimeout(r, 250));

    const dialogState2 = await page.evaluate(() => {
      const dialog = document.getElementById('support-guidance-dialog');
      const active = document.activeElement;
      return {
        isOpen: dialog && (dialog.open || dialog.hasAttribute('open')),
        restoredActiveElementId: active ? active.id : null
      };
    });

    // F02/R03: trapAsserted MUST be part of t03Pass!
    const t03Pass = dialogState1.isOpen &&
                    dialogState1.activeElementId === 'btn-close-guidance' &&
                    trapAsserted &&
                    !dialogState2.isOpen &&
                    dialogState2.restoredActiveElementId === 'btn-open-guidance';

    results.tests.T03 = {
      name: 'Native Dialog Journey & Focus Trap Assertion',
      gate: 'A03',
      pass: t03Pass,
      data: {
        triggerActiveOnTab: triggerActive === 'btn-open-guidance',
        opened: dialogState1.isOpen,
        initialFocusCloseBtn: dialogState1.activeElementId === 'btn-close-guidance',
        focusTrapFwdInside: trapFwd.insideDialog,
        focusTrapBwdInside: trapBwd.insideDialog,
        focusTrapAsserted: trapAsserted,
        closedOnEscape: !dialogState2.isOpen,
        focusRestoredToTrigger: dialogState2.restoredActiveElementId === 'btn-open-guidance'
      }
    };
    console.log(`[T03 RESULT] NativeTrigger: ${triggerActive} | Opened: ${dialogState1.isOpen} | InitFocus: ${dialogState1.activeElementId} | TrapAsserted: ${trapAsserted} | Restored: ${dialogState2.restoredActiveElementId} => ${t03Pass ? 'PASS' : 'FAIL'}\n`);

    // ------------------------------------------------------------------------
    // T04: Empty Submit Validation & Single-Source Announcement (Gate A04, P02, P07, K03)
    // ------------------------------------------------------------------------
    console.log('[RUNNING T04] Testing Empty Submit Validation & Single-Source Announcement...');
    await page.goto(CANDIDATE_URL, { waitUntil: 'load' });

    // Submit empty form via native click
    await page.click('#btn-save-support');
    await new Promise(r => setTimeout(r, 150));

    const t04Data = await page.evaluate(() => {
      const summary = document.getElementById('error-summary');
      const links = Array.from(summary.querySelectorAll('a')).map(a => ({ href: a.getAttribute('href'), text: a.innerText.trim() }));
      const active = document.activeElement;
      const liveAlertText = document.getElementById('live-alert-region').innerText.trim();
      const attempts = window.__TRIPFLOW_ACCESSIBILITY__.getAttempts();

      const radioInvalid = document.getElementById('support-type-group').getAttribute('aria-invalid') === 'true';
      const confirmInvalid = document.getElementById('confirmation-container').getAttribute('aria-invalid') === 'true';

      return {
        summaryVisible: summary && !summary.hidden,
        summaryRole: summary ? summary.getAttribute('role') : null,
        linksCount: links.length,
        links,
        activeElementId: active ? active.id : null,
        liveAlertText,
        liveAlertDidNotRepeat: liveAlertText.length === 0, // K03 Single source!
        attempts,
        radioInvalid,
        confirmInvalid
      };
    });

    const t04Pass = t04Data.summaryVisible && t04Data.summaryRole === 'alert' && t04Data.activeElementId === 'radio-boarding' && t04Data.attempts === 0 && t04Data.liveAlertDidNotRepeat;
    results.tests.T04 = {
      name: 'Empty Submit Validation & Single-Source Announcement',
      gate: 'A04',
      pass: t04Pass,
      data: t04Data
    };
    console.log(`[T04 RESULT] SummaryVisible: ${t04Data.summaryVisible} | FocusFirstInvalid: ${t04Data.activeElementId} | Attempts: ${t04Data.attempts} | NoAlertRepeat: ${t04Data.liveAlertDidNotRepeat} => ${t04Pass ? 'PASS' : 'FAIL'}\n`);

    // Capture mobile validation screenshot
    await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
    const shotMobVal = path.join(SCREENSHOTS_DIR, 'final_mobile_validation_390x844.png');
    await page.screenshot({ path: shotMobVal, fullPage: true });
    results.screenshots['final_mobile_validation_390x844.png'] = { path: 'screenshots/final_mobile_validation_390x844.png', sha256: computeSha256(shotMobVal) };

    // ------------------------------------------------------------------------
    // T05: 201 Characters Error & Repair to 200 (Gate A04)
    // ------------------------------------------------------------------------
    console.log('[RUNNING T05] Testing 201-char Error and Repair to 200...');
    await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
    await page.goto(CANDIDATE_URL, { waitUntil: 'load' });

    // Fill valid radio and confirmation
    await page.click('#radio-boarding');
    await page.click('#checkbox-confirmation');

    // Type 201 characters into #field-details
    const str201 = 'A'.repeat(201);
    await page.type('#field-details', str201);

    // Submit
    await page.click('#btn-save-support');
    await new Promise(r => setTimeout(r, 100));

    const t05State1 = await page.evaluate(() => {
      const errLimit = document.getElementById('error-details-limit');
      const details = document.getElementById('field-details');
      const attempts = window.__TRIPFLOW_ACCESSIBILITY__.getAttempts();
      return {
        errVisible: errLimit && !errLimit.hidden,
        errText: errLimit ? errLimit.innerText.trim() : '',
        ariaInvalid: details.getAttribute('aria-invalid') === 'true',
        attempts
      };
    });

    // Delete 1 character to make it 200 characters
    await page.click('#field-details');
    await page.keyboard.press('Backspace');
    await new Promise(r => setTimeout(r, 100));

    const t05State2 = await page.evaluate(() => {
      const details = document.getElementById('field-details');
      const len = details.value.length;
      return {
        len,
        ariaInvalid: details.getAttribute('aria-invalid') === 'true'
      };
    });

    const t05Pass = t05State1.errVisible && t05State1.errText === 'Chi tiết hỗ trợ không được vượt quá 200 ký tự.' && t05State1.attempts === 0 && t05State2.len === 200 && !t05State2.ariaInvalid;
    results.tests.T05 = {
      name: '201 Characters Error & Repair to 200',
      gate: 'A04',
      pass: t05Pass,
      data: { state201: t05State1, state200: t05State2 }
    };
    console.log(`[T05 RESULT] 201CharsError: ${t05State1.errVisible} (${t05State1.errText}) | Edit200CharsLen: ${t05State2.len} | Attempts: ${t05State1.attempts} => ${t05Pass ? 'PASS' : 'FAIL'}\n`);

    // ------------------------------------------------------------------------
    // T06: Valid Submit Attempt 1 (Failure Lifecycle) (Gate A04, A05, P04, K01)
    // ------------------------------------------------------------------------
    console.log('[RUNNING T06] Executing Valid Submit Attempt 1 (Failure Lifecycle)...');
    await page.goto(CANDIDATE_URL, { waitUntil: 'load' });

    // Fill valid form
    await page.click('#radio-boarding');
    await page.type('#field-details', 'Khách A cần hỗ trợ xe lăn khi lên xuống xe.');
    await page.click('#checkbox-confirmation');

    // Submit Attempt 1
    await page.click('#btn-save-support');

    const t06SavingState = await page.evaluate(() => {
      const btn = document.getElementById('btn-save-support');
      const liveStatus = document.getElementById('live-status-region').innerText.trim();
      const isSaving = window.__TRIPFLOW_ACCESSIBILITY__.getIsSaving();
      return {
        btnText: btn.innerText.trim(),
        ariaBusy: btn.getAttribute('aria-busy'),
        ariaDisabled: btn.getAttribute('aria-disabled'),
        liveStatus,
        isSaving
      };
    });

    // Wait 900ms for mock save failure
    await new Promise(r => setTimeout(r, 900));

    const t06FailureState = await page.evaluate(() => {
      const btn = document.getElementById('btn-save-support');
      const liveAlert = document.getElementById('live-alert-region').innerText.trim();
      const attempts = window.__TRIPFLOW_ACCESSIBILITY__.getAttempts();
      const commits = window.__TRIPFLOW_ACCESSIBILITY__.getCommits();
      const detailsValue = document.getElementById('field-details').value;
      const boardingChecked = document.getElementById('radio-boarding').checked;
      const confirmChecked = document.getElementById('checkbox-confirmation').checked;

      return {
        btnText: btn.innerText.trim(),
        liveAlert,
        attempts,
        commits,
        draftPreserved: boardingChecked && detailsValue === 'Khách A cần hỗ trợ xe lăn khi lên xuống xe.' && confirmChecked
      };
    });

    const t06Pass = t06SavingState.btnText === 'Đang lưu yêu cầu hỗ trợ…' && t06SavingState.isSaving && t06FailureState.btnText === 'Thử lưu lại' && t06FailureState.liveAlert === 'Chưa lưu được yêu cầu hỗ trợ. Nội dung đã nhập vẫn được giữ.' && t06FailureState.draftPreserved && t06FailureState.attempts === 1 && t06FailureState.commits === 0;
    results.tests.T06 = {
      name: 'Valid Submit Attempt 1 (Failure Lifecycle)',
      gate: 'A04',
      pass: t06Pass,
      data: { saving: t06SavingState, failure: t06FailureState }
    };
    console.log(`[T06 RESULT] SavingText: ${t06SavingState.btnText} | FailureBtn: ${t06FailureState.btnText} | Alert: ${t06FailureState.liveAlert} | DraftPreserved: ${t06FailureState.draftPreserved} | Attempts: ${t06FailureState.attempts} => ${t06Pass ? 'PASS' : 'FAIL'}\n`);

    // Capture mobile network error screenshot
    await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
    const shotMobNet = path.join(SCREENSHOTS_DIR, 'final_mobile_network_error_390x844.png');
    await page.screenshot({ path: shotMobNet, fullPage: true });
    results.screenshots['final_mobile_network_error_390x844.png'] = { path: 'screenshots/final_mobile_network_error_390x844.png', sha256: computeSha256(shotMobNet) };

    // ------------------------------------------------------------------------
    // T07: Retry Attempt 2 (Success Lifecycle) (Gate A04, A05, P04)
    // ------------------------------------------------------------------------
    console.log('[RUNNING T07] Executing Retry Attempt 2 (Success Lifecycle)...');
    await page.click('#btn-save-support');

    // Wait 900ms for success
    await new Promise(r => setTimeout(r, 900));

    const t07SuccessState = await page.evaluate(() => {
      const liveStatus = document.getElementById('live-status-region').innerText.trim();
      const committedSection = document.getElementById('committed-summary-section');
      const committedSupportType = document.getElementById('committed-support-type').innerText.trim();
      const committedDetails = document.getElementById('committed-details').innerText.trim();
      const btnEdit = document.getElementById('btn-edit-saved');
      const attempts = window.__TRIPFLOW_ACCESSIBILITY__.getAttempts();
      const commits = window.__TRIPFLOW_ACCESSIBILITY__.getCommits();

      return {
        liveStatus,
        committedVisible: committedSection && !committedSection.hidden,
        committedSupportType,
        committedDetails,
        btnEditExists: !!btnEdit,
        btnEditText: btnEdit ? btnEdit.innerText.trim() : null,
        attempts,
        commits
      };
    });

    const t07Pass = t07SuccessState.liveStatus === 'Đã lưu yêu cầu hỗ trợ cho hồ sơ AR-901.' && t07SuccessState.committedVisible && t07SuccessState.committedSupportType === 'Hỗ trợ lên xuống phương tiện' && t07SuccessState.committedDetails === 'Khách A cần hỗ trợ xe lăn khi lên xuống xe.' && t07SuccessState.btnEditText === 'Sửa yêu cầu' && t07SuccessState.attempts === 2 && t07SuccessState.commits === 1;
    results.tests.T07 = {
      name: 'Retry Attempt 2 (Success Lifecycle)',
      gate: 'A04',
      pass: t07Pass,
      data: t07SuccessState
    };
    console.log(`[T07 RESULT] SuccessLive: ${t07SuccessState.liveStatus} | SummaryVisible: ${t07SuccessState.committedVisible} | EditBtn: ${t07SuccessState.btnEditText} | Attempts: ${t07SuccessState.attempts} | Commits: ${t07SuccessState.commits} => ${t07Pass ? 'PASS' : 'FAIL'}\n`);

    // Capture mobile success screenshot
    const shotMobSucc = path.join(SCREENSHOTS_DIR, 'final_mobile_success_390x844.png');
    await page.screenshot({ path: shotMobSucc, fullPage: true });
    results.screenshots['final_mobile_success_390x844.png'] = { path: 'screenshots/final_mobile_success_390x844.png', sha256: computeSha256(shotMobSucc) };

    // ------------------------------------------------------------------------
    // T08: Native Duplicate Activation Guard (Gate A05, F02, R04)
    // ------------------------------------------------------------------------
    console.log('[RUNNING T08] Testing Native Duplicate Activation Guard (Pointer Click + Native Enter Keypress)...');
    await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
    await page.goto(CANDIDATE_URL, { waitUntil: 'load' });

    // Setup valid form
    await page.click('#radio-boarding');
    await page.click('#checkbox-confirmation');

    // Trigger double activation via Native Pointer click + Native Enter keypress within saving window
    // 1. Pointer click
    await page.click('#btn-save-support');
    // 2. Native Enter keypress immediately in saving window
    await page.keyboard.press('Enter');

    // Wait 900ms for attempt 1 failure to settle
    await new Promise(r => setTimeout(r, 900));

    const t08Attempts = await page.evaluate(() => window.__TRIPFLOW_ACCESSIBILITY__.getAttempts());
    const t08Pass = t08Attempts === 1;
    results.tests.T08 = {
      name: 'Native Duplicate Activation Guard',
      gate: 'A05',
      pass: t08Pass,
      data: {
        method: 'pointer_click_then_native_enter_in_saving_window',
        attemptsAfterDuplicateActivation: t08Attempts,
        expected: 1
      }
    };
    console.log(`[T08 RESULT] Attempts after pointer+enter duplicate: ${t08Attempts} (Expected: 1) => ${t08Pass ? 'PASS' : 'FAIL'}\n`);

    // ------------------------------------------------------------------------
    // T09: Native No-Steal Focus & Strict Node Identity (Gate A05, F02, R05)
    // ------------------------------------------------------------------------
    console.log('[RUNNING T09] Testing Native No-Steal Focus & Strict Node Identity...');
    await page.goto(CANDIDATE_URL, { waitUntil: 'load' });

    await page.click('#radio-boarding');
    await page.click('#checkbox-confirmation');

    // Register initial button node and track body focus events
    await page.evaluate(() => {
      window.__initialSaveBtn = document.getElementById('btn-save-support');
      window.__bodyFocusCount = 0;
      document.body.addEventListener('focus', (e) => {
        if (e.target === document.body) {
          window.__bodyFocusCount++;
        }
      }, true);
    });

    // Click Save
    await page.click('#btn-save-support');

    // Within saving window (t=100ms): Tab naturally to #btn-open-guidance (NO programmatic focus!)
    await new Promise(r => setTimeout(r, 100));
    // Focus was on #btn-save-support. Shift+Tab backward takes us up towards header
    // Or let's naturally tab to #btn-open-guidance via keyboard
    await page.keyboard.down('Shift');
    await page.keyboard.press('Tab');
    await page.keyboard.up('Shift');
    // Tab back up until #btn-open-guidance is active
    for (let tabI = 0; tabI < 8; tabI++) {
      const curActive = await page.evaluate(() => document.activeElement ? document.activeElement.id : null);
      if (curActive === 'btn-open-guidance') break;
      await page.keyboard.down('Shift');
      await page.keyboard.press('Tab');
      await page.keyboard.up('Shift');
    }

    const midSavingActive = await page.evaluate(() => document.activeElement ? document.activeElement.id : null);

    // Wait for save completion at 850ms
    await new Promise(r => setTimeout(r, 800));

    const t09Data = await page.evaluate(() => {
      const active = document.activeElement ? document.activeElement.id : null;
      const curSaveBtn = document.getElementById('btn-save-support');
      const nodeIdentityPreserved = window.__initialSaveBtn === curSaveBtn;
      const bodyFocusEvents = window.__bodyFocusCount;

      return {
        activeElementAfterSave: active,
        nodeIdentityPreserved,
        bodyFocusEvents
      };
    });

    const t09Pass = t09Data.activeElementAfterSave === 'btn-open-guidance' &&
                    t09Data.nodeIdentityPreserved &&
                    t09Data.bodyFocusEvents === 0;

    results.tests.T09 = {
      name: 'Native No-Steal Focus & Strict Node Identity',
      gate: 'A05',
      pass: t09Pass,
      data: {
        midSavingActive,
        ...t09Data,
        expectedActive: 'btn-open-guidance'
      }
    };
    console.log(`[T09 RESULT] FocusPreserved: ${t09Data.activeElementAfterSave} | NodeIdentity: ${t09Data.nodeIdentityPreserved} | BodyFocusEvents: ${t09Data.bodyFocusEvents} => ${t09Pass ? 'PASS' : 'FAIL'}\n`);

    // ------------------------------------------------------------------------
    // T10: 5-Viewport Reflow Matrix, Clipping & Overlap Audit (Gate A06, F03, R06-R09)
    // ------------------------------------------------------------------------
    console.log('[RUNNING T10] Auditing 5-Viewport Reflow Matrix, Text Scaling, Clipping & Overlap Collision...');
    
    const viewports = [
      { name: 'reflow_320x800_default', width: 320, height: 800, scale: '100%' },
      { name: 'text_scale_320x800_200pct', width: 320, height: 800, scale: '200%' },
      { name: 'mobile_390x844_default', width: 390, height: 844, scale: '100%' },
      { name: 'tablet_768x1024_default', width: 768, height: 1024, scale: '100%' },
      { name: 'desktop_1440x900_default', width: 1440, height: 900, scale: '100%' }
    ];

    const reflowMatrix = [];
    let allViewportsNoOverflow = true;
    let allViewportsNoClipping = true;
    let allViewportsNoOverlap = true;

    for (const vp of viewports) {
      await page.setViewport({ width: vp.width, height: vp.height, deviceScaleFactor: 2 });
      await page.goto(CANDIDATE_URL, { waitUntil: 'load' });

      if (vp.scale !== '100%') {
        await page.evaluate((s) => { document.documentElement.style.fontSize = s; }, vp.scale);
        await new Promise(r => setTimeout(r, 150));
      }

      const vpAudit = await page.evaluate((vpName, vpWidth) => {
        const docEl = document.documentElement;
        const bodyEl = document.body;
        const scrollW = Math.max(docEl.scrollWidth, bodyEl.scrollWidth);
        const clientW = docEl.clientWidth;
        const hasHorizontalOverflow = scrollW > clientW + 1; // 1px threshold for fractional subpixels

        // Check text elements clipping (bounding rect width/height > 0 and right <= clientW + 2)
        const textNodes = Array.from(document.querySelectorAll('label, h1, h2, legend, button, p, a.skip-link'))
          .filter(el => !el.closest('[hidden], dialog:not([open])'))
          .map(el => {
            const r = el.getBoundingClientRect();
            return {
              tag: el.tagName,
              id: el.id,
              w: Math.round(r.width),
              h: Math.round(r.height),
              right: Math.round(r.right),
              clipped: r.width <= 0 || r.height <= 0 || r.right > clientW + 2
            };
          });
        const clippedCount = textNodes.filter(t => t.clipped).length;

        // Check interactive controls overlap collision
        const controls = Array.from(document.querySelectorAll('button, a.skip-link, input[type="radio"], input[type="checkbox"], textarea'))
          .filter(el => !el.closest('[hidden], dialog:not([open])'))
          .map(el => {
            const r = el.getBoundingClientRect();
            return { id: el.id || el.tagName, r };
          });

        let overlapCollisions = 0;
        for (let i = 0; i < controls.length; i++) {
          for (let j = i + 1; j < controls.length; j++) {
            const a = controls[i].r;
            const b = controls[j].r;
            // Check bounding box intersection
            const xOverlap = a.left < b.right && a.right > b.left;
            const yOverlap = a.top < b.bottom && a.bottom > b.top;
            if (xOverlap && yOverlap) {
              overlapCollisions++;
            }
          }
        }

        return {
          vpName,
          scrollW,
          clientW,
          hasHorizontalOverflow,
          clippedCount,
          overlapCollisions
        };
      }, vp.name, vp.width);

      reflowMatrix.push(vpAudit);
      if (vpAudit.hasHorizontalOverflow) allViewportsNoOverflow = false;
      if (vpAudit.clippedCount > 0) allViewportsNoClipping = false;
      if (vpAudit.overlapCollisions > 0) allViewportsNoOverlap = false;

      // Capture authoritative screenshots
      if (vp.name === 'reflow_320x800_default') {
        const shotReflow = path.join(SCREENSHOTS_DIR, 'final_reflow_320x800.png');
        await page.screenshot({ path: shotReflow, fullPage: true });
        results.screenshots['final_reflow_320x800.png'] = { path: 'screenshots/final_reflow_320x800.png', sha256: computeSha256(shotReflow) };
      }
      if (vp.name === 'text_scale_320x800_200pct') {
        const shotTextScale = path.join(SCREENSHOTS_DIR, 'final_text_resize_200_percent.png');
        await page.screenshot({ path: shotTextScale, fullPage: true });
        results.screenshots['final_text_resize_200_percent.png'] = {
          path: 'screenshots/final_text_resize_200_percent.png',
          sha256: computeSha256(shotTextScale),
          label: 'TEXT_SCALE_SIMULATION'
        };
      }
    }

    const t10Pass = allViewportsNoOverflow && allViewportsNoClipping && allViewportsNoOverlap;
    results.tests.T10 = {
      name: '5-Viewport Reflow Matrix, Clipping & Overlap Collision Audit',
      gate: 'A06',
      pass: t10Pass,
      data: {
        allViewportsNoOverflow,
        allViewportsNoClipping,
        allViewportsNoOverlap,
        matrix: reflowMatrix,
        verticalScrollAllowed: true
      }
    };
    console.log(`[T10 RESULT] 5-Viewport Matrix: 0 Overflow: ${allViewportsNoOverflow} | 0 Clipping: ${allViewportsNoClipping} | 0 Overlap: ${allViewportsNoOverlap} => ${t10Pass ? 'PASS' : 'FAIL'}\n`);

    // ------------------------------------------------------------------------
    // T11: Forced-Colors Preflight (In Conjunction), Target Inventory & Contrast (Gate A07, F04, R10, R11)
    // ------------------------------------------------------------------------
    console.log('[RUNNING T11] Auditing Forced-Colors Preflight, Complete Target Inventory & Fail-Closed Contrast...');
    await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
    await page.goto(CANDIDATE_URL, { waitUntil: 'load' });

    // 1. Target Size Audit (Complete Real Controls Inventory: Textarea, Buttons, Skip link, Labels)
    const targetAudit = await page.evaluate(() => {
      const controls = Array.from(document.querySelectorAll('button, a.skip-link, textarea#field-details, .target-container'))
        .filter(el => !el.closest('[hidden], dialog:not([open])'))
        .map(el => {
          const rect = el.getBoundingClientRect();
          return {
            id: el.id || el.className,
            tag: el.tagName,
            w: Math.round(rect.width),
            h: Math.round(rect.height),
            meetsWcag24: rect.width >= 24 && rect.height >= 24,
            meetsProject44: rect.width >= 44 && rect.height >= 44
          };
        });

      const failedWcag24 = controls.filter(c => !c.meetsWcag24);
      const failedProject44 = controls.filter(c => !c.meetsProject44);

      return {
        totalControls: controls.length,
        failedWcag24Count: failedWcag24.length,
        failedProject44Count: failedProject44.length,
        controls
      };
    });

    // 2. Comprehensive 6-Pair Fail-Closed Contrast Audit
    const contrastAudit = await page.evaluate(() => {
      const getLum = ([r, g, b]) => {
        const [rs, gs, bs] = [r, g, b].map(c => {
          c = c / 255;
          return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
        });
        return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
      };
      const getRatio = (c1, c2) => {
        const l1 = getLum(c1);
        const l2 = getLum(c2);
        return ((Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05));
      };
      const parseRgb = (s) => {
        const m = s.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
        return m ? [parseInt(m[1]), parseInt(m[2]), parseInt(m[3])] : null;
      };

      const pairs = [
        { name: 'Primary Text on Canvas', fg: getComputedStyle(document.body).color, bg: getComputedStyle(document.body).backgroundColor, req: 4.5 },
        { name: 'Secondary Text on Card', fg: getComputedStyle(document.querySelector('.case-item-label')).color, bg: getComputedStyle(document.querySelector('.case-summary-card')).backgroundColor, req: 4.5 },
        { name: 'Primary Button Text on CTA', fg: getComputedStyle(document.getElementById('btn-save-support')).color, bg: getComputedStyle(document.getElementById('btn-save-support')).backgroundColor, req: 4.5 },
        { name: 'Control Structural Border on Card', fg: getComputedStyle(document.querySelector('fieldset.form-fieldset')).borderColor, bg: getComputedStyle(document.querySelector('.intake-card')).backgroundColor, req: 3.0 },
        { name: 'Textarea Border on Surface', fg: getComputedStyle(document.getElementById('field-details')).borderColor, bg: getComputedStyle(document.getElementById('field-details')).backgroundColor, req: 3.0 },
        { name: 'Focus Visible Ring on Canvas', fg: '#2563EB', bg: '#FAF9F6', req: 3.0 }
      ];

      return pairs.map(p => {
        const cFg = p.fg.startsWith('#') ? [37, 99, 235] : parseRgb(p.fg);
        const cBg = p.bg.startsWith('#') ? [250, 249, 246] : parseRgb(p.bg);
        if (!cFg || !cBg) return { ...p, ratio: 0, pass: false, error: 'Color parse failure' };
        const ratio = Math.round(getRatio(cFg, cBg) * 100) / 100;
        return { ...p, ratio, pass: ratio >= p.req };
      });
    });

    const contrastAllPass = contrastAudit.every(p => p.pass);

    // 3. Complete Rendered DOM Zero Motion Audit
    const zeroMotionAudit = await page.evaluate(() => {
      const allRendered = Array.from(document.querySelectorAll('*')).filter(el => {
        const s = window.getComputedStyle(el);
        return s.display !== 'none' && s.visibility !== 'hidden';
      });
      let violatingCount = 0;
      for (const el of allRendered) {
        const s = window.getComputedStyle(el);
        if (s.transitionDuration && s.transitionDuration !== '0s' && s.transitionDuration !== '0ms') violatingCount++;
        if (s.animationDuration && s.animationDuration !== '0s' && s.animationDuration !== '0ms') violatingCount++;
      }
      return { zeroMotionPass: violatingCount === 0, violatingCount };
    });

    // 4. Forced-Colors Capability Preflight (MUST PARTICIPATE IN GATE CONJUNCTION!)
    let forcedColorsStatus = 'NOT_EXECUTED_ENVIRONMENT_UNSUPPORTED';
    let forcedColorsActive = false;
    try {
      await cdpClient.send('Emulation.setEmulatedMedia', {
        media: 'page',
        features: [{ name: 'forced-colors', value: 'active' }]
      });
      forcedColorsActive = await page.evaluate(() => window.matchMedia('(forced-colors: active)').matches);
      if (forcedColorsActive) {
        forcedColorsStatus = 'EXECUTED_PASS';
      } else {
        forcedColorsStatus = 'EXECUTED_FAIL';
      }
    } catch (e) {
      console.log('[INFO] Forced-colors emulation preflight failed:', e.message);
      forcedColorsStatus = 'NOT_EXECUTED_ENVIRONMENT_UNSUPPORTED';
    }

    const shotForced = path.join(SCREENSHOTS_DIR, 'final_forced_colors.png');
    await page.screenshot({ path: shotForced, fullPage: true });
    results.screenshots['final_forced_colors.png'] = {
      path: 'screenshots/final_forced_colors.png',
      sha256: computeSha256(shotForced),
      forcedColorsStatus,
      forcedColorsActive
    };

    // Reset media emulation
    await cdpClient.send('Emulation.setEmulatedMedia', { media: 'page', features: [] });

    // R10: Forced-Colors MUST be part of Gate A07 Conjunction!
    const targetWcag24Pass = targetAudit.failedWcag24Count === 0;
    const targetProjectPass = targetAudit.failedProject44Count === 0;
    const forcedColorsGatePass = (forcedColorsStatus === 'EXECUTED_PASS');

    const t11Pass = forcedColorsGatePass && targetProjectPass && targetWcag24Pass && contrastAllPass && zeroMotionAudit.zeroMotionPass;
    results.tests.T11 = {
      name: 'Forced-Colors, Target Size & Contrast',
      gate: 'A07',
      pass: t11Pass,
      data: {
        forcedColorsStatus,
        forcedColorsActive,
        forcedColorsGatePass,
        wcag24MinimumPass: targetWcag24Pass,
        project44InvariantPass: targetProjectPass,
        contrastAudit,
        contrastAllPass,
        zeroMotionAudit
      }
    };
    console.log(`[T11 RESULT] ForcedColors: ${forcedColorsStatus} | Target44: ${targetProjectPass} | Target24: ${targetWcag24Pass} | Contrast6Pairs: ${contrastAllPass} | ZeroMotion: ${zeroMotionAudit.zeroMotionPass} => ${t11Pass ? 'PASS' : 'FAIL'}\n`);

    // ------------------------------------------------------------------------
    // T12: Evidence Integrity, AX Tree & Dynamic Controller Docs Audit (Gate A08, F05, R12-R14)
    // ------------------------------------------------------------------------
    console.log('[RUNNING T12] Auditing AX Tree Snapshot, Authoritative Screenshots & Controller Document Hashes...');
    await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
    await page.goto(CANDIDATE_URL, { waitUntil: 'load' });

    // 1. Export Chromium CDP Accessibility Tree
    let axTreeNodes = [];
    try {
      const axTreeResponse = await cdpClient.send('Accessibility.getFullAXTree');
      axTreeNodes = axTreeResponse.nodes;
      const axTreePath = path.join(BASE_DIR, 'AX_TREE.json');
      fs.writeFileSync(axTreePath, JSON.stringify(axTreeNodes, null, 2), 'utf8');
      console.log(`[AX TREE] Successfully exported ${axTreeNodes.length} nodes to AX_TREE.json`);
    } catch (e) {
      console.warn('[AX TREE WARNING] Could not retrieve full AX Tree:', e.message);
    }

    // 2. Capture Initial Clean State Screenshots (F01 Resolved Proofs)
    const shotFinalDesk = path.join(SCREENSHOTS_DIR, 'final_desktop_1440x900.png');
    await page.screenshot({ path: shotFinalDesk, fullPage: true });
    results.screenshots['final_desktop_1440x900.png'] = { path: 'screenshots/final_desktop_1440x900.png', sha256: computeSha256(shotFinalDesk) };

    await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
    const shotFinalMob = path.join(SCREENSHOTS_DIR, 'final_mobile_390x844.png');
    await page.screenshot({ path: shotFinalMob, fullPage: true });
    results.screenshots['final_mobile_390x844.png'] = { path: 'screenshots/final_mobile_390x844.png', sha256: computeSha256(shotFinalMob) };

    // Baseline, Direction A, Direction B screenshots
    await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 2 });
    await page.goto(BASELINE_URL, { waitUntil: 'load' });
    const shotBaseDesk = path.join(SCREENSHOTS_DIR, 'baseline_desktop_1440x900.png');
    await page.screenshot({ path: shotBaseDesk, fullPage: true });
    results.screenshots['baseline_desktop_1440x900.png'] = { path: 'screenshots/baseline_desktop_1440x900.png', sha256: computeSha256(shotBaseDesk) };

    await page.goto(OPTION_A_URL, { waitUntil: 'load' });
    const shotOptA = path.join(SCREENSHOTS_DIR, 'direction_a_desktop_1440x900.png');
    await page.screenshot({ path: shotOptA, fullPage: true });
    results.screenshots['direction_a_desktop_1440x900.png'] = { path: 'screenshots/direction_a_desktop_1440x900.png', sha256: computeSha256(shotOptA) };

    await page.goto(OPTION_B_URL, { waitUntil: 'load' });
    const shotOptB = path.join(SCREENSHOTS_DIR, 'direction_b_desktop_1440x900.png');
    await page.screenshot({ path: shotOptB, fullPage: true });
    results.screenshots['direction_b_desktop_1440x900.png'] = { path: 'screenshots/direction_b_desktop_1440x900.png', sha256: computeSha256(shotOptB) };

    // 3. Compute Source File Hashes
    results.file_hashes['index.html'] = computeSha256(CANDIDATE_PATH);
    results.file_hashes['baseline/index.html'] = computeSha256(BASELINE_PATH);
    results.file_hashes['directions/option_a.html'] = computeSha256(OPTION_A_PATH);
    results.file_hashes['directions/option_b.html'] = computeSha256(OPTION_B_PATH);
    results.file_hashes['ACCESSIBILITY_CONTRACT.yaml'] = computeSha256(CONTRACT_PATH);
    results.file_hashes['ASSISTIVE_TECH_REVIEW_PLAN.md'] = computeSha256(PLAN_PATH);

    // 4. Dynamic Audit of 4 Controller Documents (R12 Byte-Identical Invariant)
    let allControllerDocsMatch = true;
    for (const [docName, expectedHash] of Object.entries(OFFICIAL_CONTROLLER_DOCS)) {
      const docPath = path.join(BASE_DIR, docName);
      const computed = computeSha256(docPath);
      const matches = computed === expectedHash;
      results.official_documents_audit[docName] = {
        path: docName,
        expectedSha256: expectedHash,
        computedSha256: computed,
        matches
      };
      if (!matches) {
        console.error(`[HASH MISMATCH] ${docName}: Computed ${computed} !== Expected ${expectedHash}`);
        allControllerDocsMatch = false;
      }
    }

    // 5. Report Governance Audit (R16 - No Unilateral VERDICT: PASS Claim)
    let reportGovernancePass = true;
    if (fs.existsSync(REPORT_PATH)) {
      const repContent = fs.readFileSync(REPORT_PATH, 'utf8');
      if (repContent.includes('VERDICT: PASS') || repContent.includes('VERDICT: ACCEPTED')) {
        reportGovernancePass = false;
      }
    }

    const t12Pass = axTreeNodes.length >= 130 &&
                    Object.keys(results.screenshots).length >= 11 &&
                    allControllerDocsMatch &&
                    reportGovernancePass;

    results.tests.T12 = {
      name: 'AX Tree Snapshot & Evidence Integrity',
      gate: 'A08',
      pass: t12Pass,
      data: {
        axTreeNodesCount: axTreeNodes.length,
        screenshotsCount: Object.keys(results.screenshots).length,
        allControllerDocsMatch,
        reportGovernancePass
      }
    };
    console.log(`[T12 RESULT] AX Nodes: ${axTreeNodes.length} | Screenshots: ${Object.keys(results.screenshots).length}/11 | ControllerDocsByteIdentical: ${allControllerDocsMatch} | ReportGovernance: ${reportGovernancePass} => ${t12Pass ? 'PASS' : 'FAIL'}\n`);

    // ------------------------------------------------------------------------
    // SYNTHESIZE GATES A01–A08 & FAIL-CLOSED OVERALL STATUS (R14)
    // ------------------------------------------------------------------------
    results.gates.A01 = results.tests.T01.pass;
    results.gates.A02 = results.tests.T02.pass;
    results.gates.A03 = results.tests.T03.pass;
    results.gates.A04 = results.tests.T04.pass && results.tests.T05.pass && results.tests.T06.pass && results.tests.T07.pass;
    results.gates.A05 = results.tests.T08.pass && results.tests.T09.pass;
    results.gates.A06 = results.tests.T10.pass;
    results.gates.A07 = results.tests.T11.pass;
    results.gates.A08 = results.tests.T12.pass;

    const allGatesPass = Object.values(results.gates).every(v => v === true);

    if (allGatesPass) {
      results.overall_status = 'SELF_CHECK_PASS / SUBMITTED_FOR_CONTROLLER_REVIEW';
    } else {
      results.overall_status = 'SELF_CHECK_FAIL';
    }

    // Export VERIFICATION.json
    const verificationPath = path.join(BASE_DIR, 'VERIFICATION.json');
    fs.writeFileSync(verificationPath, JSON.stringify(results, null, 2), 'utf8');
    console.log(`[VERIFICATION] Telemetry exported to: ${verificationPath}`);

    // Print Final Gate Summary Matrix
    console.log('\n======================================================================');
    console.log(' GATE EVALUATION SUMMARY MATRIX — MODULE 09 (REPAIR ROUND 1)');
    console.log('======================================================================');
    console.log(` Gate A01 (Semantic Structure & Reading Order    ) : [ ${results.gates.A01 ? 'PASS' : 'FAIL'} ]`);
    console.log(` Gate A02 (Accessible Name & ARIA Reference Graph) : [ ${results.gates.A02 ? 'PASS' : 'FAIL'} ]`);
    console.log(` Gate A03 (Native Keyboard Journey & Modal Dialog) : [ ${results.gates.A03 ? 'PASS' : 'FAIL'} ]`);
    console.log(` Gate A04 (Validation, Error Recovery & FSM      ) : [ ${results.gates.A04 ? 'PASS' : 'FAIL'} ]`);
    console.log(` Gate A05 (Live Announcement & No-Steal Invariant) : [ ${results.gates.A05 ? 'PASS' : 'FAIL'} ]`);
    console.log(` Gate A06 (Reflow 320px & Text Scaling Stress    ) : [ ${results.gates.A06 ? 'PASS' : 'FAIL'} ]`);
    console.log(` Gate A07 (Forced-Colors, Target Size & Contrast ) : [ ${results.gates.A07 ? 'PASS' : 'FAIL'} ]`);
    console.log(` Gate A08 (Evidence Integrity & AX Tree Snapshot ) : [ ${results.gates.A08 ? 'PASS' : 'FAIL'} ]`);
    console.log('----------------------------------------------------------------------');
    console.log(` OVERALL VERDICT: ${results.overall_status}`);
    console.log('======================================================================\n');

    if (!allGatesPass) {
      console.error('[FAIL-CLOSED] One or more gates failed verification!');
      process.exit(1);
    }

    process.exit(0);

  } catch (err) {
    console.error('[UNCAUGHT ERROR IN HARNESS]', err);
    results.overall_status = 'SELF_CHECK_FAIL';
    results.fatal_error = err.message;
    const verificationPath = path.join(BASE_DIR, 'VERIFICATION.json');
    fs.writeFileSync(verificationPath, JSON.stringify(results, null, 2), 'utf8');
    process.exit(1);
  } finally {
    await page.close();
    await browser.disconnect();
  }
})();
