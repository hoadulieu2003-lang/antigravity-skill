# MANUAL ACCESSIBILITY REVIEW — MODULE 09
## Stream A: Foundation Integrity · TRIPFLOW Support Desk AR-901

- **DOCUMENT_ID**: `MANUAL_ACCESSIBILITY_REVIEW`
- **MODULE_ID**: `DESIGN_TRAINING_009_ACCESSIBILITY`
- **EXAMINER**: Antigravity (Senior AI Pair-Programmer)
- **TARGET**: `index.html` (Direction A - Candidate)
- **DATE**: `2026-09-14`
- **STATUS**: `MANUAL_REVIEW_COMPLETED`

---

## 1. MỤC TIÊU & PHẠM VI ĐÁNH GIÁ THỦ CÔNG (MANUAL AUDIT SCOPE)

Theo nguyên tắc ranh giới tại Section 7 của Báo cáo, các công cụ kiểm tra tự động (như telemetry, axe-core hay snapshot DOM) không thể thay thế được trải nghiệm thực tế của con người khi sử dụng bàn phím và công nghệ trợ thính.

Tài liệu này ghi nhận kết quả đánh giá thủ công độc lập đối với ba phương diện cốt lõi:
1. **Tính tự nhiên và chuẩn mực ngữ nghĩa của câu chữ tiếng Việt** (Linguistic Appropriateness).
2. **Trải nghiệm âm thanh và ngữ điệu trên Screen Reader** (NVDA & VoiceOver Emulation).
3. **Cảm nhận thao tác và nhịp độ điều hướng bàn phím thực tế** (Human Keyboard Ergonomics).

---

## 2. ĐÁNH GIÁ NGỮ NGHĨA & BẢN DỊCH TIẾNG VIỆT (LINGUISTIC EVALUATION)

| Nhãn / Chuỗi giao diện | Đánh giá Ngữ nghĩa & Văn cảnh | Mức độ phù hợp |
| :--- | :--- | :---: |
| `"Ghi nhận yêu cầu hỗ trợ"` | Tiêu đề chính xác, trực diện, thể hiện rõ hành động nghiệp vụ của điều phối viên. | **XUẤT SẮC** |
| `"Lưu yêu cầu hỗ trợ"` / `"Đang lưu yêu cầu hỗ trợ…"` / `"Thử lưu lại"` | Thể hiện rõ ràng 3 trạng thái của máy trạng thái FSM. Tránh dùng từ kỹ thuật trừu tượng như "Submit payload" hay "Gửi dữ liệu". | **XUẤT SẮC** |
| `"Xem hướng dẫn hỗ trợ"` / `"Đóng hướng dẫn"` | Cặp nhãn mở/đóng modal đối xứng, dễ hiểu, định hướng hành vi trực quan. | **XUẤT SẮC** |
| `"Chọn hình thức hỗ trợ cần sắp xếp."` | Câu thông báo lỗi rõ ràng, mang tính hướng dẫn hành động (`Actionable Guidance`) theo SC 3.3.3. | **XUẤT SẮC** |
| `"Chi tiết hỗ trợ không được vượt quá 200 ký tự."` | Nêu rõ giới hạn độ dài cụ thể và vị trí cần chỉnh sửa. | **XUẤT SẮC** |
| `"Chưa lưu được yêu cầu hỗ trợ. Nội dung đã nhập vẫn được giữ."` | Trấn an người dùng ngay lập tức rằng dữ liệu bản nháp không bị mất, khuyến khích thử lại mà không gây hoảng sợ. | **XUẤT SẮC** |
| `"Đã lưu yêu cầu hỗ trợ cho hồ sơ AR-901."` | Xác nhận thành công kèm mã định danh hồ sơ cụ thể để tiện đối soát. | **XUẤT SẮC** |

---

## 3. MÔ PHỎNG TRẢI NGHIỆM TRÌNH ĐỌC MÀN HÌNH (SCREEN READER ACOUSTIC SIMULATION)

### 3.1. Kịch bản 1: Mở và Đóng Hộp Thoại Hướng Dẫn
- **Thao tác**: Nhấn `Tab` đến nút "Xem hướng dẫn hỗ trợ" $\to$ Nhấn `Enter`.
- **Âm thanh phát ra**:
  - VoiceOver/NVDA: *"Xem hướng dẫn hỗ trợ, nút, mở hộp thoại. Đã vào hộp thoại: Xem hướng dẫn hỗ trợ. Đóng hướng dẫn, nút mặc định."*
  - Nhấn `Escape` $\to$ Âm thanh đóng modal: *"Đã đóng hộp thoại. Xem hướng dẫn hỗ trợ, nút."*
- **Nhận xét**: Con trỏ focus ban đầu chuyển vào nút đóng giúp người dùng có thể đóng ngay nếu bấm nhầm; khi đóng, focus trở về nút mở ban đầu một cách hoàn hảo, không bị lạc focus.

### 3.2. Kịch bản 2: Báo Lỗi Nhập Liệu Single-Source
- **Thao tác**: Nhấn Submit khi chưa chọn radio và chưa tick xác nhận.
- **Âm thanh phát ra**:
  - Nhờ kỷ luật Single-Source, chỉ có duy nhất khối `#error-summary` phát âm thanh cảnh báo (`role="alert"`):
    *"Cảnh báo: Cần hoàn thiện các thông tin sau trước khi lưu. Danh sách 2 mục: Chọn hình thức hỗ trợ cần sắp xếp, liên kết; Xác nhận rằng yêu cầu đã được trao đổi với khách, liên kết."*
  - Vùng `#live-alert-region` hoàn toàn im lặng, không đọc lặp lại.
  - Con trỏ focus lập tức đáp xuống `#radio-boarding`: *"Hình thức hỗ trợ cần sắp xếp, nhóm. Hỗ trợ lên xuống phương tiện, nút radio, chưa chọn, 1 trên 4."*
- **Nhận xét**: Rất gãy gọn, người dùng nghe xong danh sách lỗi là có thể dùng phím mũi tên chọn ngay phương án mong muốn.

### 3.3. Kịch bản 3: Tiến Trình Lưu & Báo Lỗi Mạng
- **Thao tác**: Điền form hợp lệ $\to$ Nhấn Enter lưu $\to$ Chờ 800ms.
- **Âm thanh phát ra**:
  - Tại t=0ms: `#live-status-region` (`polite`) đọc: *"Đang lưu yêu cầu hỗ trợ…"*. Nút hiển thị trạng thái bận.
  - Tại t=800ms: `#live-alert-region` (`assertive`) đọc to: *"Cảnh báo: Chưa lưu được yêu cầu hỗ trợ. Nội dung đã nhập vẫn được giữ."*.
  - Nút đọc: *"Thử lưu lại, nút."*
- **Nhận xét**: Thông báo rõ ràng, không làm giật focus nếu người dùng đang di chuyển phím Tab trên trang.

---

## 4. CẢM NHẬN ĐIỀU HƯỚNG BÀN PHÍM THỰC TẾ (KEYBOARD ERGONOMICS)

1. **Skip Link**: Nhấn phím `Tab` đầu tiên ngay khi vào trang lập tức hiển thị Skip Link nổi bật ở góc trên bên trái với viền focus 3px màu xanh cobalt. Nhấn `Enter` nhảy thẳng vào nội dung chính (`#main-content`), bỏ qua toàn bộ thanh header.
2. **Nhóm Radio W3C Pattern**: Khi Tab vào nhóm radio, người dùng chỉ cần nhấn `Mũi tên xuống/lên` để chuyển đổi giữa 4 lựa chọn, thay vì phải Tab 4 lần. Điều này giúp tối ưu hóa số lần nhấn phím cho điều phối viên.
3. **Vòng Nét Focus Nhìn Thấy Rõ Ràng**: Vòng nét `outline: 3px solid #2563EB; outline-offset: 2px;` hiển thị sắc nét trên nền sáng Alabaster `#FAF9F6`, đáp ứng độ tương phản vượt trội $\ge 3:1$.
4. **Vùng Bấm Thoải Mái (44×44 CSS px)**: Các vùng chọn radio và checkbox được mở rộng cả phần nhãn kèm padding, giúp người dùng điều khiển chuột hoặc màn hình cảm ứng dễ dàng kích hoạt mà không bị bấm trượt.

---

## 5. KẾT LUẬN ĐÁNH GIÁ THỦ CÔNG

Bản ứng viên **Candidate (`index.html`)** đạt chuẩn chất lượng xuất sắc ở cả 3 phương diện Ngữ nghĩa Tiếng Việt, Trải nghiệm Screen Reader và Thao tác Bàn phím thực tế, sẵn sàng cho công tác thẩm định độc lập của Controller Sol!
