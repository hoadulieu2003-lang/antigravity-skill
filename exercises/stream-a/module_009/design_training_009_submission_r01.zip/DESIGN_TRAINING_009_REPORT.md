# BÁO CÁO THỰC THI & KIỂM CHỨNG TRỢ NĂNG — MODULE 09
## STREAM A: FOUNDATION INTEGRITY · TASK: ACCESSIBILITY TASK COMPLETION
### TRIPFLOW — Bàn Tiếp Nhận Yêu Cầu Hỗ Trợ Hành Khách (Hồ sơ AR-901)

- **REPORT_ID**: `DESIGN_TRAINING_009_REPORT`
- **MODULE_ID**: `DESIGN_TRAINING_009_ACCESSIBILITY`
- **MODULE_NAME**: `ACCESSIBILITY_TASK_COMPLETION`
- **STREAM_ID**: `FOUNDATION_INTEGRITY`
- **BRANCH_ID**: `TAB_A`
- **OWNER**: Anh — Lead Architect / Product Owner
- **CONTROLLER**: ChatGPT Architectural Controller (Sol)
- **EXECUTOR**: Antigravity (Senior AI Pair-Programmer)
- **SUBMISSION_REVISION**: `R01`
- **PROPOSED_VERDICT**: `SELF_CHECK_PASS / SUBMITTED_FOR_CONTROLLER_REVIEW`
- **HARNESS_EXECUTION_RESULT**: `8/8 GATES PASS (A01–A08) · 12/12 TESTS PASS (T01–T12)`

---

## 1. CANONICAL FIXTURE & PRIVACY BOUNDARY (BỐI CẢNH DỮ LIỆU & RANH GIỚI BẢO MẬT)

### 1.1. Dữ liệu Huấn luyện Chuẩn hóa (Synthetic Training Fixture)
Toàn bộ quy trình kiểm toán và thi công của Module 09 được vận hành độc quyền trên bộ dữ liệu giả lập đã được Controller phê duyệt:
- **Mã hồ sơ yêu cầu (`request_id`)**: `AR-901`
- **Mã đặt chỗ (`booking_code`)**: `BK-24091`
- **Tên hành khách (`passenger_display_name`)**: `Khách A`
- **Mã tour (`tour_id`)**: `TF-802`
- **Tên tour (`tour_name`)**: `Tour Fansipan Sapa 2 Ngày 1 Đêm`
- **Thời gian khởi hành (`departure`)**: `2026-09-15 06:30 ICT`
- **Trạng thái ban đầu (`current_status`)**: `Chưa ghi nhận yêu cầu hỗ trợ`

```yaml
DATA_CLASSIFICATION: SYNTHETIC_TRAINING_FIXTURE
REAL_CUSTOMER_DATA: false
MEDICAL_DIAGNOSIS_COLLECTION: forbidden
BUSINESS_PERFORMANCE_CLAIMS: none
```

### 1.2. Ranh giới Bảo mật Nghiệp vụ (Privacy Boundary)
- Hệ thống chỉ thu thập **Nhu cầu hỗ trợ chức năng thực tế cần bố trí** trong hành trình (xe lăn lên xuống xe, tài liệu chữ lớn, giao tiếp văn bản).
- Tuyệt đối nghiêm cấm thu thập, lưu trữ hoặc gợi ý chẩn đoán y tế, bệnh án hay lịch sử sức khỏe cá nhân của hành khách.

---

## 2. BASELINE AUDIT — BẢNG PHÂN TÍCH 8 KHUYẾT TẬT CÓ CHỦ ĐÍCH (DEF-01 ĐẾN DEF-08)

Bản mẫu cơ sở [`baseline/index.html`](file:///C:/Users/game/.gemini/exercises/stream-a/module_009/baseline/index.html) mang đúng 8 khuyết tật trợ năng có chủ đích kèm banner cảnh báo bắt buộc:
> *"Bản mẫu huấn luyện có lỗi khả năng tiếp cận có chủ đích — không dùng trong sản phẩm thật."*

| Mã Lỗi | Khuyết tật Quan sát được (`Observed Defect`) | Nguy cơ Tiêu chuẩn Liên quan (`Relevant Criterion / Risk`) | Kỹ thuật Khắc phục Ứng viên (`Candidate Technique`) |
| :---: | :--- | :--- | :--- |
| **`DEF-01`** | Nút lưu dùng thẻ `<div class="btn-save" onclick="save()">`, thiếu `role="button"`, không có `tabindex="0"`, không bắt phím Enter/Space. | **POTENTIAL_FAILURE**: SC 4.1.2 (Name, Role, Value) & SC 2.1.1 (Keyboard). Người dùng bàn phím hoàn toàn không thể Tab hoặc kích hoạt nút. | Sử dụng native `<button type="submit" id="btn-save-support">` kế thừa trọn vẹn hành vi bàn phím và khả năng focus mặc định của trình duyệt. |
| **`DEF-02`** | Ô Chi tiết hỗ trợ chỉ dùng `placeholder="Chi tiết hỗ trợ"`, thiếu thẻ `<label>` và không có `aria-label`. Nhãn biến mất khi nhập liệu. | **POTENTIAL_FAILURE**: SC 3.3.2 (Labels or Instructions) & SC 4.1.2. Mất nhãn định danh khi người dùng gõ chữ vào ô nhập. | Sử dụng thẻ `<label for="field-details">Chi tiết hỗ trợ</label>` hiển thị cố định và bền vững phía trên ô nhập liệu. |
| **`DEF-03`** | Trạng thái lỗi chỉ biểu diễn bằng viền đỏ (`border-color: #EF4444`), không có câu text giải thích và không có liên kết `aria-describedby`. | **POTENTIAL_FAILURE**: SC 1.4.1 (Use of Color) & SC 3.3.1 (Error Identification). Người dùng khiếm thị hoặc mù màu không nhận biết được lỗi. | Hiển thị chuỗi văn bản thông báo lỗi cụ thể và liên kết ngữ nghĩa với control qua `aria-describedby` + `aria-invalid="true"`. |
| **`DEF-04`** | Thứ tự DOM và thứ tự hiển thị thị giác bị đảo ngược bằng CSS `flex-direction: column-reverse;`, phím Tab đi ngược từ dưới lên. | **POTENTIAL_FAILURE**: SC 1.3.2 (Meaningful Sequence) & SC 2.4.3 (Focus Order). Gây mất phương hướng cho người dùng duyệt bằng phím Tab. | Chuẩn hóa luồng mã nguồn DOM khớp 100% với luồng đọc tự nhiên từ trên xuống dưới. |
| **`DEF-05`** | Cập nhật trạng thái đang lưu và lỗi mạng được chèn vào thẻ `<div>` thông thường không có `role="status"`, `role="alert"`, hay `aria-live`. | **POTENTIAL_FAILURE**: SC 4.1.3 (Status Messages). Trình đọc màn hình không thể tự động phát hiện và đọc thông báo cập nhật bất đồng bộ. | Thiết lập hai vùng live-region tĩnh hiện diện sẵn từ DOM ban đầu (`#live-status-region`, `#live-alert-region`). |
| **`DEF-06`** | Khi nhấn Lưu, gán native `disabled` hoặc thay thế HTML nút, khiến trình duyệt đẩy bật con trỏ focus rơi tự do về `document.body`. | **USABILITY_DEFECT / POTENTIAL_FAILURE**: Rủi ro mất định hướng con trỏ bàn phím theo khuyến nghị của WAI-ARIA APG. | Duy trì 1 node button duy nhất ổn định (`#btn-save-support`), dùng `aria-busy`, `aria-disabled` và cờ logic `isSaving` (0 body focus). |
| **`DEF-07`** | Vùng bấm độc lập của radio và checkbox chỉ đạt kích thước 20×20 CSS px không có padding mở rộng. | **PROJECT_INVARIANT_FAILURE**: Vi phạm quy chuẩn nội bộ dự án TRIPFLOW (Mục tiêu hiệu dụng $\ge 44 \times 44$ CSS px).<br>*(Lưu ý: Ngưỡng SC 2.5.8 WCAG 2.2 AA là 24×24 CSS px).* | Thiết lập container bao bọc `.target-container` kết hợp padding và nhãn liên kết đạt kích thước tối thiểu $44 \times 44$ CSS px. |
| **`DEF-08`** | Khung chứa form đặt fixed width cứng `width: 650px;`, gây vỡ giao diện và phát sinh thanh cuộn ngang khi xem ở màn hình 320 CSS px. | **POTENTIAL_FAILURE**: SC 1.4.10 (Reflow). Buộc người dùng phải cuộn hai chiều để xem nội dung và điền biểu mẫu. | Áp dụng thiết kế đáp ứng linh hoạt với `max-width: 100%`, loại bỏ hoàn toàn thanh cuộn ngang trang ở mọi kích thước viewport. |

---

## 3. BA NGUYÊN TẮC CHUẨN MỰC W3C CỐT LÕI (THREE NORMATIVE PILLARS)

Báo cáo căn cứ độc quyền vào các tài liệu tiêu chuẩn chính thức của W3C (không sử dụng blog cá nhân làm căn cứ pháp lý):

### 3.1. Nguyên tắc 1: W3C WAI-ARIA APG — Dialog (Modal) Pattern
- **Điều nguồn thực sự quy định**: Hộp thoại modal phải có `role="dialog"`, `aria-modal="true"`. Focus khi mở phải chuyển vào bên trong hộp thoại; các phím `Tab` / `Shift+Tab` bị giam giữ (`Focus Trap`) trong modal; phím `Escape` đóng hộp thoại; khi đóng, focus **bắt buộc phải hoàn trả chuẩn xác về trigger button** đã mở hộp thoại đó.
- **Cách áp dụng vào bài**: Hộp thoại native `<dialog id="support-guidance-dialog">` kích hoạt bởi `#btn-open-guidance` (`aria-haspopup="dialog"`). Khi mở bằng `.showModal()`, focus chuyển vào `#btn-close-guidance`. Nhấn `Escape` hoặc nút đóng: focus lập tức hoàn trả về `#btn-open-guidance`.
- **Giới hạn**: Quyết định đưa focus ban đầu vào nút đóng là quyết định thiết kế có chủ đích của dự án cho modal hướng dẫn ngắn, không phải lựa chọn duy nhất của APG.
- **Bằng chứng thực thi**: Đạt tuyệt đối tại **Test T03 (Gate A03)**.

### 3.2. Nguyên tắc 2: WCAG 2.2 SC 3.3.1 (Error Identification) & SC 3.3.3 (Error Suggestion)
- **Điều nguồn thực sự quy định**: Khi phát hiện lỗi nhập liệu, phần tử bị lỗi phải được xác định và mô tả bằng văn bản cụ thể. Mối quan hệ giữa control lỗi và văn bản mô tả phải xác định được bằng máy qua `aria-describedby` và `aria-invalid="true"`.
- **Cách áp dụng vào bài**: Thiết lập khối Error Summary ở đầu form (`#error-summary` với `role="alert"`) chứa danh sách anchor links trỏ tới từng control lỗi. Các trường lỗi được gắn `aria-invalid="true"` và liên kết qua `aria-describedby`. Khi submit lỗi, focus tự động chuyển đến control lỗi đầu tiên theo thứ tự DOM (`#radio-boarding`).
- **Giới hạn**: Automated scanner chỉ kiểm tra sự tồn tại của attributes và ID liên kết; độ rõ ràng và dễ hiểu của câu chữ tiếng Việt được thẩm định qua Manual Accessibility Review.
- **Bằng chứng thực thi**: Đạt tuyệt đối tại **Test T04, T05 (Gate A04)**.

### 3.3. Nguyên tắc 3: WCAG 2.2 SC 4.1.3 (Status Messages) & Live Regions
- **Điều nguồn thực sự quy định**: Thông điệp trạng thái bất đồng bộ phải được truyền đạt tới công nghệ hỗ trợ mà không cướp con trỏ focus của người dùng. Trạng thái lưu/thành công dùng `role="status"` (`polite`); trạng thái lỗi mạng khẩn cấp dùng `role="alert"` (`assertive`).
- **Cách áp dụng vào bài**: Khóa ma trận Single-Source Announcement Matrix:
  - Validation error: Chỉ phát từ `#error-summary` (`role="alert"`). Không phát lặp qua live alert region (`live_alert_region_repeats_validation: false`).
  - Network error: Phát qua `#live-alert-region` (`role="alert"`, `assertive`).
  - Saving & Success: Phát qua `#live-status-region` (`role="status"`, `polite`).
  - Nút submit `#btn-save-support` duy trì nguyên vẹn node trong DOM, dùng `aria-busy="true"` và cờ `isSaving` (không dùng native `disabled`).
  - **No-Steal Focus Invariant**: Khi người dùng di chuyển focus sang `#btn-open-guidance` trong lúc đang lưu, khi lưu xong, focus hiện tại tại `#btn-open-guidance` được bảo toàn nguyên vẹn.
- **Bằng chứng thực thi**: Đạt tuyệt đối tại **Test T06, T07, T08, T09 (Gate A04, A05)**.

---

## 4. PHÂN TÍCH HAI HƯỚNG TIẾP CẬN & ĐÁNH ĐỔI KIẾN TRÚC (REMEDIATION DIRECTIONS)

Hai hướng được xây dựng song song trên cùng bộ dữ liệu chuẩn hóa AR-901 và cùng bộ chuỗi copy khóa:
- **Direction A**: [`directions/option_a.html`](file:///C:/Users/game/.gemini/exercises/stream-a/module_009/directions/option_a.html) — Inline Accessible Form (Được chọn làm Candidate).
- **Direction B**: [`directions/option_b.html`](file:///C:/Users/game/.gemini/exercises/stream-a/module_009/directions/option_b.html) — Guided Review Flow (Mô hình 2 bước có rà soát).

### 4.1. Bảng So Sánh 4 Chiều Kích Theo Quy Chuẩn Bounded Claims

| Chiều kích So sánh | Direction A — Inline Accessible Form (`option_a.html`) | Direction B — Guided Review Flow (`option_b.html`) |
| :--- | :--- | :--- |
| **1. Số bước bàn phím (`Tab Stops`)** | **`ESTIMATED_TAB_STOPS` trước triển khai: ~12–14 steps**.<br>Đo đạc thực tế tại runtime: **12 Tab stops** từ Skip link đến nút Lưu. Luồng thao tác tuyến tính liên tục, không có nút chuyển bước trung gian. | **`ESTIMATED_TAB_STOPS` trước triển khai: ~20–22 steps**.<br>Đo đạc thực tế tại runtime: **21 Tab stops** do phải qua nút "Tiếp tục", bảng rà soát ở Bước 2, và nút "Quay lại". |
| **2. Khả năng phát hiện & sửa lỗi (`Error Recovery`)** | Toàn bộ lỗi hiển thị đồng thời tại `#error-summary` và inline dưới từng trường. Bấm anchor link hoặc Tab tới thẳng trường lỗi để sửa tại chỗ. | Lỗi Bước 1 chặn ở Bước 1. Nếu sang Bước 2 người dùng muốn đổi ý, họ phải bấm "Quay lại", làm gián đoạn luồng tác nghiệp. |
| **3. Tải ghi nhớ (`Cognitive Memory Load`)** | **`DESIGN_HYPOTHESIS`**: Người dùng nhìn thấy đồng thời toàn bộ trường và lựa chọn trên cùng màn hình, tối ưu cho tác vụ tác nghiệp nhanh của điều phối viên TRIPFLOW. | **`DESIGN_HYPOTHESIS`**: Bước 2 cung cấp bảng tĩnh rà soát thông tin trước khi nhấn Lưu chính thức, giúp giảm tải ghi nhớ cho việc kiểm chứng dữ liệu phức tạp. |
| **4. Độ ổn định focus (`Focus Stability`)** | **Tuyệt đối ổn định**: DOM tĩnh hoàn toàn, không có ẩn hiện khối cha, focus chỉ di chuyển theo thứ tự bàn phím tự nhiên hoặc tới lỗi đầu tiên khi submit. | Đòi hỏi quản lý focus chủ động bằng script khi chuyển bước (nhấn "Tiếp tục" phải chuyển focus về `#heading-step-2` có `tabindex="-1"`). |

### 4.2. Hai Điểm Đánh Đổi Kiến Trúc Bắt Buộc Của Hướng Được Chọn (Candidate - Direction A)
1. **Đánh đổi 1 (Mật độ hiển thị vs Toàn vẹn Cây Trợ năng)**:
   - *Chấp nhận*: Trên màn hình nhỏ (320px) hoặc khi phóng to chữ 200%, Direction A dồn toàn bộ biểu mẫu và khối tóm tắt lỗi lên cùng một trang, khiến trang dài hơn và phát sinh cuộn dọc nhiều hơn.
   - *Bù lại*: Đảm bảo 100% cây trợ năng luôn toàn vẹn và hiện diện đầy đủ (`Zero State Fragmentation`), toàn bộ thuộc tính `aria-describedby` và anchor links luôn trỏ tới các DOM nodes có thực tại mọi thời điểm.
2. **Đánh đổi 2 (Không có màn hình Review tĩnh vs Phục hồi Lỗi mạng Tức thì)**:
   - *Chấp nhận*: Không có màn hình Review chuyên biệt như Direction B, đòi hỏi điều phối viên phải tự lướt mắt rà soát dữ liệu trước khi gửi.
   - *Bù lại*: Khi xảy ra lỗi mạng ở Attempt 1, người dùng quan sát thấy ngay toàn bộ dữ liệu bản nháp (`Live Draft`) vẫn đang được giữ nguyên vẹn trong ô nhập liệu và có thể nhấn nút "Thử lưu lại" ngay lập tức mà không phải thực hiện các thao tác chuyển bước phức tạp.

---

## 5. REQUIREMENT → SELECTOR → TEST → EVIDENCE MATRIX

| Mã Gate | Yêu Cầu Kỹ Thuật | Selector Ánh Xạ Trong Contract | Test Kiểm Chứng | Dữ Liệu Thực Nghiệm (Telemetry & Hashes) | Kết Quả Tự Kiểm |
| :---: | :---|---|:---:|---|:---:|
| **`A01`** | Semantic Structure, Single H1, Reading Order & Skip Link | `header#site-header`, `nav#site-nav`, `main#main-content`, `footer#site-footer`, `h1#page-heading`, `a#skip-link` | **T01** | • 4/4 landmarks hợp lệ.<br>• 1 thẻ `h1` duy nhất ("Ghi nhận yêu cầu hỗ trợ").<br>• Heading hierarchy không bỏ cấp.<br>• Skip link focusable, rect dương (243×48px). | **SELF_CHECK_PASS** |
| **`A02`** | Accessible Name Graph, 0 Unnamed, 0 Duplicate IDs, 0 Orphan Refs | `button`, `input`, `textarea`, `a[href]` | **T02** | • 11/11 controls có accessible name duy nhất.<br>• 0 duplicate IDs.<br>• 0 orphaned ARIA references. | **SELF_CHECK_PASS** |
| **`A03`** | Native Keyboard Journey & Modal Dialog APG Lifecycle | `dialog#support-guidance-dialog`, `button#btn-open-guidance`, `button#btn-close-guidance` | **T03** | • Gọi native `.showModal()`, `aria-modal="true"`.<br>• Focus ban đầu vào nút đóng (Design decision).<br>• Tab bị giam trong dialog.<br>• Escape đóng dialog, focus phục hồi 100% về `#btn-open-guidance`. | **SELF_CHECK_PASS** |
| **`A04`** | Validation, Error Association, 200-char Limit, Draft Preservation & Retry FSM | `#error-summary`, `#support-type-group`, `#field-details`, `#checkbox-confirmation`, `#btn-save-support` | **T04<br>T05<br>T06<br>T07** | • Submit rỗng: focus về `#radio-boarding`, attempts=0.<br>• 201 ký tự bị chặn, sửa về 200 xóa lỗi, attempts=0.<br>• Attempt 1: Lỗi mạng, draft giữ nguyên 100%, attempts=1, commits=0.<br>• Attempt 2: Thành công, render committed summary, attempts=2, commits=1. | **SELF_CHECK_PASS** |
| **`A05`** | Single-Source Live Announcement, Stable Action Node & No-Steal Focus Invariant | `#live-status-region`, `#live-alert-region`, `#btn-save-support`, `#btn-open-guidance` | **T08<br>T09** | • Validation chỉ phát từ `#error-summary` (không lặp qua live alert).<br>• Click kép trong lúc saving bị chặn (attempts=1).<br>• Di chuyển focus sang `#btn-open-guidance` trong lúc saving; khi hoàn tất, focus vẫn ở `#btn-open-guidance` (No focus steal). | **SELF_CHECK_PASS** |
| **`A06`** | Responsive Cadence, Reflow 320px & Text Scaling Simulation 200% | `html`, `body`, `.app-shell`, `.case-grid` | **T10** | • Viewport 320×800: `scrollWidth (320) <= clientWidth (320)` (0 cuộn ngang).<br>• Phóng to chữ 200%: Cho phép cuộn dọc, 0 cuộn ngang, 0 text clipping.<br>• Gắn nhãn `TEXT_SCALE_SIMULATION`. | **SELF_CHECK_PASS** |
| **`A07`** | Forced-Colors Capability Preflight, Target Sizes & Mathematical Contrast | `button`, `input`, `textarea`, `.target-container` | **T11** | • Preflight forced-colors: `matchMedia` = true (`EXECUTED_PASS`).<br>• 100% controls đạt project invariant $\ge 44 \times 44$ CSS px và SC 2.5.8 $\ge 24 \times 24$ px.<br>• Tương phản văn bản chính: 16.96:1 (Đạt chuẩn $\ge 4.5:1$).<br>• Zero motion: 0 animations/transitions. | **SELF_CHECK_PASS** |
| **`A08`** | Evidence Integrity, AX Tree Snapshot & Deliverable Hashes | `AX_TREE.json`, `VERIFICATION.json`, `screenshots/` | **T12** | • Snapshot cây trợ năng Chromium CDP: 136 nodes.<br>• Đủ 11 ảnh authoritative screenshots DPR=2.<br>• Mã băm SHA-256 đồng bộ tuyệt đối.<br>• 0 giá trị hardcoded pass. | **SELF_CHECK_PASS** |

---

## 6. KẾT QUẢ KIỂM THỬ KHÓA T01–T12 CHI TIẾT

```text
======================================================================
 GATE EVALUATION SUMMARY MATRIX — MODULE 09 (SUBMISSION R01)
======================================================================
 Gate A01 (Semantic Structure & Reading Order    ) : [ PASS ]
 Gate A02 (Accessible Name & ARIA Reference Graph) : [ PASS ]
 Gate A03 (Native Keyboard Journey & Modal Dialog) : [ PASS ]
 Gate A04 (Validation, Error Recovery & FSM      ) : [ PASS ]
 Gate A05 (Live Announcement & No-Steal Invariant) : [ PASS ]
 Gate A06 (Reflow 320px & Text Scaling Stress    ) : [ PASS ]
 Gate A07 (Forced-Colors, Target Size & Contrast ) : [ PASS ]
 Gate A08 (Evidence Integrity & AX Tree Snapshot ) : [ PASS ]
----------------------------------------------------------------------
 OVERALL VERDICT: SELF_CHECK_PASS / SUBMITTED_FOR_CONTROLLER_REVIEW
======================================================================
```

- **T01 (Structure Scan)**: 4/4 landmarks hiện diện; 1 thẻ `h1` duy nhất; hierarchy hợp lệ; Skip link hoạt động khi nhấn Tab (`skipLinkFocused: true`). $\to$ **PASS**
- **T02 (Accessible Name Graph)**: 11 controls được phân tích; `unnamedCount: 0`; `dupIdsCount: 0`; `orphanRefsCount: 0`. $\to$ **PASS**
- **T03 (Native Dialog Journey)**: `opened: true`; `initialFocusCloseBtn: true`; `closedOnEscape: true`; `focusRestoredToTrigger: true` (hoàn trả về `#btn-open-guidance`). $\to$ **PASS**
- **T04 (Empty Submit Validation)**: `#error-summary` hiển thị với `role="alert"`; focus tự động chuyển đến `#radio-boarding`; `attempts: 0`; `liveAlertDidNotRepeat: true` (Single source compliance). $\to$ **PASS**
- **T05 (201-char Error & Edit to 200)**: Nhập 201 ký tự hiển thị đúng copy `"Chi tiết hỗ trợ không được vượt quá 200 ký tự."`; sửa về 200 ký tự xóa bỏ lỗi; `attempts: 0`. $\to$ **PASS**
- **T06 (Valid Submit Attempt 1)**: Nút chuyển `"Đang lưu yêu cầu hỗ trợ…"`; sau 800ms phát thông báo lỗi mạng `"Chưa lưu được yêu cầu hỗ trợ. Nội dung đã nhập vẫn được giữ."`; bản nháp giữ nguyên 100%; nút chuyển `"Thử lưu lại"`; `attempts: 1`, `commits: 0`. $\to$ **PASS**
- **T07 (Retry Attempt 2 Success)**: Nút lưu lần 2; sau 800ms phát thông báo thành công `"Đã lưu yêu cầu hỗ trợ cho hồ sơ AR-901."`; Committed Summary hiển thị chính xác dữ liệu từ Payload Snapshot; nút `"Sửa yêu cầu"` xuất hiện; `attempts: 2`, `commits: 1`. $\to$ **PASS**
- **T08 (Duplicate Activation Guard)**: Kích hoạt đúp trong cửa sổ lưu 800ms được chặn bởi cờ `isSaving`; `attempts: 1` (không vượt quá 1). $\to$ **PASS**
- **T09 (No-Steal Focus Audit)**: Chuyển focus sang `#btn-open-guidance` trong lúc đang lưu; sau khi lưu hoàn tất, focus vẫn giữ nguyên tại `#btn-open-guidance` (`document.activeElement.id === 'btn-open-guidance'`). $\to$ **PASS**
- **T10 (Reflow & Text Stress)**: Ở 320 CSS px: `scrollWidth <= clientWidth` (0 horizontal overflow); Text scale 200%: cho phép cuộn dọc, `zeroRectsCount: 0`, 0 text clipping. $\to$ **PASS**
- **T11 (Forced-Colors, Target Size & Contrast)**: Preflight forced-colors: `forcedColorsStatus: EXECUTED_PASS`; 100% controls đạt target $\ge 44 \times 44$ CSS px; tương phản văn bản chính 16.96:1; zero motion. $\to$ **PASS**
- **T12 (AX Tree & Evidence Integrity)**: Trích xuất 136 nodes từ Chromium CDP AX Tree; đủ 11 screenshots DPR=2; mã băm đồng bộ tuyệt đối; 0 hardcoded pass. $\to$ **PASS**

---

## 7. PHÂN ĐỊNH RANH GIỚI TELEMETRY / MANUAL REVIEW / HYPOTHESIS

```
┌──────────────────────────────────────────────────────────┬──────────────────────────────────────────────────────────┐
│             TELEMETRY (ĐO ĐẠC TỰ ĐỘNG)                   │          MANUAL REVIEW (ĐÁNH GIÁ THỦ CÔNG)               │
├──────────────────────────────────────────────────────────┼──────────────────────────────────────────────────────────┤
│ • Danh sách 4 landmarks, số lượng thẻ h1 và headings.   │ • Tính tự nhiên, tôn trọng và dễ hiểu của nhãn và câu    │
│ • Kiểm tra thuộc tính accessible name, dup IDs, ARIA refs.│   thông báo lỗi tiếng Việt đối với người dùng thực tế.   │
│ • Bounding Box hình học (44x44 CSS px, 24x24 CSS px).    │ • Trải nghiệm âm thanh và nhịp đọc thực tế trên các      │
│ • Chỉ số cuộn trang scrollWidth <= clientWidth (320px).  │   trình đọc màn hình (NVDA, VoiceOver, JAWS).            │
│ • Tính toán toán học độ tương phản sRGB (Luminance).     │ • Đánh giá tính logic trong nghiệp vụ điều phối viên du  │
│ • Snapshot 136 nodes của cây trợ năng Chromium CDP.      │   lịch TRIPFLOW.                                         │
│ • Bộ đếm FSM (attempts counter, no-steal focus target).  │ • Nhận định người dùng: "Tối ưu thao tác", "giảm tải ghi │
│                                                          │   nhớ" (được định danh là DESIGN_HYPOTHESIS).            │
└──────────────────────────────────────────────────────────┴──────────────────────────────────────────────────────────┘
```

- **Giới hạn kỹ thuật (`Limitations`)**:
  1. Cây trợ năng Chromium CDP (`AX Tree`) chỉ phản ánh cấu trúc dữ liệu máy tính của trình duyệt, không thay thế được việc kiểm thử trực tiếp của người khuyết tật sử dụng công nghệ hỗ trợ thực tế.
  2. Phương thức phóng to chữ qua CSS (`html { font-size: 200% }`) là một mô phỏng kích thước chữ cơ sở (`TEXT_SCALE_SIMULATION`), không tương đương hoàn toàn với tính năng Full Browser Zoom của trình duyệt.
  3. Preflight forced-colors được thực thi qua CDP `Emulation.setEmulatedMedia`, phản ánh môi trường mô phỏng trên Chromium engine.

---

## 8. TỰ PHÊ BÌNH & ĐÁNH GIÁ CHUYÊN MÔN (SELF-CRITIQUE)

### 8.1. Điểm Mạnh (`STRENGTH`)
1. **Kiến trúc Native-First Triệt Để**: Biểu mẫu ưu tiên tối đa các phần tử native HTML (`<dialog>`, `<fieldset>`, `<legend>`, `<label>`, `<button type="submit">`), giảm thiểu sự phụ thuộc vào các thuộc tính ARIA phức tạp, giúp cây trợ năng gọn nhẹ và ổn định tuyệt đối.
2. **Kỷ Luật Single-Source Live Announcement**: Phân định rạch ròi nguồn phát âm thanh cho từng loại thông báo (Error Summary cho validation, Live Alert cho lỗi mạng, Live Status cho tiến trình lưu), loại bỏ hoàn toàn hiện tượng đọc lặp lỗi gây phiền toái cho người dùng khiếm thị.
3. **Mô Hình Dữ Liệu 3 Lớp Chặt Chẽ**: Phân tách rõ ràng giữa `Live Draft`, `Payload Snapshot` (chụp bất biến tại t=0ms) và `Committed Data`, ngăn ngừa triệt để các lỗi tranh chấp dữ liệu khi mạng gặp sự cố.

### 8.2. Khuyết Tật & Hạn Chế (`DEFECT`)
1. **Mật Độ Thị Giác Trên Màn Hình Hẹp Ở Direction A**: Khi hiển thị trên màn hình 320 CSS px kết hợp chế độ phóng to chữ 200%, toàn bộ khối Error Summary và biểu mẫu dồn lên một trang duy nhất khiến chiều dài trang tăng lên đáng kể, đòi hỏi người dùng phải cuộn dọc nhiều màn hình.
2. **Chưa Tích Hợp Live Validation Khi Đang Gõ**: Hiện tại việc kiểm tra hợp lệ chỉ kích hoạt khi người dùng nhấn submit hoặc xóa ký tự ở trường textarea. Việc bổ sung kiểm tra theo thời gian thực khi người dùng rời khỏi trường (`onblur`) có thể giúp phát hiện lỗi sớm hơn, nhưng cần cân nhắc kỹ để không gây nhiễu cho screen reader.

### 8.3. Điểm Đánh Đổi Kỹ Thuật (`TRADEOFF`)
1. **Duy Trì Node Button Thay Vì Native Disabled**: Để bảo toàn focus không bị rơi tự do về `document.body` trong suốt 800ms đang lưu, hệ thống chấp nhận không sử dụng thuộc tính native `disabled` trên nút bấm, mà sử dụng `aria-disabled="true"` kết hợp cờ logic `isSaving = true` ở tầng JavaScript để chặn kích hoạt trùng lặp.
2. **Loại Bỏ Màn Hình Rà Soát Trung Gian**: Chọn Direction A thay vì Direction B đồng nghĩa với việc từ bỏ bước rà soát dữ liệu tĩnh trước khi gửi, đổi lại là giảm thiểu 50% số bước bàn phím (từ 21 xuống 12 Tab stops) và giúp người dùng phục hồi ngay lập tức sau lỗi mạng.

### 8.4. Thiên Hướng Thiết Kế (`PREFERENCE`)
- Em ưu tiên **Direction A (Inline Accessible Form)** cho các hệ thống tiếp nhận tác nghiệp nghiệp vụ chuyên nghiệp (như TRIPFLOW Support Desk), nơi người điều phối viên coi trọng tốc độ xử lý, tính trực quan toàn diện và khả năng phục hồi lỗi mạng nhanh hơn là việc phải bấm Next/Back qua các bước rà soát thủ công.

---

## 9. DANH MỤC BẰNG CHỨNG HÌNH ẢNH AUTHORITATIVE (DPR=2)

Toàn bộ 11 tệp ảnh chụp màn hình độ phân giải cao DPR=2 đã được ghi nhận vào thư mục `screenshots/` với mã băm SHA-256 tương ứng:

1. `screenshots/baseline_desktop_1440x900.png` — Bản cơ sở Baseline với 8 defects và disclaimer banner.
2. `screenshots/direction_a_desktop_1440x900.png` — Hướng kiến trúc A (Inline Form).
3. `screenshots/direction_b_desktop_1440x900.png` — Hướng kiến trúc B (Guided Review Flow).
4. `screenshots/final_desktop_1440x900.png` — Bản ứng viên Candidate hoàn chỉnh ở Desktop (1440×900).
5. `screenshots/final_mobile_390x844.png` — Bản ứng viên Candidate hoàn chỉnh ở Mobile (390×844).
6. `screenshots/final_mobile_validation_390x844.png` — Trạng thái hiển thị Error Summary và lỗi inline trên Mobile.
7. `screenshots/final_mobile_network_error_390x844.png` — Trạng thái lỗi mạng Attempt 1 và nút "Thử lưu lại".
8. `screenshots/final_mobile_success_390x844.png` — Trạng thái thành công Attempt 2 và bảng Committed Summary.
9. `screenshots/final_reflow_320x800.png` — Bằng chứng không phát sinh cuộn ngang ở bề rộng 320 CSS px.
10. `screenshots/final_text_resize_200_percent.png` — Bằng chứng mô phỏng phóng to chữ 200% (`TEXT_SCALE_SIMULATION`).
11. `screenshots/final_forced_colors.png` — Bằng chứng hiển thị rõ nét trong chế độ màu tương phản cao (`forced-colors: active`).

---

## 10. KẾT LUẬN & ĐỀ XUẤT PHÁN QUYẾT (VERDICT RECOMMENDATION)

- Toàn bộ 8 Cổng kiểm toán Trợ năng (**A01 — A08**) và 12 Kịch bản kiểm thử khóa (**T01 — T12**) đều đã được thi công hoàn chỉnh, tự kiểm chứng thành công và ghi nhận đầy đủ bằng chứng thực nghiệm độc lập.
- Bản nộp tuân thủ nghiêm ngặt mọi điều kiện bắt buộc từ **`DESIGN_TRAINING_009_FIRST_RESPONSE_REVIEW_002.md`** (K01 — K06).

Antigravity trân trọng đề xuất Controller Sol phê duyệt kết quả tự kiểm của Module 09:

```yaml
PROPOSED_VERDICT: SELF_CHECK_PASS / SUBMITTED_FOR_CONTROLLER_REVIEW
MODULE_009_STATUS: READY_FOR_CONTROLLER_AUDIT
NEXT_MODULE: DESIGN_TRAINING_010_RESPONSIVE_INCLUSIVE_DESIGN
```
